package com.example.siaappa50;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MainActivity extends AppCompatActivity {

    ConstraintLayout myLayout;
    AnimationDrawable animationDrawable;

    Button buttonGetStarted;
    ImageView imgViewbookIcon, imgViewCSEReviewerText;
    Animation frombottom, fromtop, fromleft;

    private static long back_pressed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myLayout = findViewById(R.id.myLayout);
        animationDrawable = (AnimationDrawable) myLayout.getBackground();
        animationDrawable.setEnterFadeDuration(0);
        animationDrawable.setExitFadeDuration(4500);
        animationDrawable.start();

        buttonGetStarted = findViewById(R.id.button);
        imgViewbookIcon = findViewById(R.id.imageView_book_icon);
        imgViewCSEReviewerText = findViewById(R.id.imageView_CSE_reviewer_text);

        frombottom = AnimationUtils.loadAnimation(this,R.anim.frombottom);
        fromtop = AnimationUtils.loadAnimation(this,R.anim.fromtop);
        fromleft = AnimationUtils.loadAnimation(this,R.anim.fromleft);

        buttonGetStarted.setAnimation(frombottom);
        imgViewbookIcon.setAnimation(fromtop);
        imgViewCSEReviewerText.setAnimation(fromleft);

        buttonGetStarted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMain2Activity();
            }
        });
    }

    @Override
    public void onBackPressed() {

            if(back_pressed + 2000 > System.currentTimeMillis())
            {
                super.onBackPressed();
                return;
            }
            else
            {
                Toast.makeText(getBaseContext(), "Please Back again to exit", Toast.LENGTH_SHORT).show();
            }
            back_pressed = System.currentTimeMillis();
        }



    public void openMain2Activity(){
        Intent intent = new Intent(this, Main3Activity.class);
        startActivity(intent);
    }


}



