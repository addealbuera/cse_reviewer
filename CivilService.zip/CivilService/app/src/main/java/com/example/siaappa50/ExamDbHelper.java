package com.example.siaappa50;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
import com.example.siaappa50.QuizContact.*;

import java.util.ArrayList;
import java.util.List;

public class ExamDbHelper extends SQLiteOpenHelper
{
    // Database Name and Version
    private static final String DATABASE_NAME = "myawesomeexam.db";
    private static final int DATABASE_VERSION = 1;

    private SQLiteDatabase db;

    public ExamDbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);


    }

    //    Creating Table in SQLite
    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;
        final String SQL_CRETE_QUESTION_TABLE = " CREATE TABLE " + QuizContact.QuestionTables.TABLE_NAME + " ( " + QuestionTables._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionTables.COLUMN_QUESTION + " TEXT, " + QuestionTables.COLUMN_OPTION1 + " TEXT, " + QuestionTables.COLUMN_OPTION2 + " TEXT, " + QuestionTables.COLUMN_OPTION3 + " TEXT, " + QuestionTables.COLUMN_OPTION4 + " TEXT, " + QuestionTables.COLUMN_ANSWER_NR + " INTEGER " + " ) ";
        db.execSQL(SQL_CRETE_QUESTION_TABLE);

        fillQuestionTable();
    }
    // Deleting Table if the Table is Already Exist In SQLite
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(" DROP TABLE IF EXISTS " + QuestionTables.TABLE_NAME);
        onCreate(db);
    }

    //    Question and Answer here      //
    private void fillQuestionTable() {

        //Anatomy and Logic
        Question q1 = new Question("Iron: metal: : Granite: ______", "Marble ", "Rock", "Sand", "Solid", 2);
        addQuestion(q1);
        Question q2 = new Question("Decibel: sound: : volt: ______", "Watts", "Fire", "Electricity", "Lightning", 3);
        addQuestion(q2);
        Question q3 = new Question("Coward: brave: : philanthropist: _______", "Selfish", "Kind", "Pessimist", "Optimist", 1);
        addQuestion(q3);
        Question q4 = new Question("Logic: reasoning: : ethics: _______", "Character", "Behavior", "Subject", "Traits", 2);
        addQuestion(q4);
        Question q5 = new Question("Antenna: signal: : net: ______", "Web", "Catch", "Gross", "Fish", 4);
        addQuestion(q5);
        Question q6 = new Question("Stanza: poem : Act: ______", "Movie", "Opera", "Song", "Lyric", 2);
        addQuestion(q6);
        Question q7 = new Question("Astrology: Astronomy : Alchemy: ______", "Chemistry", "Biology", "Physics", "Science", 1);
        addQuestion(q7);
        Question q8 = new Question("Census: Population : Inventory: ______", "Accounting", "Merchandise", "Cost", "List", 2);
        addQuestion(q8);
        Question q9 = new Question("Oath: Promise : Contract: ______", "License", "Contract", "Agreement", "Paper", 3);
        addQuestion(q9);
        Question q10 = new Question("Glimmer: Flicker : Murmur:  ______", "Whisper", "Shout", "Rumor", "Speak", 1);
        addQuestion(q10);
        Question q11 = new Question("Bouquet: Flower : Flock:  ______", "Dogs", "Sheep", "Ship", "Cats", 2);
        addQuestion(q11);
        Question q12 = new Question("Rescind: Law : Withdraw: ______", "Bank", "Candidacy", "Deposit", "Resume", 2);
        addQuestion(q12);
        Question q13 = new Question("Hoax: Deceive : Filibuster: ______", "Delay", "Refuse", "Stop", "None", 1);
        addQuestion(q13);
        Question q14= new Question("Syllabus: Course : Agenda: ______", "Subject", "Platform", "Meeting", "Lesson", 3);
        addQuestion(q14);
        Question q15 = new Question("Cat: Kitten : Horse: ______", "Cab", "Puppy", "Stallion", "Pony", 4);
        addQuestion(q15);
        Question q16 = new Question("Evaporate: Vapor : Petrify: ______", "Liquid", "Stone", "Magnify", "Cold", 2);
        addQuestion(q16);
        Question q17 = new Question("Canvas: Painter : Marble: ______", "Sculptor", "Rock", "Statue", "Form", 1);
        addQuestion(q17);
        Question q18 = new Question("Hammer: Anvil : Pestle: ______", "Ground", "Grinder", "Mortar", "Knife", 3);
        addQuestion(q18);
        Question q19 = new Question("Librarian: Books : Curator ______", "Atlas", "Encyclopedia", "Room", "Paintings", 4);
        addQuestion(q19);
        Question q20 = new Question("Archive: Manuscript : Arsenal: ______", "Soldier", "Weapon", "Castle", "King", 2);
        addQuestion(q20);

        //English Vocabulary
        Question q21 = new Question("If you are ambivalent with the answers, analyze the given problem.", "Confusion", "Innocent", "Uncertain", "Unaware", 3);
        addQuestion(q21);
        Question q22 = new Question("He left the country because of the ominous experiences he had in the past.", "Unforgettable", "Threatening", "Ugly", "Remarkable", 2);
        addQuestion(q22);
        Question q23 = new Question("Teenagers are easily susceptible to peer influence", "Flexible", "Inspired", "Dependable", "Inclined", 4);
        addQuestion(q23);
        Question q24 = new Question("My mother is always adamant in eating breakfast before leaving the house.", "Tresolute", "Uncertain", "Forgetful", "Clueless", 1);
        addQuestion(q24);
        Question q25 = new Question("Reading words without understanding their meaning is futile", "Helpless", "Useless", "Unnecessary", "Avoidable", 2);
        addQuestion(q25);
        Question q26 = new Question("She wears gold but people know how ostentatious she can be", "Pretentious", "Ambitious", "Gorgeous", "Rebellious", 1);
        addQuestion(q26);
        Question q27 = new Question("He submitted a grotesque artwork that nobody in the class could relate to", "Different", "Weird", "Beautiful", "Colorful", 2);
        addQuestion(q27);
        Question q28 = new Question("Their clandestine affair remained unknown for three years.", "Forbidden", "Surprise", "Secret", "Unacceptable", 3);
        addQuestion(q28);
        Question q29 = new Question("They say love is like a firework, a fleeting moment.", "Brief", "Unforgettable", "Shinny", "Remarkable", 1);
        addQuestion(q29);
        Question q30 = new Question("Cara is repulsive and rebellious. She always speaks sordid words.", "Dirty", "Vulgar", "Weird", "bizarre", 2);
        addQuestion(q30);
        Question q31 = new Question("Every time I see Cathy looking at me, I feel Euphoria in my bones.", "Gravity", "Ecstasy", "Erotic", "Numb", 2);
        addQuestion(q31);
        Question q32 = new Question("I bought this book because when I read the blurb at the back, I fell in love with it.", "Summary", "Teaser", "Blog", "Plot", 2);
        addQuestion(q32);
        Question q33 = new Question("Finding a way out of the labyrinth is the last challenge of the competition.", "Castle", "Forest", "Maze", "Box", 3);
        addQuestion(q33);
        Question q34 = new Question("There is still love in our hearts amidst our seemingly mundane existence.", "Complicated", "Modern", "Worldly", "Wealthy", 2);
        addQuestion(q34);
        Question q35 = new Question("Cassy has a strong penchant in collecting cars.", "Belief", "Fondness", "Hobby", "Route", 2);
        addQuestion(q35);
        Question q36 = new Question("Diskettes and CDs are going obsolete.", "Recycled", "Refurbished", "Updated", "Outdated", 4);
        addQuestion(q36);
        Question q37 = new Question("The Queen of the Night dances vivaciously.", "Lively", "Awkward", "Kindly", "Sweetly", 1);
        addQuestion(q37);
        Question q38 = new Question("The court released a dogmatic statement that made people more hopeful.", "Naive", "Unbelievable", "Assertive", "Unclear", 3);
        addQuestion(q38);
        Question q39 = new Question("This generation is prone to plethoric use of mobile gadgets.", "Essential", "Crucial", "Important", "Excessive", 4);
        addQuestion(q39);
        Question q40 = new Question("I am usually haphazard in composing my poetry but they turn out so well anyway.", "Disorganized", "Blank", "Puzzled", "Ttrategic", 1);
        addQuestion(q40);

        //Numerical Reasoning
        Question q41 = new Question("2187, 729, 243, 81, 27, 9, ____?", "6", "3", "4", "2", 2);
        addQuestion(q41);
        Question q42 = new Question("1, 4, 9, 16, 25, 36, 49, 64, ___ ?", "72", "75", "81", "90", 3);
        addQuestion(q42);
        Question q43 = new Question("13 -21 34 -55 89 ___?", "-95", "-104", "-123", "-144", 4);
        addQuestion(q43);
        Question q44 = new Question("AZ CX EV GT ____?", "IR KP", "IR KQ", "IS KQ", "IS KP", 1);
        addQuestion(q44);
        Question q45 = new Question("A5 D25 G125 J625 M3125 ____?", "P15525", "P15625", "O15525", "O15625", 2);
        addQuestion(q45);
        Question q46 = new Question("What is -25 + 16?", "9", "-9", "-41", "41", 2);
        addQuestion(q46);
        Question q47 = new Question("What is 107 – (-17) ?", "-90", "90", "124", "-124", 3);
        addQuestion(q47);
        Question q48 = new Question("(-9) (-22) = ____?", "198", "-198", "31", "-31", 1);
        addQuestion(q48);
        Question q49 = new Question("(21) (-4) + (8) (-2) = ____?", "-100", "100", "-23", "23", 1);
        addQuestion(q49);
        Question q50 = new Question("(-560) ÷ 7 = ___?", "-80", "80", "-553", "553", 1);
        addQuestion(q50);
        Question q51 = new Question(" 6/8 + 2 ½ + 4/12 is also the same as?", "½ + 2.5 + ¼", "½ + 5/2 + 1/6", "¾ + 2.5 + 1/6", "¾ + 5/2 + 1/3", 4);
        addQuestion(q51);
        Question q52 = new Question("What is the Least Common Denominator of 1/8, ¾, and 1/16?", "4", "8", "16", "2", 3);
        addQuestion(q52);
        Question q53 = new Question("What is the Greatest Common Factor of 36 and 54?", "6", "12", "18", "9", 3);
        addQuestion(q53);
        Question q54 = new Question(" What is the sum of ½ + 8/4 + 6/12 ?", "15/12", "3/12", "3", "3 1/12", 3);
        addQuestion(q54);
        Question q55 = new Question("3/9 x 2/3 = ____", "6/27", "2/9", "9/18", "1/9", 2);
        addQuestion(q55);
        Question q56 = new Question("¾ ÷ 1/8 = ____", "8", "4", "12", "6", 4);
        addQuestion(q56);
        Question q57 = new Question(" What is the decimal form of ¾ %?", ".0075", ".075", ".75", ".00075", 1);
        addQuestion(q57);
        Question q58 = new Question("Convert 3.4% as a fraction.", "34/100", "34/100", "3.4/1000", "3.4/100", 4);
        addQuestion(q58);
        Question q59 = new Question("What is ¼ in decimal?", ".025", ".25", "2.5", ".0025", 2);
        addQuestion(q59);

        //Idiomatic Expression
        Question q60 = new Question("If you don’t spill the beans now, you might gonna regret it.", "Spread rumors", "Let out a secret", "Plant some seeds", "None of the above", 2);
        addQuestion(q60);
        Question q61 = new Question("Hey, man, you are absolutely barking up the wrong tree here because I’m innocent.", "Choosing the wrong dog", "Giving up a fight", "Accusing the wrong person", "Setting up an event in a tree", 3);
        addQuestion(q61);
        Question q62 = new Question("One proven way to beat an enemy is find his Achilles heel.", "Secret strategy", "Amulet", "Strong point", "Weak spot", 4);
        addQuestion(q62);
        Question q63 = new Question("His new Ferrari costs an arm and a leg so he is now looking for another job.", "Very expensive", "Got fired", "Met an accident", "Was stolen", 1);
        addQuestion(q63);
        Question q64 = new Question("He married a woman who was born with a silver spoon in her mouth.", "Born very beautiful", "Born very poor", "Born from a very rich family", "Born very talkative", 3);
        addQuestion(q64);
        Question q65 = new Question("She has different investments because she doesn’t want to put all eggs in one basket.", "Doesn’t want to put all resources in one possibility", "Doesn’t want to cook everything at once", "Doesn’t want to go bankrupt", "None of the above", 1);
        addQuestion(q65);
        Question q66= new Question("Whenever his crush passes by the hallway, he’s having butterflies in his stomach.",  "He feels sick", "He feels nervous", "He feels like flying","He feels so handsome", 2);
        addQuestion(q66);
        Question q67 = new Question("Even though they had a nasty fight, they decided to bury the hatchet and move on.", "Kill the enemy", "Remember the past", "Bury the dead", "Forget the past quarrel", 4);
        addQuestion(q67);
        Question q68 = new Question("My father always reminds us, “don’t count your chickens before the eggs have hatched.”", "Don’t eat your eggs before they are cooked.", "Don’t make plans for something that might not happen.", "Don’t deal with your problems before they are solved.", "All of the above.", 2);
        addQuestion(q68);
        Question q69 = new Question("iphones became so popular not only to teens, even my grandparents jumped on the bandwagon and bought some.", "ride on the gadget and sell Apple", "jump for technology and sell iphones", "joined the new trend and bought iphones", "bought Android and Apple", 3);
        addQuestion(q69);

        //
        Question q70 = new Question("Priscila _______ rather not invest her savings in the stock market.", "must", "has to", "could", "would", 4);
        addQuestion(q70);
        Question q71 = new Question(" Did you have any problem ______ our house?", "search", "to search", "searching", "for searching", 3);
        addQuestion(q71);
        Question q72 = new Question("I hope you don’t mind _____ joining you.", "to be", "i had been", "that i may", "my", 4);
        addQuestion(q72);
        Question q73 = new Question(" Most basketball players are 6 ____ tall or more.", "foot", "feet", "foots", "feets", 2);
        addQuestion(q73);
        Question q74 = new Question("These children _____ how to improvise more props for the play.", "knew", "knows", "know", "known", 3);
        addQuestion(q74);
        Question q75 = new Question(" The company will upgrade ______ computer systems next week.", "there", "their", "its", "it's", 3);
        addQuestion(q75);
        Question q76 = new Question("Clara ___________ three thousand words for her essay.", "has wrote", "have wrote", "have written", "has written", 4);
        addQuestion(q76);
        Question q77 = new Question("You have too many _______ but few time to prove you’re right.", "hypothesis", "hypotheses", "hyphothesises", "hypothesess", 2);
        addQuestion(q77);
        Question q78 = new Question("Neither Sarah nor Tina _______ the crime yesterday.", "witness", "witnesses", "witnessed", "witnessing", 3);
        addQuestion(q78);
        Question q79 = new Question("You do like going to the party alone. _____ you?", "Does", "Doesn't", "Do", "Don't", 4);
        addQuestion(q79);
        Question q80 = new Question("We had our house _______ in yellow.", "painting", "painted", "paint", "to paint", 2);
        addQuestion(q80);
        Question q81 = new Question("He has been exercising but his immune system was steadily _________.", "weak", "weaken", "weakened", "weakening", 4);
        addQuestion(q81);
        Question q82 = new Question(" I was ______ that the weather would be sunny and we would be able to enjoy our swimming.", "hopeless", "hopeful", "hopelike", "hopely", 2);
        addQuestion(q82);
        Question q83 = new Question(" I think it’s not a great idea. I totally ______.", "misagree", "unagree", "inagree", "disagree", 4);
        addQuestion(q83);
        Question q84 = new Question("So many ___________ I found in the library, now I’m ready to report.", "information", "informations", "infoes", "infos", 1);
        addQuestion(q84);
        Question q85 = new Question("My grandpa always feed his flock of _______ early in the morning.", "sheeps", "sheep", "ships", "ship", 2);
        addQuestion(q85);
        Question q86 = new Question(" Flight Z735 ______ yesterday. 350 passengers died in that accident.", "crush", "crushed", "crash", "crashed", 4);
        addQuestion(q86);
        Question q87 = new Question("Happy memories are always remembered, not ________.", "forget", "forgets", "forgot", "forgotten", 4);
        addQuestion(q87);
        Question q88 = new Question("There is a ________ message when you look closely at her painting.", "hid", "hide", "hided", "hidden", 4);
        addQuestion(q88);

        //
        Question q89 = new Question("Which department of an office is responsible for hiring new personnel?", "Office of the President ", "Accounting Department", "Logistic and Supply", "Human Resource Department", 4);
        addQuestion(q89);
        Question q90 = new Question("Which computer program should you go if you want to email a company?", "Word", "Excel", "Outlook", "Powerpoint", 3);
        addQuestion(q90);
        Question q91 = new Question(" This is a telephonic transmission of scanned documents of texts and images to a telephone number connected to a printer.", "Photocopying Machine", "Fax Machine", "Typewriter", "Inkjet Printer", 2);
        addQuestion(q91);
        Question q92 = new Question("The chief financial officer is responsible for the financial matters and financial management of a corporation, she is also known as the _______.", "Auditor", "Treasurer", "Chief Executive Officer", "Manager", 2);
        addQuestion(q92);
        Question q93 = new Question("Which department of a company is responsible for cash register operations and payment processing?", "Cashier", "Billing", "Accounting", "Budget", 1);
        addQuestion(q93);
        Question q94 = new Question(" All of the following items are found in the Official Receipt form except _____.", "Name and address of the buyer", " Signature of the recipient", "Quantity of the items paid", "Credit Card Number of the customer", 1);
        addQuestion(q94);
        Question q95 = new Question(" The method of indexing and filing where names are in alphabetized order.", "Geographic", "Numeric", "Metric", "Alphabetic", 4);
        addQuestion(q95);
        Question q96 = new Question("Which is the best way to address a correspondence for the President of the Philippines?", "His Excellency Rodrigo Duterte", "His Excellency President Rodrigo Duterte", "President Rodrigo Duterte", "President Digong", 2);
        addQuestion(q96);
        Question q97 = new Question(" How do you address the Queen of England when you talk about her?", "Her Highness the Queen", "Her Majesty Queen Elizabeth II", "Queen Elizabeth II her Highness", "Queen Elizabeth II her Majesty", 2);
        addQuestion(q97);
        Question q98 = new Question("Your boss asked you to send her a soft copy of your latest résumé. An example of a soft copy is:", "A print out copy usually in a paper", "Original copy written in a paper", "A copy saved in a computer and sent through email", "A copy from a Xerox machine", 3);
        addQuestion(q98);
        Question q99 = new Question("When a company asked you to submit your latest CV, what does CV stand for?", "Curriculum Vitum", "Curriculum Virtue", "Curriculum Vitae", "Curriculum Vital", 3);
        addQuestion(q99);
        Question q100 = new Question("It is the section of Accounting Department in a company that records goods and services that it receives and the payments it owes.", "Budget", "Payroll", "Accounts Payable and Receivable", "Inventory", 3);
        addQuestion(q100);
        Question q101 = new Question(" Which of the following is not a function of Accounting Department in a big corporation?", "Prepare Interim Financial Statements", "Inventory Management", "Bank Reconciliation", "Internal and External Auditing", 4);
        addQuestion(q101);
        Question q102= new Question("He is the highest ranking executive manager in a corporation and he is the top person in command in an organization.", "Chief Financial Executive", "Chief Executive Officer", "Executive Admin. Officer", "Chief Executive Assistant", 2);
        addQuestion(q102);
        Question q103 = new Question("Which of the following is not a responsibility of a clerical worker?", "Marketing and promotion for customers", "Filing and updating purchase orders", "Updating and billing buyer’s account", "Answering business emails", 1);
        addQuestion(q103);
        Question q104 = new Question("How much is the present Value-Added-Tax in the Philippines?", "12% of gross profit", "12% of cost of goods sold", "12% of gross sales", "12% of net income", 3);
        addQuestion(q104);
        Question q105 = new Question("This department of the company is responsible for preparing and updating customers’ accounts:", "Purchasing section", "Cashier section", "Billing Section", "Releasing section", 3);
        addQuestion(q105);
        Question q106 = new Question("This is a type of document issued by a seller to a buyer relating to a sale transaction and indicating the products, quantities and prices sold to the buyer.", "Check voucher", "Purchase order", "Delivery receipt", "Sales invoice", 4);
        addQuestion(q106);
        Question q107 = new Question("Which of the following is not a usual document used in a sales company?", "Form 137", "Delivery receipt", "Sales invoice", "Purchase order", 1);
        addQuestion(q107);
        Question q108 = new Question("One of the responsibilities of a clerical job is answering and tending phone calls. Which is the best way to answer a phone call in a company?", "Say “Hello,” and wait for the caller to speak.", "Run and get a pen and notebook then pick up the phone.", "Answer the phone politely and give your department or company name.", "Wait for fellow employees to answer the phone.", 3);
        addQuestion(q108);

        //
        Question q109 = new Question("A. One effective way is to diversify his funds to different investments like real estate, stocks and money instruments like bonds and trust funds.\n" +
                "B. It is always best to expand money to different investment wheels.\n" +
                "C. A wise investor must not put all his eggs in one basket.\n" +
                "D. He should always consider the risks involved in investing his money.", "CBAD ", "CBDA", " CDAB", "CDBA", 2);
        addQuestion(q109);
        Question q110 = new Question("A. It is very vital to have social media presence however personal blogs serve as web domains.\n" +
                "B. Most people including celebrities and businessmen have blogs nowadays.\n" +
                "C. Therefore, building them will help anyone in promoting himself or his business.\n" +
                "D. Apparently blogs are like our offices only they are in the internet.", "BDAC", "BADC", "BACD", " BDCA", 3);
        addQuestion(q110);
        Question q111 = new Question("A. The basic steps in building a website are easy to remember and registering a domain name is the usual priority.\n" +
                "B. Designing a layout will come after that.\n" +
                "C. Finally, adding more content and social media presence are required to keep your site active.\n" +
                "D. Then you need a hosting provider to host your site’s content in the World Wide Web.", "ABCD", "ADBC", "ACBD", "ADCB", 1);
        addQuestion(q111);
        Question q112 = new Question("A. Speaking in English every day is also proven effective.\n" +
                "B. Another way is watching English movies and TV shows particularly with English subtitles.\n" +
                "C. Reading articles in books, newspapers, and magazines is just among the helpful ways.\n" +
                "D. There are many ways to improve and develop English proficiency.", "DCBA", "DACB", "DABC    ", "DCAB", 2);
        addQuestion(q112);
        Question q113 = new Question("A. Others don’t realize yet what to pursue because they have many dreams.\n" +
                "B. Finding the right course in college is one of the most challenging decisions anyone can make.\n" +
                "C. Some people want to pursue their dreams ever since they were just little.\n" +
                "D. Indeed destiny is a matter of choice.", "BDAC", "BCDA", "BADC   ", "BCAD", 4);
        addQuestion(q113);
        Question q114 = new Question("A. While passport, airline tickets and valid IDs are required, proof of financial capacity may be required for visa application.\n" +
                "B. Many Filipinos rejoiced hearing that good news.\n" +
                "C. The Bureau of Immigration announced recently that proof of financial capacity is not a primary requirement at the airport.\n" +
                "D. Positive points go to the bureau for this.", "CBAD", "CADB", " CABD", "CBDA", 2);
        addQuestion(q114);
        Question q115 = new Question("A. This will be one of your tickets to land a job in the government.\n" +
                "B. That is why many people apply to take the Career Service examination.\n" +
                "C. If you passed the exam, you will get a certificate of eligibility.\n" +
                "D. Career Service Eligibility is a major requirement to apply for a job position in the government.", "DCBA ", "DBAC ", "DBCA ", "DCAB", 1);
        addQuestion(q115);
        Question q116 = new Question("A. Your passport will arrive in 7 days if you choose the rush processing.\n" +
                "B. Getting a passport is faster nowadays.\n" +
                "C. Now, it only takes about 10 working days.\n" +
                "D. Compared before, it would take about a month for the regular processing.", "BCAD  ", "BDCA", "BADC", "BACD", 2);
        addQuestion(q116);
        Question q117 = new Question("A. Facebook has been the number one social network in the web and the world for quite long now.\n" +
                "B. Mobile instant messaging apps are also dominating social presence in the internet.\n" +
                "C. After many acquisitions, Facebook bought Instagram, one of the fastest growing photo sharing networks.\n" +
                "D. Because of that, Facebook acquired WhatsApp, a leading instant chat platform like Kakaotalk.", "ACBD", "ABCD ", "ADCB ", "ADBC", 3);
        addQuestion(q117);
        Question q118 = new Question("A. They will help you to purchase through zero-interest installment schemes.\n" +
                "B. Thus, you must be wise and pay in full if you want to avoid never-ending debts.\n" +
                "C. Credit cards are helpful if you know how and when to use them wisely.\n" +
                "D. However, they will produce interests from interests if you didn’t pay the whole amount at the due date.", "CDBA", "CABD", "CDAB  ", "CADB", 1);
        addQuestion(q118);



    }


    private void addQuestion(Question question) {
        ContentValues Content_val = new ContentValues();
        Content_val.put(QuestionTables.COLUMN_QUESTION, question.getQuestion());
        Content_val.put(QuestionTables.COLUMN_OPTION1, question.getOption1());
        Content_val.put(QuestionTables.COLUMN_OPTION2, question.getOption2());
        Content_val.put(QuestionTables.COLUMN_OPTION3, question.getOption3());
        Content_val.put(QuestionTables.COLUMN_OPTION4, question.getOption4());
        Content_val.put(QuestionTables.COLUMN_ANSWER_NR, question.getAnswer());
        db.insert(QuestionTables.TABLE_NAME, null, Content_val);
    }

    public List<Question> getAllQuestions() {
        List<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery(" SELECT * FROM " + QuestionTables.TABLE_NAME, null);
        if (c.moveToFirst()) {
            do {
                Question questions = new Question();
                questions.setQuestion((c.getString(c.getColumnIndex(QuestionTables.COLUMN_QUESTION))));
                questions.setOption1((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION1))));
                questions.setOption2((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION2))));
                questions.setOption3((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION3))));
                questions.setOption4((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION4))));
                questions.setAnswer((c.getInt(c.getColumnIndex(QuestionTables.COLUMN_ANSWER_NR))));
                questionList.add(questions);
            } while (c.moveToNext());
        }

        c.close();
        return questionList;

    }

}
