package com.example.siaappa50;
//
//Analogy and Logic
//
//
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Collections;
import java.util.Locale;

public class Exam_Question extends AppCompatActivity {
    private static final String EXTRA_SCORE = "extraScore";
    private static final long COUNT_DOWN_MILLIS = 650000;

    TextView Question1_field, Question1_item,
             Question2_field, Question2_item,
             Question3_field, Question3_item,
             Question4_field, Question4_item,
             Question5_field, Question5_item,
             Question6_field, Question6_item,
             Question7_field, Question7_item,
             Question8_field, Question8_item,
             Question9_field, Question9_item,
             Question10_field, Question10_item,
             Question11_field, Question11_item,
             Question12_field, Question12_item,
             Question13_field, Question13_item,
             Question14_field, Question14_item,
             Question15_field, Question15_item,
             Question16_field, Question16_item,
             Question17_field, Question17_item,
             Question18_field, Question18_item,
             Question19_field, Question19_item,
             Question20_field, Question20_item,
             Question21_field, Question21_item,
             Question22_field, Question22_item,
             Question23_field, Question23_item,
             Question24_field, Question24_item,
             Question25_field, Question25_item,
             Question26_field, Question26_item,
             Question27_field, Question27_item,
             Question28_field, Question28_item,
             Question29_field, Question29_item,
            Question30_field, Question30_item,
            Question31_field, Question31_item,
            Question32_field, Question32_item,
            Question33_field, Question33_item,
            Question34_field, Question34_item,
            Question35_field, Question35_item,
            Question36_field, Question36_item,
            Question37_field, Question37_item,
            Question38_field, Question38_item,
            Question39_field, Question39_item,
            Question40_field, Question40_item,
            Question41_field, Question41_item,
            Question42_field, Question42_item,
            Question43_field, Question43_item,
            Question44_field, Question44_item,
            Question45_field, Question45_item,
            Question46_field, Question46_item,
            Question47_field, Question47_item,
            Question48_field, Question48_item,
            Question49_field, Question49_item,
            Question50_field, Question50_item,
            Question51_field, Question51_item,
            Question52_field, Question52_item,
            Question53_field, Question53_item,
            Question54_field, Question54_item,
            Question55_field, Question55_item,
            Question56_field, Question56_item,
            Question57_field, Question57_item,
            Question58_field, Question58_item,
            Question59_field, Question59_item,
            Question60_field, Question60_item,
            Question61_field, Question61_item,
            Question62_field, Question62_item,
            Question63_field, Question63_item,
            Question64_field, Question64_item,
            Question65_field, Question65_item,
            Question66_field, Question66_item,
            Question67_field, Question67_item,
            Question68_field, Question68_item,
            Question69_field, Question69_item,
            Question70_field, Question70_item,
            Question71_field, Question71_item,
            Question72_field, Question72_item,
            Question73_field, Question73_item,
            Question74_field, Question74_item,
            Question75_field, Question75_item,
            Question76_field, Question76_item,
            Question77_field, Question77_item,
            Question78_field, Question78_item,
            Question79_field, Question79_item,
            Question80_field, Question80_item,
            Question81_field, Question81_item,
            Question82_field, Question82_item,
            Question83_field, Question83_item,
            Question84_field, Question84_item,
            Question85_field, Question85_item,
            Question86_field, Question86_item,
            Question87_field, Question87_item,
            Question88_field, Question88_item,
            Question89_field, Question89_item,
            Question90_field, Question90_item,
            Question91_field, Question91_item,
            Question92_field, Question92_item,
            Question93_field, Question93_item,
            Question94_field, Question94_item,
            Question95_field, Question95_item,
            Question96_field, Question96_item,
            Question97_field, Question97_item,
            Question98_field, Question98_item,
            Question99_field, Question99_item,
            Question100_field, Question100_item,
            Question101_field, Question101_item,
            Question102_field, Question102_item,
            Question103_field, Question103_item,
            Question104_field, Question104_item,
            Question105_field, Question105_item,
            Question106_field, Question106_item,
            Question107_field, Question107_item,
            Question108_field, Question108_item,
            Question109_field, Question109_item,
             txt_time,txt_score;
    RadioButton
            Question1_btn1,Question1_btn2,Question1_btn3,Question1_btn4,
            Question2_btn1,Question2_btn2,Question2_btn3,Question2_btn4,
            Question3_btn1,Question3_btn2,Question3_btn3,Question3_btn4,
            Question4_btn1,Question4_btn2,Question4_btn3,Question4_btn4,
            Question5_btn1,Question5_btn2,Question5_btn3,Question5_btn4,
            Question6_btn1,Question6_btn2,Question6_btn3,Question6_btn4,
            Question7_btn1,Question7_btn2,Question7_btn3,Question7_btn4,
            Question8_btn1,Question8_btn2,Question8_btn3,Question8_btn4,
            Question9_btn1,Question9_btn2,Question9_btn3,Question9_btn4,
            Question10_btn1,Question10_btn2,Question10_btn3,Question10_btn4,
            Question11_btn1,Question11_btn2,Question11_btn3,Question11_btn4,
            Question12_btn1,Question12_btn2,Question12_btn3,Question12_btn4,
            Question13_btn1,Question13_btn2,Question13_btn3,Question13_btn4,
            Question14_btn1,Question14_btn2,Question14_btn3,Question14_btn4,
            Question15_btn1,Question15_btn2,Question15_btn3,Question15_btn4,
            Question16_btn1,Question16_btn2,Question16_btn3,Question16_btn4,
            Question17_btn1,Question17_btn2,Question17_btn3,Question17_btn4,
            Question18_btn1,Question18_btn2,Question18_btn3,Question18_btn4,
            Question19_btn1,Question19_btn2,Question19_btn3,Question19_btn4,
            Question20_btn1,Question20_btn2,Question20_btn3,Question20_btn4,
            Question21_btn1,Question21_btn2,Question21_btn3,Question21_btn4,
            Question22_btn1,Question22_btn2,Question22_btn3,Question22_btn4,
            Question23_btn1,Question23_btn2,Question23_btn3,Question23_btn4,
            Question24_btn1,Question24_btn2,Question24_btn3,Question24_btn4,
            Question25_btn1,Question25_btn2,Question25_btn3,Question25_btn4,
            Question26_btn1,Question26_btn2,Question26_btn3,Question26_btn4,
            Question27_btn1,Question27_btn2,Question27_btn3,Question27_btn4,
            Question28_btn1,Question28_btn2,Question28_btn3,Question28_btn4,
            Question29_btn1,Question29_btn2,Question29_btn3,Question29_btn4,
            Question30_btn1,Question30_btn2,Question30_btn3,Question30_btn4,
            Question31_btn1,Question31_btn2,Question31_btn3,Question31_btn4,
            Question32_btn1,Question32_btn2,Question32_btn3,Question32_btn4,
            Question33_btn1,Question33_btn2,Question33_btn3,Question33_btn4,
            Question34_btn1,Question34_btn2,Question34_btn3,Question34_btn4,
            Question35_btn1,Question35_btn2,Question35_btn3,Question35_btn4,
            Question36_btn1,Question36_btn2,Question36_btn3,Question36_btn4,
            Question37_btn1,Question37_btn2,Question37_btn3,Question37_btn4,
            Question38_btn1,Question38_btn2,Question38_btn3,Question38_btn4,
            Question39_btn1,Question39_btn2,Question39_btn3,Question39_btn4,
            Question40_btn1,Question40_btn2,Question40_btn3,Question40_btn4,
            Question41_btn1,Question41_btn2,Question41_btn3,Question41_btn4,
            Question42_btn1,Question42_btn2,Question42_btn3,Question42_btn4,
            Question43_btn1,Question43_btn2,Question43_btn3,Question43_btn4,
            Question44_btn1,Question44_btn2,Question44_btn3,Question44_btn4,
            Question45_btn1,Question45_btn2,Question45_btn3,Question45_btn4,
            Question46_btn1,Question46_btn2,Question46_btn3,Question46_btn4,
            Question47_btn1,Question47_btn2,Question47_btn3,Question47_btn4,
            Question48_btn1,Question48_btn2,Question48_btn3,Question48_btn4,
            Question49_btn1,Question49_btn2,Question49_btn3,Question49_btn4,
            Question50_btn1,Question50_btn2,Question50_btn3,Question50_btn4,
            Question51_btn1,Question51_btn2,Question51_btn3,Question51_btn4,
            Question52_btn1,Question52_btn2,Question52_btn3,Question52_btn4,
            Question53_btn1,Question53_btn2,Question53_btn3,Question53_btn4,
            Question54_btn1,Question54_btn2,Question54_btn3,Question54_btn4,
            Question55_btn1,Question55_btn2,Question55_btn3,Question55_btn4,
            Question56_btn1,Question56_btn2,Question56_btn3,Question56_btn4,
            Question57_btn1,Question57_btn2,Question57_btn3,Question57_btn4,
            Question58_btn1,Question58_btn2,Question58_btn3,Question58_btn4,
            Question59_btn1,Question59_btn2,Question59_btn3,Question59_btn4,
            Question60_btn1,Question60_btn2,Question60_btn3,Question60_btn4,
            Question61_btn1,Question61_btn2,Question61_btn3,Question61_btn4,
            Question62_btn1,Question62_btn2,Question62_btn3,Question62_btn4,
            Question63_btn1,Question63_btn2,Question63_btn3,Question63_btn4,
            Question64_btn1,Question64_btn2,Question64_btn3,Question64_btn4,
            Question65_btn1,Question65_btn2,Question65_btn3,Question65_btn4,
            Question66_btn1,Question66_btn2,Question66_btn3,Question66_btn4,
            Question67_btn1,Question67_btn2,Question67_btn3,Question67_btn4,
            Question68_btn1,Question68_btn2,Question68_btn3,Question68_btn4,
            Question69_btn1,Question69_btn2,Question69_btn3,Question69_btn4,
            Question70_btn1,Question70_btn2,Question70_btn3,Question70_btn4,
            Question71_btn1,Question71_btn2,Question71_btn3,Question71_btn4,
            Question72_btn1,Question72_btn2,Question72_btn3,Question72_btn4,
            Question73_btn1,Question73_btn2,Question73_btn3,Question73_btn4,
            Question74_btn1,Question74_btn2,Question74_btn3,Question74_btn4,
            Question75_btn1,Question75_btn2,Question75_btn3,Question75_btn4,
            Question76_btn1,Question76_btn2,Question76_btn3,Question76_btn4,
            Question77_btn1,Question77_btn2,Question77_btn3,Question77_btn4,
            Question78_btn1,Question78_btn2,Question78_btn3,Question78_btn4,
            Question79_btn1,Question79_btn2,Question79_btn3,Question79_btn4,
            Question80_btn1,Question80_btn2,Question80_btn3,Question80_btn4,
            Question81_btn1,Question81_btn2,Question81_btn3,Question81_btn4,
            Question82_btn1,Question82_btn2,Question82_btn3,Question82_btn4,
            Question83_btn1,Question83_btn2,Question83_btn3,Question83_btn4,
            Question84_btn1,Question84_btn2,Question84_btn3,Question84_btn4,
            Question85_btn1,Question85_btn2,Question85_btn3,Question85_btn4,
            Question86_btn1,Question86_btn2,Question86_btn3,Question86_btn4,
            Question87_btn1,Question87_btn2,Question87_btn3,Question87_btn4,
            Question88_btn1,Question88_btn2,Question88_btn3,Question88_btn4,
            Question89_btn1,Question89_btn2,Question89_btn3,Question89_btn4,
            Question90_btn1,Question90_btn2,Question90_btn3,Question90_btn4,
            Question91_btn1,Question91_btn2,Question91_btn3,Question91_btn4,
            Question92_btn1,Question92_btn2,Question92_btn3,Question92_btn4,
            Question93_btn1,Question93_btn2,Question93_btn3,Question93_btn4,
            Question94_btn1,Question94_btn2,Question94_btn3,Question94_btn4,
            Question95_btn1,Question95_btn2,Question95_btn3,Question95_btn4,
            Question96_btn1,Question96_btn2,Question96_btn3,Question96_btn4,
            Question97_btn1,Question97_btn2,Question97_btn3,Question97_btn4,
            Question98_btn1,Question98_btn2,Question98_btn3,Question98_btn4,
            Question99_btn1,Question99_btn2,Question99_btn3,Question99_btn4,
            Question100_btn1,Question100_btn2,Question100_btn3,Question100_btn4,
            Question101_btn1,Question101_btn2,Question101_btn3,Question101_btn4,
            Question102_btn1,Question102_btn2,Question102_btn3,Question102_btn4,
            Question103_btn1,Question103_btn2,Question103_btn3,Question103_btn4,
            Question104_btn1,Question104_btn2,Question104_btn3,Question104_btn4,
            Question105_btn1,Question105_btn2,Question105_btn3,Question105_btn4,
            Question106_btn1,Question106_btn2,Question106_btn3,Question106_btn4,
            Question107_btn1,Question107_btn2,Question107_btn3,Question107_btn4,
            Question108_btn1,Question108_btn2,Question108_btn3,Question108_btn4,
            Question109_btn1,Question109_btn2,Question109_btn3,Question109_btn4;
            Button btnsubmit;
    RadioGroup
            Question1_Rgroup,Question2_Rgroup,Question3_Rgroup,Question4_Rgroup,
            Question5_Rgroup,Question6_Rgroup,Question7_Rgroup,Question8_Rgroup,
            Question9_Rgroup,Question10_Rgroup,Question11_Rgroup,Question12_Rgroup,
            Question13_Rgroup,Question14_Rgroup,Question15_Rgroup,Question16_Rgroup,
            Question17_Rgroup,Question18_Rgroup,Question19_Rgroup,Question20_Rgroup,
            Question21_Rgroup,Question22_Rgroup,Question23_Rgroup,Question24_Rgroup,
            Question25_Rgroup,Question26_Rgroup,Question27_Rgroup,Question28_Rgroup,
            Question29_Rgroup,Question30_Rgroup,Question31_Rgroup,Question32_Rgroup,
            Question33_Rgroup,Question34_Rgroup,Question35_Rgroup,Question36_Rgroup,
            Question37_Rgroup,Question38_Rgroup,Question39_Rgroup,Question40_Rgroup,
            Question41_Rgroup,Question42_Rgroup,Question43_Rgroup,Question44_Rgroup,
            Question45_Rgroup,Question46_Rgroup,Question47_Rgroup,Question48_Rgroup,
            Question49_Rgroup,Question50_Rgroup,Question51_Rgroup,Question52_Rgroup,
            Question53_Rgroup,Question54_Rgroup,Question55_Rgroup,Question56_Rgroup,
            Question57_Rgroup,Question58_Rgroup,Question59_Rgroup,Question60_Rgroup,
            Question61_Rgroup,Question62_Rgroup,Question63_Rgroup,Question64_Rgroup,
            Question65_Rgroup,Question66_Rgroup,Question67_Rgroup,Question68_Rgroup,
            Question69_Rgroup,Question70_Rgroup,Question71_Rgroup,Question72_Rgroup,
            Question73_Rgroup,Question74_Rgroup,Question75_Rgroup,Question76_Rgroup,
            Question77_Rgroup,Question78_Rgroup,Question79_Rgroup,Question80_Rgroup,
            Question81_Rgroup,Question82_Rgroup,Question83_Rgroup,Question84_Rgroup,
            Question85_Rgroup,Question86_Rgroup,Question87_Rgroup,Question88_Rgroup,
            Question89_Rgroup,Question90_Rgroup,Question91_Rgroup,Question92_Rgroup,
            Question93_Rgroup,Question94_Rgroup,Question95_Rgroup,Question96_Rgroup,
            Question97_Rgroup,Question98_Rgroup,Question99_Rgroup,Question100_Rgroup,
            Question101_Rgroup,Question102_Rgroup, Question103_Rgroup,Question104_Rgroup,
            Question105_Rgroup,Question106_Rgroup, Question107_Rgroup,Question108_Rgroup,
            Question109_Rgroup;


    private static long back_pressed;
    private List<Question> questionlist;


    private int counter;
    private int totalcount;
    private Question currentquestion;

    private ColorStateList textDefualt;
    private CountDownTimer cdtimer;
    private long timeleft;

    private int score = 0;
    private boolean answer;

    Integer answerKeys [] = new Integer[counter];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exam__question);

        txt_score = findViewById(R.id.txt_score);
        txt_time = findViewById(R.id.Question_Timer);
        btnsubmit = findViewById(R.id.Submit);
        //QUESTION1
        Question1_Rgroup = findViewById(R.id.Question1_Rgroup);
        Question1_field = findViewById(R.id.Question1_field);
        Question1_item = findViewById(R.id.Question1_item);
        Question1_btn1 = findViewById(R.id.Question1_btn1);
        Question1_btn2 = findViewById(R.id.Question1_btn2);
        Question1_btn3 = findViewById(R.id.Question1_btn3);
        Question1_btn4 = findViewById(R.id.Question1_btn4);
        //QUESTION2
        Question2_Rgroup = findViewById(R.id.Question2_Rgroup);
        Question2_field = findViewById(R.id.Question2_field);
        Question2_item = findViewById(R.id.Question2_item);
        Question2_btn1 = findViewById(R.id.Question2_btn1);
        Question2_btn2 = findViewById(R.id.Question2_btn2);
        Question2_btn3 = findViewById(R.id.Question2_btn3);
        Question2_btn4 = findViewById(R.id.Question2_btn4);
        //QUESTION3
        Question3_Rgroup = findViewById(R.id.Question3_Rgroup);
        Question3_field = findViewById(R.id.Question3_field);
        Question3_item = findViewById(R.id.Question3_item);
        Question3_btn1 = findViewById(R.id.Question3_btn1);
        Question3_btn2 = findViewById(R.id.Question3_btn2);
        Question3_btn3 = findViewById(R.id.Question3_btn3);
        Question3_btn4 = findViewById(R.id.Question3_btn4);
        //QUESTION4
        Question4_Rgroup = findViewById(R.id.Question4_Rgroup);
        Question4_field = findViewById(R.id.Question4_field);
        Question4_item = findViewById(R.id.Question4_item);
        Question4_btn1 = findViewById(R.id.Question4_btn1);
        Question4_btn2 = findViewById(R.id.Question4_btn2);
        Question4_btn3 = findViewById(R.id.Question4_btn3);
        Question4_btn4 = findViewById(R.id.Question4_btn4);
        //QUESTION5
        Question5_Rgroup = findViewById(R.id.Question5_Rgroup);
        Question5_field = findViewById(R.id.Question5_field);
        Question5_item = findViewById(R.id.Question5_item);
        Question5_btn1 = findViewById(R.id.Question5_btn1);
        Question5_btn2 = findViewById(R.id.Question5_btn2);
        Question5_btn3 = findViewById(R.id.Question5_btn3);
        Question5_btn4 = findViewById(R.id.Question5_btn4);
        //QUESTION6
        Question6_Rgroup = findViewById(R.id.Question6_Rgroup);
        Question6_field = findViewById(R.id.Question6_field);
        Question6_item = findViewById(R.id.Question6_item);
        Question6_btn1 = findViewById(R.id.Question6_btn1);
        Question6_btn2 = findViewById(R.id.Question6_btn2);
        Question6_btn3 = findViewById(R.id.Question6_btn3);
        Question6_btn4 = findViewById(R.id.Question6_btn4);
        //QUESTION7
        Question7_Rgroup = findViewById(R.id.Question7_Rgroup);
        Question7_field = findViewById(R.id.Question7_field);
        Question7_item = findViewById(R.id.Question7_item);
        Question7_btn1 = findViewById(R.id.Question7_btn1);
        Question7_btn2 = findViewById(R.id.Question7_btn2);
        Question7_btn3 = findViewById(R.id.Question7_btn3);
        Question7_btn4 = findViewById(R.id.Question7_btn4);
        //QUESTION8
        Question8_Rgroup = findViewById(R.id.Question8_Rgroup);
        Question8_field = findViewById(R.id.Question8_field);
        Question8_item = findViewById(R.id.Question8_item);
        Question8_btn1 = findViewById(R.id.Question8_btn1);
        Question8_btn2 = findViewById(R.id.Question8_btn2);
        Question8_btn3 = findViewById(R.id.Question8_btn3);
        Question8_btn4 = findViewById(R.id.Question8_btn4);
        //QUESTION9
        Question9_Rgroup = findViewById(R.id.Question9_Rgroup);
        Question9_field = findViewById(R.id.Question9_field);
        Question9_item = findViewById(R.id.Question9_item);
        Question9_btn1 = findViewById(R.id.Question9_btn1);
        Question9_btn2 = findViewById(R.id.Question9_btn2);
        Question9_btn3 = findViewById(R.id.Question9_btn3);
        Question9_btn4 = findViewById(R.id.Question9_btn4);
        //QUESTION10
        Question10_Rgroup = findViewById(R.id.Question10_Rgroup);
        Question10_field = findViewById(R.id.Question10_field);
        Question10_item = findViewById(R.id.Question10_item);
        Question10_btn1 = findViewById(R.id.Question10_btn1);
        Question10_btn2 = findViewById(R.id.Question10_btn2);
        Question10_btn3 = findViewById(R.id.Question10_btn3);
        Question10_btn4 = findViewById(R.id.Question10_btn4);
        //QUEStion11
        Question11_Rgroup = findViewById(R.id.Question11_Rgroup);
        Question11_field = findViewById(R.id.Question11_field);
        Question11_item = findViewById(R.id.Question11_item);
        Question11_btn1 = findViewById(R.id.Question11_btn1);
        Question11_btn2 = findViewById(R.id.Question11_btn2);
        Question11_btn3 = findViewById(R.id.Question11_btn3);
        Question11_btn4 = findViewById(R.id.Question11_btn4);
        //QUEStion12
        Question12_Rgroup = findViewById(R.id.Question12_Rgroup);
        Question12_field = findViewById(R.id.Question12_field);
        Question12_item = findViewById(R.id.Question12_item);
        Question12_btn1 = findViewById(R.id.Question12_btn1);
        Question12_btn2 = findViewById(R.id.Question12_btn2);
        Question12_btn3 = findViewById(R.id.Question12_btn3);
        Question12_btn4 = findViewById(R.id.Question12_btn4);
        //QUEStion13
        Question13_Rgroup = findViewById(R.id.Question13_Rgroup);
        Question13_field = findViewById(R.id.Question13_field);
        Question13_item = findViewById(R.id.Question13_item);
        Question13_btn1 = findViewById(R.id.Question13_btn1);
        Question13_btn2 = findViewById(R.id.Question13_btn2);
        Question13_btn3 = findViewById(R.id.Question13_btn3);
        Question13_btn4 = findViewById(R.id.Question13_btn4);
        //QUEStion14
        Question14_Rgroup = findViewById(R.id.Question14_Rgroup);
        Question14_field = findViewById(R.id.Question14_field);
        Question14_item = findViewById(R.id.Question14_item);
        Question14_btn1 = findViewById(R.id.Question14_btn1);
        Question14_btn2 = findViewById(R.id.Question14_btn2);
        Question14_btn3 = findViewById(R.id.Question14_btn3);
        Question14_btn4 = findViewById(R.id.Question14_btn4);
        //QUEStion15
        Question15_Rgroup = findViewById(R.id.Question15_Rgroup);
        Question15_field = findViewById(R.id.Question15_field);
        Question15_item = findViewById(R.id.Question15_item);
        Question15_btn1 = findViewById(R.id.Question15_btn1);
        Question15_btn2 = findViewById(R.id.Question15_btn2);
        Question15_btn3 = findViewById(R.id.Question15_btn3);
        Question15_btn4 = findViewById(R.id.Question15_btn4);
        //QUEStion16
        Question16_Rgroup = findViewById(R.id.Question16_Rgroup);
        Question16_field = findViewById(R.id.Question16_field);
        Question16_item = findViewById(R.id.Question16_item);
        Question16_btn1 = findViewById(R.id.Question16_btn1);
        Question16_btn2 = findViewById(R.id.Question16_btn2);
        Question16_btn3 = findViewById(R.id.Question16_btn3);
        Question16_btn4 = findViewById(R.id.Question16_btn4);
        //QUEStion17
        Question17_Rgroup = findViewById(R.id.Question17_Rgroup);
        Question17_field = findViewById(R.id.Question17_field);
        Question17_item = findViewById(R.id.Question17_item);
        Question17_btn1 = findViewById(R.id.Question17_btn1);
        Question17_btn2 = findViewById(R.id.Question17_btn2);
        Question17_btn3 = findViewById(R.id.Question17_btn3);
        Question17_btn4 = findViewById(R.id.Question17_btn4);
        //QUEStion18
        Question18_Rgroup = findViewById(R.id.Question18_Rgroup);
        Question18_field = findViewById(R.id.Question18_field);
        Question18_item = findViewById(R.id.Question18_item);
        Question18_btn1 = findViewById(R.id.Question18_btn1);
        Question18_btn2 = findViewById(R.id.Question18_btn2);
        Question18_btn3 = findViewById(R.id.Question18_btn3);
        Question18_btn4 = findViewById(R.id.Question18_btn4);
        //QUEStion19
        Question19_Rgroup = findViewById(R.id.Question19_Rgroup);
        Question19_field = findViewById(R.id.Question19_field);
        Question19_item = findViewById(R.id.Question19_item);
        Question19_btn1 = findViewById(R.id.Question19_btn1);
        Question19_btn2 = findViewById(R.id.Question19_btn2);
        Question19_btn3 = findViewById(R.id.Question19_btn3);
        Question19_btn4 = findViewById(R.id.Question19_btn4);
        //QUEStion20
        Question20_Rgroup = findViewById(R.id.Question20_Rgroup);
        Question20_field = findViewById(R.id.Question20_field);
        Question20_item = findViewById(R.id.Question20_item);
        Question20_btn1 = findViewById(R.id.Question20_btn1);
        Question20_btn2 = findViewById(R.id.Question20_btn2);
        Question20_btn3 = findViewById(R.id.Question20_btn3);
        Question20_btn4 = findViewById(R.id.Question20_btn4);
        //QUEStion21
        Question21_Rgroup = findViewById(R.id.Question21_Rgroup);
        Question21_field = findViewById(R.id.Question21_field);
        Question21_item = findViewById(R.id.Question21_item);
        Question21_btn1 = findViewById(R.id.Question21_btn1);
        Question21_btn2 = findViewById(R.id.Question21_btn2);
        Question21_btn3 = findViewById(R.id.Question21_btn3);
        Question21_btn4 = findViewById(R.id.Question21_btn4);
        //QUEStion22
        Question22_Rgroup = findViewById(R.id.Question22_Rgroup);
        Question22_field = findViewById(R.id.Question22_field);
        Question22_item = findViewById(R.id.Question22_item);
        Question22_btn1 = findViewById(R.id.Question22_btn1);
        Question22_btn2 = findViewById(R.id.Question22_btn2);
        Question22_btn3 = findViewById(R.id.Question22_btn3);
        Question22_btn4 = findViewById(R.id.Question22_btn4);
        //QUEStion23
        Question23_Rgroup = findViewById(R.id.Question23_Rgroup);
        Question23_field = findViewById(R.id.Question23_field);
        Question23_item = findViewById(R.id.Question23_item);
        Question23_btn1 = findViewById(R.id.Question23_btn1);
        Question23_btn2 = findViewById(R.id.Question23_btn2);
        Question23_btn3 = findViewById(R.id.Question23_btn3);
        Question23_btn4 = findViewById(R.id.Question23_btn4);
        //QUEStion24
        Question24_Rgroup = findViewById(R.id.Question24_Rgroup);
        Question24_field = findViewById(R.id.Question24_field);
        Question24_item = findViewById(R.id.Question24_item);
        Question24_btn1 = findViewById(R.id.Question24_btn1);
        Question24_btn2 = findViewById(R.id.Question24_btn2);
        Question24_btn3 = findViewById(R.id.Question24_btn3);
        Question24_btn4 = findViewById(R.id.Question24_btn4);
        //QUEStion25
        Question25_Rgroup = findViewById(R.id.Question25_Rgroup);
        Question25_field = findViewById(R.id.Question25_field);
        Question25_item = findViewById(R.id.Question25_item);
        Question25_btn1 = findViewById(R.id.Question25_btn1);
        Question25_btn2 = findViewById(R.id.Question25_btn2);
        Question25_btn3 = findViewById(R.id.Question25_btn3);
        Question25_btn4 = findViewById(R.id.Question25_btn4);
        //QUEStion26
        Question26_Rgroup = findViewById(R.id.Question26_Rgroup);
        Question26_field = findViewById(R.id.Question26_field);
        Question26_item = findViewById(R.id.Question26_item);
        Question26_btn1 = findViewById(R.id.Question26_btn1);
        Question26_btn2 = findViewById(R.id.Question26_btn2);
        Question26_btn3 = findViewById(R.id.Question26_btn3);
        Question26_btn4 = findViewById(R.id.Question26_btn4);
        //QUEStion27
        Question27_Rgroup = findViewById(R.id.Question27_Rgroup);
        Question27_field = findViewById(R.id.Question27_field);
        Question27_item = findViewById(R.id.Question27_item);
        Question27_btn1 = findViewById(R.id.Question27_btn1);
        Question27_btn2 = findViewById(R.id.Question27_btn2);
        Question27_btn3 = findViewById(R.id.Question27_btn3);
        Question27_btn4 = findViewById(R.id.Question27_btn4);
        //QUEStion28
        Question28_Rgroup = findViewById(R.id.Question28_Rgroup);
        Question28_field = findViewById(R.id.Question28_field);
        Question28_item = findViewById(R.id.Question28_item);
        Question28_btn1 = findViewById(R.id.Question28_btn1);
        Question28_btn2 = findViewById(R.id.Question28_btn2);
        Question28_btn3 = findViewById(R.id.Question28_btn3);
        Question28_btn4 = findViewById(R.id.Question28_btn4);
        //QUEStion29
        Question29_Rgroup = findViewById(R.id.Question29_Rgroup);
        Question29_field = findViewById(R.id.Question29_field);
        Question29_item = findViewById(R.id.Question29_item);
        Question29_btn1 = findViewById(R.id.Question29_btn1);
        Question29_btn2 = findViewById(R.id.Question29_btn2);
        Question29_btn3 = findViewById(R.id.Question29_btn3);
        Question29_btn4 = findViewById(R.id.Question29_btn4);
        //Question30
        Question30_Rgroup = findViewById(R.id.Question30_Rgroup);
        Question30_field = findViewById(R.id.Question30_field);
        Question30_item = findViewById(R.id.Question30_item);
        Question30_btn1 = findViewById(R.id.Question30_btn1);
        Question30_btn2 = findViewById(R.id.Question30_btn2);
        Question30_btn3 = findViewById(R.id.Question30_btn3);
        Question30_btn4 = findViewById(R.id.Question30_btn4);
        //QUEStion31
        Question31_Rgroup = findViewById(R.id.Question31_Rgroup);
        Question31_field = findViewById(R.id.Question31_field);
        Question31_item = findViewById(R.id.Question31_item);
        Question31_btn1 = findViewById(R.id.Question31_btn1);
        Question31_btn2 = findViewById(R.id.Question31_btn2);
        Question31_btn3 = findViewById(R.id.Question31_btn3);
        Question31_btn4 = findViewById(R.id.Question31_btn4);
        //QUEStion32
        Question32_Rgroup = findViewById(R.id.Question32_Rgroup);
        Question32_field = findViewById(R.id.Question32_field);
        Question32_item = findViewById(R.id.Question32_item);
        Question32_btn1 = findViewById(R.id.Question32_btn1);
        Question32_btn2 = findViewById(R.id.Question32_btn2);
        Question32_btn3 = findViewById(R.id.Question32_btn3);
        Question32_btn4 = findViewById(R.id.Question32_btn4);
        //QUEStion33
        Question33_Rgroup = findViewById(R.id.Question33_Rgroup);
        Question33_field = findViewById(R.id.Question33_field);
        Question33_item = findViewById(R.id.Question33_item);
        Question33_btn1 = findViewById(R.id.Question33_btn1);
        Question33_btn2 = findViewById(R.id.Question33_btn2);
        Question33_btn3 = findViewById(R.id.Question33_btn3);
        Question33_btn4 = findViewById(R.id.Question33_btn4);
        //QUEStion34
        Question34_Rgroup = findViewById(R.id.Question34_Rgroup);
        Question34_field = findViewById(R.id.Question34_field);
        Question34_item = findViewById(R.id.Question34_item);
        Question34_btn1 = findViewById(R.id.Question34_btn1);
        Question34_btn2 = findViewById(R.id.Question34_btn2);
        Question34_btn3 = findViewById(R.id.Question34_btn3);
        Question34_btn4 = findViewById(R.id.Question34_btn4);
        //QUEStion35
        Question35_Rgroup = findViewById(R.id.Question35_Rgroup);
        Question35_field = findViewById(R.id.Question35_field);
        Question35_item = findViewById(R.id.Question35_item);
        Question35_btn1 = findViewById(R.id.Question35_btn1);
        Question35_btn2 = findViewById(R.id.Question35_btn2);
        Question35_btn3 = findViewById(R.id.Question35_btn3);
        Question35_btn4 = findViewById(R.id.Question35_btn4);
        //QUEStion36
        Question36_Rgroup = findViewById(R.id.Question36_Rgroup);
        Question36_field = findViewById(R.id.Question36_field);
        Question36_item = findViewById(R.id.Question36_item);
        Question36_btn1 = findViewById(R.id.Question36_btn1);
        Question36_btn2 = findViewById(R.id.Question36_btn2);
        Question36_btn3 = findViewById(R.id.Question36_btn3);
        Question36_btn4 = findViewById(R.id.Question36_btn4);
        //QUEStion37
        Question37_Rgroup = findViewById(R.id.Question37_Rgroup);
        Question37_field = findViewById(R.id.Question37_field);
        Question37_item = findViewById(R.id.Question37_item);
        Question37_btn1 = findViewById(R.id.Question37_btn1);
        Question37_btn2 = findViewById(R.id.Question37_btn2);
        Question37_btn3 = findViewById(R.id.Question37_btn3);
        Question37_btn4 = findViewById(R.id.Question37_btn4);
        //QUEStion38
        Question38_Rgroup = findViewById(R.id.Question38_Rgroup);
        Question38_field = findViewById(R.id.Question38_field);
        Question38_item = findViewById(R.id.Question38_item);
        Question38_btn1 = findViewById(R.id.Question38_btn1);
        Question38_btn2 = findViewById(R.id.Question38_btn2);
        Question38_btn3 = findViewById(R.id.Question38_btn3);
        Question38_btn4 = findViewById(R.id.Question38_btn4);
        //QUEStion39
        Question39_Rgroup = findViewById(R.id.Question39_Rgroup);
        Question39_field = findViewById(R.id.Question39_field);
        Question39_item = findViewById(R.id.Question39_item);
        Question39_btn1 = findViewById(R.id.Question39_btn1);
        Question39_btn2 = findViewById(R.id.Question39_btn2);
        Question39_btn3 = findViewById(R.id.Question39_btn3);
        Question39_btn4 = findViewById(R.id.Question39_btn4);
        //QUEStion40
        Question40_Rgroup = findViewById(R.id.Question40_Rgroup);
        Question40_field = findViewById(R.id.Question40_field);
        Question40_item = findViewById(R.id.Question40_item);
        Question40_btn1 = findViewById(R.id.Question40_btn1);
        Question40_btn2 = findViewById(R.id.Question40_btn2);
        Question40_btn3 = findViewById(R.id.Question40_btn3);
        Question40_btn4 = findViewById(R.id.Question40_btn4);
        //QUEStion41
        Question41_Rgroup = findViewById(R.id.Question41_Rgroup);
        Question41_field = findViewById(R.id.Question41_field);
        Question41_item = findViewById(R.id.Question41_item);
        Question41_btn1 = findViewById(R.id.Question41_btn1);
        Question41_btn2 = findViewById(R.id.Question41_btn2);
        Question41_btn3 = findViewById(R.id.Question41_btn3);
        Question41_btn4 = findViewById(R.id.Question41_btn4);
        //QUEStion42
        Question42_Rgroup = findViewById(R.id.Question42_Rgroup);
        Question42_field = findViewById(R.id.Question42_field);
        Question42_item = findViewById(R.id.Question42_item);
        Question42_btn1 = findViewById(R.id.Question42_btn1);
        Question42_btn2 = findViewById(R.id.Question42_btn2);
        Question42_btn3 = findViewById(R.id.Question42_btn3);
        Question42_btn4 = findViewById(R.id.Question42_btn4);
        //QUEStion43
        Question43_Rgroup = findViewById(R.id.Question43_Rgroup);
        Question43_field = findViewById(R.id.Question43_field);
        Question43_item = findViewById(R.id.Question43_item);
        Question43_btn1 = findViewById(R.id.Question43_btn1);
        Question43_btn2 = findViewById(R.id.Question43_btn2);
        Question43_btn3 = findViewById(R.id.Question43_btn3);
        Question43_btn4 = findViewById(R.id.Question43_btn4);
        //QUEStion44
        Question44_Rgroup = findViewById(R.id.Question44_Rgroup);
        Question44_field = findViewById(R.id.Question44_field);
        Question44_item = findViewById(R.id.Question44_item);
        Question44_btn1 = findViewById(R.id.Question44_btn1);
        Question44_btn2 = findViewById(R.id.Question44_btn2);
        Question44_btn3 = findViewById(R.id.Question44_btn3);
        Question44_btn4 = findViewById(R.id.Question44_btn4);
        //QUEStion45
        Question45_Rgroup = findViewById(R.id.Question45_Rgroup);
        Question45_field = findViewById(R.id.Question45_field);
        Question45_item = findViewById(R.id.Question45_item);
        Question45_btn1 = findViewById(R.id.Question45_btn1);
        Question45_btn2 = findViewById(R.id.Question45_btn2);
        Question45_btn3 = findViewById(R.id.Question45_btn3);
        Question45_btn4 = findViewById(R.id.Question45_btn4);
        //QUEStion46
        Question46_Rgroup = findViewById(R.id.Question46_Rgroup);
        Question46_field = findViewById(R.id.Question46_field);
        Question46_item = findViewById(R.id.Question46_item);
        Question46_btn1 = findViewById(R.id.Question46_btn1);
        Question46_btn2 = findViewById(R.id.Question46_btn2);
        Question46_btn3 = findViewById(R.id.Question46_btn3);
        Question46_btn4 = findViewById(R.id.Question46_btn4);
        //QUEStion47
        Question47_Rgroup = findViewById(R.id.Question47_Rgroup);
        Question47_field = findViewById(R.id.Question47_field);
        Question47_item = findViewById(R.id.Question47_item);
        Question47_btn1 = findViewById(R.id.Question47_btn1);
        Question47_btn2 = findViewById(R.id.Question47_btn2);
        Question47_btn3 = findViewById(R.id.Question47_btn3);
        Question47_btn4 = findViewById(R.id.Question47_btn4);
        //QUEStion48
        Question48_Rgroup = findViewById(R.id.Question48_Rgroup);
        Question48_field = findViewById(R.id.Question48_field);
        Question48_item = findViewById(R.id.Question48_item);
        Question48_btn1 = findViewById(R.id.Question48_btn1);
        Question48_btn2 = findViewById(R.id.Question48_btn2);
        Question48_btn3 = findViewById(R.id.Question48_btn3);
        Question48_btn4 = findViewById(R.id.Question48_btn4);
        //QUEStion49
        Question49_Rgroup = findViewById(R.id.Question49_Rgroup);
        Question49_field = findViewById(R.id.Question49_field);
        Question49_item = findViewById(R.id.Question49_item);
        Question49_btn1 = findViewById(R.id.Question49_btn1);
        Question49_btn2 = findViewById(R.id.Question49_btn2);
        Question49_btn3 = findViewById(R.id.Question49_btn3);
        Question49_btn4 = findViewById(R.id.Question49_btn4);
        //QUEStion50
        Question50_Rgroup = findViewById(R.id.Question50_Rgroup);
        Question50_field = findViewById(R.id.Question50_field);
        Question50_item = findViewById(R.id.Question50_item);
        Question50_btn1 = findViewById(R.id.Question50_btn1);
        Question50_btn2 = findViewById(R.id.Question50_btn2);
        Question50_btn3 = findViewById(R.id.Question50_btn3);
        Question50_btn4 = findViewById(R.id.Question50_btn4);
        //QUEStion51
        Question51_Rgroup = findViewById(R.id.Question51_Rgroup);
        Question51_field = findViewById(R.id.Question51_field);
        Question51_item = findViewById(R.id.Question51_item);
        Question51_btn1 = findViewById(R.id.Question51_btn1);
        Question51_btn2 = findViewById(R.id.Question51_btn2);
        Question51_btn3 = findViewById(R.id.Question51_btn3);
        Question51_btn4 = findViewById(R.id.Question51_btn4);
        //QUEStion52
        Question52_Rgroup = findViewById(R.id.Question52_Rgroup);
        Question52_field = findViewById(R.id.Question52_field);
        Question52_item = findViewById(R.id.Question52_item);
        Question52_btn1 = findViewById(R.id.Question52_btn1);
        Question52_btn2 = findViewById(R.id.Question52_btn2);
        Question52_btn3 = findViewById(R.id.Question52_btn3);
        Question52_btn4 = findViewById(R.id.Question52_btn4);
        //QUEStion53
        Question53_Rgroup = findViewById(R.id.Question53_Rgroup);
        Question53_field = findViewById(R.id.Question53_field);
        Question53_item = findViewById(R.id.Question53_item);
        Question53_btn1 = findViewById(R.id.Question53_btn1);
        Question53_btn2 = findViewById(R.id.Question53_btn2);
        Question53_btn3 = findViewById(R.id.Question53_btn3);
        Question53_btn4 = findViewById(R.id.Question53_btn4);
        //QUEStion54
        Question54_Rgroup = findViewById(R.id.Question54_Rgroup);
        Question54_field = findViewById(R.id.Question54_field);
        Question54_item = findViewById(R.id.Question54_item);
        Question54_btn1 = findViewById(R.id.Question54_btn1);
        Question54_btn2 = findViewById(R.id.Question54_btn2);
        Question54_btn3 = findViewById(R.id.Question54_btn3);
        Question54_btn4 = findViewById(R.id.Question54_btn4);
        //QUEStion55
        Question55_Rgroup = findViewById(R.id.Question55_Rgroup);
        Question55_field = findViewById(R.id.Question55_field);
        Question55_item = findViewById(R.id.Question55_item);
        Question55_btn1 = findViewById(R.id.Question55_btn1);
        Question55_btn2 = findViewById(R.id.Question55_btn2);
        Question55_btn3 = findViewById(R.id.Question55_btn3);
        Question55_btn4 = findViewById(R.id.Question55_btn4);
        //QUEStion56
        Question56_Rgroup = findViewById(R.id.Question56_Rgroup);
        Question56_field = findViewById(R.id.Question56_field);
        Question56_item = findViewById(R.id.Question56_item);
        Question56_btn1 = findViewById(R.id.Question56_btn1);
        Question56_btn2 = findViewById(R.id.Question56_btn2);
        Question56_btn3 = findViewById(R.id.Question56_btn3);
        Question56_btn4 = findViewById(R.id.Question56_btn4);
        //QUEStion57
        Question57_Rgroup = findViewById(R.id.Question57_Rgroup);
        Question57_field = findViewById(R.id.Question57_field);
        Question57_item = findViewById(R.id.Question57_item);
        Question57_btn1 = findViewById(R.id.Question57_btn1);
        Question57_btn2 = findViewById(R.id.Question57_btn2);
        Question57_btn3 = findViewById(R.id.Question57_btn3);
        Question57_btn4 = findViewById(R.id.Question57_btn4);
        //QUEStion58
        Question58_Rgroup = findViewById(R.id.Question58_Rgroup);
        Question58_field = findViewById(R.id.Question58_field);
        Question58_item = findViewById(R.id.Question58_item);
        Question58_btn1 = findViewById(R.id.Question58_btn1);
        Question58_btn2 = findViewById(R.id.Question58_btn2);
        Question58_btn3 = findViewById(R.id.Question58_btn3);
        Question58_btn4 = findViewById(R.id.Question58_btn4);
        //QUEStion59
        Question59_Rgroup = findViewById(R.id.Question59_Rgroup);
        Question59_field = findViewById(R.id.Question59_field);
        Question59_item = findViewById(R.id.Question59_item);
        Question59_btn1 = findViewById(R.id.Question59_btn1);
        Question59_btn2 = findViewById(R.id.Question59_btn2);
        Question59_btn3 = findViewById(R.id.Question59_btn3);
        Question59_btn4 = findViewById(R.id.Question59_btn4);
        //QUEStion60
        Question60_Rgroup = findViewById(R.id.Question60_Rgroup);
        Question60_field = findViewById(R.id.Question60_field);
        Question60_item = findViewById(R.id.Question60_item);
        Question60_btn1 = findViewById(R.id.Question60_btn1);
        Question60_btn2 = findViewById(R.id.Question60_btn2);
        Question60_btn3 = findViewById(R.id.Question60_btn3);
        Question60_btn4 = findViewById(R.id.Question60_btn4);
        //QUEStion61
        Question61_Rgroup = findViewById(R.id.Question61_Rgroup);
        Question61_field = findViewById(R.id.Question61_field);
        Question61_item = findViewById(R.id.Question61_item);
        Question61_btn1 = findViewById(R.id.Question61_btn1);
        Question61_btn2 = findViewById(R.id.Question61_btn2);
        Question61_btn3 = findViewById(R.id.Question61_btn3);
        Question61_btn4 = findViewById(R.id.Question61_btn4);
        //QUEStion62
        Question62_Rgroup = findViewById(R.id.Question62_Rgroup);
        Question62_field = findViewById(R.id.Question62_field);
        Question62_item = findViewById(R.id.Question62_item);
        Question62_btn1 = findViewById(R.id.Question62_btn1);
        Question62_btn2 = findViewById(R.id.Question62_btn2);
        Question62_btn3 = findViewById(R.id.Question62_btn3);
        Question62_btn4 = findViewById(R.id.Question62_btn4);
        //QUEStion63
        Question63_Rgroup = findViewById(R.id.Question63_Rgroup);
        Question63_field = findViewById(R.id.Question63_field);
        Question63_item = findViewById(R.id.Question63_item);
        Question63_btn1 = findViewById(R.id.Question63_btn1);
        Question63_btn2 = findViewById(R.id.Question63_btn2);
        Question63_btn3 = findViewById(R.id.Question63_btn3);
        Question63_btn4 = findViewById(R.id.Question63_btn4);
        //QUEStion64
        Question64_Rgroup = findViewById(R.id.Question64_Rgroup);
        Question64_field = findViewById(R.id.Question64_field);
        Question64_item = findViewById(R.id.Question64_item);
        Question64_btn1 = findViewById(R.id.Question64_btn1);
        Question64_btn2 = findViewById(R.id.Question64_btn2);
        Question64_btn3 = findViewById(R.id.Question64_btn3);
        Question64_btn4 = findViewById(R.id.Question64_btn4);
        //QUEStion65
        Question65_Rgroup = findViewById(R.id.Question65_Rgroup);
        Question65_field = findViewById(R.id.Question65_field);
        Question65_item = findViewById(R.id.Question65_item);
        Question65_btn1 = findViewById(R.id.Question65_btn1);
        Question65_btn2 = findViewById(R.id.Question65_btn2);
        Question65_btn3 = findViewById(R.id.Question65_btn3);
        Question65_btn4 = findViewById(R.id.Question65_btn4);
        //QUEStion66
        Question66_Rgroup = findViewById(R.id.Question66_Rgroup);
        Question66_field = findViewById(R.id.Question66_field);
        Question66_item = findViewById(R.id.Question66_item);
        Question66_btn1 = findViewById(R.id.Question66_btn1);
        Question66_btn2 = findViewById(R.id.Question66_btn2);
        Question66_btn3 = findViewById(R.id.Question66_btn3);
        Question66_btn4 = findViewById(R.id.Question66_btn4);
        //QUEStion67
        Question67_Rgroup = findViewById(R.id.Question67_Rgroup);
        Question67_field = findViewById(R.id.Question67_field);
        Question67_item = findViewById(R.id.Question67_item);
        Question67_btn1 = findViewById(R.id.Question67_btn1);
        Question67_btn2 = findViewById(R.id.Question67_btn2);
        Question67_btn3 = findViewById(R.id.Question67_btn3);
        Question67_btn4 = findViewById(R.id.Question67_btn4);
        //QUEStion68
        Question68_Rgroup = findViewById(R.id.Question68_Rgroup);
        Question68_field = findViewById(R.id.Question68_field);
        Question68_item = findViewById(R.id.Question68_item);
        Question68_btn1 = findViewById(R.id.Question68_btn1);
        Question68_btn2 = findViewById(R.id.Question68_btn2);
        Question68_btn3 = findViewById(R.id.Question68_btn3);
        Question68_btn4 = findViewById(R.id.Question68_btn4);
        //QUEStion69
        Question69_Rgroup = findViewById(R.id.Question69_Rgroup);
        Question69_field = findViewById(R.id.Question69_field);
        Question69_item = findViewById(R.id.Question69_item);
        Question69_btn1 = findViewById(R.id.Question69_btn1);
        Question69_btn2 = findViewById(R.id.Question69_btn2);
        Question69_btn3 = findViewById(R.id.Question69_btn3);
        Question69_btn4 = findViewById(R.id.Question69_btn4);
        //QUEStion70
        Question70_Rgroup = findViewById(R.id.Question70_Rgroup);
        Question70_field = findViewById(R.id.Question70_field);
        Question70_item = findViewById(R.id.Question70_item);
        Question70_btn1 = findViewById(R.id.Question70_btn1);
        Question70_btn2 = findViewById(R.id.Question70_btn2);
        Question70_btn3 = findViewById(R.id.Question70_btn3);
        Question70_btn4 = findViewById(R.id.Question70_btn4);
        //QUEStion71
        Question71_Rgroup = findViewById(R.id.Question71_Rgroup);
        Question71_field = findViewById(R.id.Question71_field);
        Question71_item = findViewById(R.id.Question71_item);
        Question71_btn1 = findViewById(R.id.Question71_btn1);
        Question71_btn2 = findViewById(R.id.Question71_btn2);
        Question71_btn3 = findViewById(R.id.Question71_btn3);
        Question71_btn4 = findViewById(R.id.Question71_btn4);
        //QUEStion72
        Question72_Rgroup = findViewById(R.id.Question72_Rgroup);
        Question72_field = findViewById(R.id.Question72_field);
        Question72_item = findViewById(R.id.Question72_item);
        Question72_btn1 = findViewById(R.id.Question72_btn1);
        Question72_btn2 = findViewById(R.id.Question72_btn2);
        Question72_btn3 = findViewById(R.id.Question72_btn3);
        Question72_btn4 = findViewById(R.id.Question72_btn4);
        //QUEStion73
        Question73_Rgroup = findViewById(R.id.Question73_Rgroup);
        Question73_field = findViewById(R.id.Question73_field);
        Question73_item = findViewById(R.id.Question73_item);
        Question73_btn1 = findViewById(R.id.Question73_btn1);
        Question73_btn2 = findViewById(R.id.Question73_btn2);
        Question73_btn3 = findViewById(R.id.Question73_btn3);
        Question73_btn4 = findViewById(R.id.Question73_btn4);
        //QUEStion74
        Question74_Rgroup = findViewById(R.id.Question74_Rgroup);
        Question74_field = findViewById(R.id.Question74_field);
        Question74_item = findViewById(R.id.Question74_item);
        Question74_btn1 = findViewById(R.id.Question74_btn1);
        Question74_btn2 = findViewById(R.id.Question74_btn2);
        Question74_btn3 = findViewById(R.id.Question74_btn3);
        Question74_btn4 = findViewById(R.id.Question74_btn4);
        //QUEStion75
        Question75_Rgroup = findViewById(R.id.Question75_Rgroup);
        Question75_field = findViewById(R.id.Question75_field);
        Question75_item = findViewById(R.id.Question75_item);
        Question75_btn1 = findViewById(R.id.Question75_btn1);
        Question75_btn2 = findViewById(R.id.Question75_btn2);
        Question75_btn3 = findViewById(R.id.Question75_btn3);
        Question75_btn4 = findViewById(R.id.Question75_btn4);
        //QUEStion76
        Question76_Rgroup = findViewById(R.id.Question76_Rgroup);
        Question76_field = findViewById(R.id.Question76_field);
        Question76_item = findViewById(R.id.Question76_item);
        Question76_btn1 = findViewById(R.id.Question76_btn1);
        Question76_btn2 = findViewById(R.id.Question76_btn2);
        Question76_btn3 = findViewById(R.id.Question76_btn3);
        Question76_btn4 = findViewById(R.id.Question76_btn4);
        //QUEStion77
        Question77_Rgroup = findViewById(R.id.Question77_Rgroup);
        Question77_field = findViewById(R.id.Question77_field);
        Question77_item = findViewById(R.id.Question77_item);
        Question77_btn1 = findViewById(R.id.Question77_btn1);
        Question77_btn2 = findViewById(R.id.Question77_btn2);
        Question77_btn3 = findViewById(R.id.Question77_btn3);
        Question77_btn4 = findViewById(R.id.Question77_btn4);
        //QUEStion78
        Question78_Rgroup = findViewById(R.id.Question78_Rgroup);
        Question78_field = findViewById(R.id.Question78_field);
        Question78_item = findViewById(R.id.Question78_item);
        Question78_btn1 = findViewById(R.id.Question78_btn1);
        Question78_btn2 = findViewById(R.id.Question78_btn2);
        Question78_btn3 = findViewById(R.id.Question78_btn3);
        Question78_btn4 = findViewById(R.id.Question78_btn4);
        //QUEStion79
        Question79_Rgroup = findViewById(R.id.Question79_Rgroup);
        Question79_field = findViewById(R.id.Question79_field);
        Question79_item = findViewById(R.id.Question79_item);
        Question79_btn1 = findViewById(R.id.Question79_btn1);
        Question79_btn2 = findViewById(R.id.Question79_btn2);
        Question79_btn3 = findViewById(R.id.Question79_btn3);
        Question79_btn4 = findViewById(R.id.Question79_btn4);
        //QUEStion80
        Question80_Rgroup = findViewById(R.id.Question80_Rgroup);
        Question80_field = findViewById(R.id.Question80_field);
        Question80_item = findViewById(R.id.Question80_item);
        Question80_btn1 = findViewById(R.id.Question80_btn1);
        Question80_btn2 = findViewById(R.id.Question80_btn2);
        Question80_btn3 = findViewById(R.id.Question80_btn3);
        Question80_btn4 = findViewById(R.id.Question80_btn4);
        //QUEStion81
        Question81_Rgroup = findViewById(R.id.Question81_Rgroup);
        Question81_field = findViewById(R.id.Question81_field);
        Question81_item = findViewById(R.id.Question81_item);
        Question81_btn1 = findViewById(R.id.Question81_btn1);
        Question81_btn2 = findViewById(R.id.Question81_btn2);
        Question81_btn3 = findViewById(R.id.Question81_btn3);
        Question81_btn4 = findViewById(R.id.Question81_btn4);
        //QUEStion82
        Question82_Rgroup = findViewById(R.id.Question82_Rgroup);
        Question82_field = findViewById(R.id.Question82_field);
        Question82_item = findViewById(R.id.Question82_item);
        Question82_btn1 = findViewById(R.id.Question82_btn1);
        Question82_btn2 = findViewById(R.id.Question82_btn2);
        Question82_btn3 = findViewById(R.id.Question82_btn3);
        Question82_btn4 = findViewById(R.id.Question82_btn4);
        //QUEStion83
        Question83_Rgroup = findViewById(R.id.Question83_Rgroup);
        Question83_field = findViewById(R.id.Question83_field);
        Question83_item = findViewById(R.id.Question83_item);
        Question83_btn1 = findViewById(R.id.Question83_btn1);
        Question83_btn2 = findViewById(R.id.Question83_btn2);
        Question83_btn3 = findViewById(R.id.Question83_btn3);
        Question83_btn4 = findViewById(R.id.Question83_btn4);
        //QUEStion84
        Question84_Rgroup = findViewById(R.id.Question84_Rgroup);
        Question84_field = findViewById(R.id.Question84_field);
        Question84_item = findViewById(R.id.Question84_item);
        Question84_btn1 = findViewById(R.id.Question84_btn1);
        Question84_btn2 = findViewById(R.id.Question84_btn2);
        Question84_btn3 = findViewById(R.id.Question84_btn3);
        Question84_btn4 = findViewById(R.id.Question84_btn4);
        //QUEStion85
        Question85_Rgroup = findViewById(R.id.Question85_Rgroup);
        Question85_field = findViewById(R.id.Question85_field);
        Question85_item = findViewById(R.id.Question85_item);
        Question85_btn1 = findViewById(R.id.Question85_btn1);
        Question85_btn2 = findViewById(R.id.Question85_btn2);
        Question85_btn3 = findViewById(R.id.Question85_btn3);
        Question85_btn4 = findViewById(R.id.Question85_btn4);
        //QUEStion86
        Question86_Rgroup = findViewById(R.id.Question86_Rgroup);
        Question86_field = findViewById(R.id.Question86_field);
        Question86_item = findViewById(R.id.Question86_item);
        Question86_btn1 = findViewById(R.id.Question86_btn1);
        Question86_btn2 = findViewById(R.id.Question86_btn2);
        Question86_btn3 = findViewById(R.id.Question86_btn3);
        Question86_btn4 = findViewById(R.id.Question86_btn4);
        //QUEStion87
        Question87_Rgroup = findViewById(R.id.Question87_Rgroup);
        Question87_field = findViewById(R.id.Question87_field);
        Question87_item = findViewById(R.id.Question87_item);
        Question87_btn1 = findViewById(R.id.Question87_btn1);
        Question87_btn2 = findViewById(R.id.Question87_btn2);
        Question87_btn3 = findViewById(R.id.Question87_btn3);
        Question87_btn4 = findViewById(R.id.Question87_btn4);
        //QUEStion88
        Question88_Rgroup = findViewById(R.id.Question88_Rgroup);
        Question88_field = findViewById(R.id.Question88_field);
        Question88_item = findViewById(R.id.Question88_item);
        Question88_btn1 = findViewById(R.id.Question88_btn1);
        Question88_btn2 = findViewById(R.id.Question88_btn2);
        Question88_btn3 = findViewById(R.id.Question88_btn3);
        Question88_btn4 = findViewById(R.id.Question88_btn4);
        //QUEStion89
        Question89_Rgroup = findViewById(R.id.Question89_Rgroup);
        Question89_field = findViewById(R.id.Question89_field);
        Question89_item = findViewById(R.id.Question89_item);
        Question89_btn1 = findViewById(R.id.Question89_btn1);
        Question89_btn2 = findViewById(R.id.Question89_btn2);
        Question89_btn3 = findViewById(R.id.Question89_btn3);
        Question89_btn4 = findViewById(R.id.Question89_btn4);
        //QUEStion90
        Question90_Rgroup = findViewById(R.id.Question90_Rgroup);
        Question90_field = findViewById(R.id.Question90_field);
        Question90_item = findViewById(R.id.Question90_item);
        Question90_btn1 = findViewById(R.id.Question90_btn1);
        Question90_btn2 = findViewById(R.id.Question90_btn2);
        Question90_btn3 = findViewById(R.id.Question90_btn3);
        Question90_btn4 = findViewById(R.id.Question90_btn4);
        //QUEStion91
        Question91_Rgroup = findViewById(R.id.Question91_Rgroup);
        Question91_field = findViewById(R.id.Question91_field);
        Question91_item = findViewById(R.id.Question91_item);
        Question91_btn1 = findViewById(R.id.Question91_btn1);
        Question91_btn2 = findViewById(R.id.Question91_btn2);
        Question91_btn3 = findViewById(R.id.Question91_btn3);
        Question91_btn4 = findViewById(R.id.Question91_btn4);
        //QUEStion92
        Question92_Rgroup = findViewById(R.id.Question92_Rgroup);
        Question92_field = findViewById(R.id.Question92_field);
        Question92_item = findViewById(R.id.Question92_item);
        Question92_btn1 = findViewById(R.id.Question92_btn1);
        Question92_btn2 = findViewById(R.id.Question92_btn2);
        Question92_btn3 = findViewById(R.id.Question92_btn3);
        Question92_btn4 = findViewById(R.id.Question92_btn4);
        //QUEStion93
        Question93_Rgroup = findViewById(R.id.Question93_Rgroup);
        Question93_field = findViewById(R.id.Question93_field);
        Question93_item = findViewById(R.id.Question93_item);
        Question93_btn1 = findViewById(R.id.Question93_btn1);
        Question93_btn2 = findViewById(R.id.Question93_btn2);
        Question93_btn3 = findViewById(R.id.Question93_btn3);
        Question93_btn4 = findViewById(R.id.Question93_btn4);
        //QUEStion94
        Question94_Rgroup = findViewById(R.id.Question94_Rgroup);
        Question94_field = findViewById(R.id.Question94_field);
        Question94_item = findViewById(R.id.Question94_item);
        Question94_btn1 = findViewById(R.id.Question94_btn1);
        Question94_btn2 = findViewById(R.id.Question94_btn2);
        Question94_btn3 = findViewById(R.id.Question94_btn3);
        Question94_btn4 = findViewById(R.id.Question94_btn4);
        //QUEStion95
        Question95_Rgroup = findViewById(R.id.Question95_Rgroup);
        Question95_field = findViewById(R.id.Question95_field);
        Question95_item = findViewById(R.id.Question95_item);
        Question95_btn1 = findViewById(R.id.Question95_btn1);
        Question95_btn2 = findViewById(R.id.Question95_btn2);
        Question95_btn3 = findViewById(R.id.Question95_btn3);
        Question95_btn4 = findViewById(R.id.Question95_btn4);
        //QUEStion96
        Question96_Rgroup = findViewById(R.id.Question96_Rgroup);
        Question96_field = findViewById(R.id.Question96_field);
        Question96_item = findViewById(R.id.Question96_item);
        Question96_btn1 = findViewById(R.id.Question96_btn1);
        Question96_btn2 = findViewById(R.id.Question96_btn2);
        Question96_btn3 = findViewById(R.id.Question96_btn3);
        Question96_btn4 = findViewById(R.id.Question96_btn4);
        //QUEStion97
        Question97_Rgroup = findViewById(R.id.Question97_Rgroup);
        Question97_field = findViewById(R.id.Question97_field);
        Question97_item = findViewById(R.id.Question97_item);
        Question97_btn1 = findViewById(R.id.Question97_btn1);
        Question97_btn2 = findViewById(R.id.Question97_btn2);
        Question97_btn3 = findViewById(R.id.Question97_btn3);
        Question97_btn4 = findViewById(R.id.Question97_btn4);
        //QUEStion98
        Question98_Rgroup = findViewById(R.id.Question98_Rgroup);
        Question98_field = findViewById(R.id.Question98_field);
        Question98_item = findViewById(R.id.Question98_item);
        Question98_btn1 = findViewById(R.id.Question98_btn1);
        Question98_btn2 = findViewById(R.id.Question98_btn2);
        Question98_btn3 = findViewById(R.id.Question98_btn3);
        Question98_btn4 = findViewById(R.id.Question98_btn4);
        //QUEStion99
        Question99_Rgroup = findViewById(R.id.Question99_Rgroup);
        Question99_field = findViewById(R.id.Question99_field);
        Question99_item = findViewById(R.id.Question99_item);
        Question99_btn1 = findViewById(R.id.Question99_btn1);
        Question99_btn2 = findViewById(R.id.Question99_btn2);
        Question99_btn3 = findViewById(R.id.Question99_btn3);
        Question99_btn4 = findViewById(R.id.Question99_btn4);
        //QUEStion100
        Question100_Rgroup = findViewById(R.id.Question100_Rgroup);
        Question100_field = findViewById(R.id.Question100_field);
        Question100_item = findViewById(R.id.Question100_item);
        Question100_btn1 = findViewById(R.id.Question100_btn1);
        Question100_btn2 = findViewById(R.id.Question100_btn2);
        Question100_btn3 = findViewById(R.id.Question100_btn3);
        Question100_btn4 = findViewById(R.id.Question100_btn4);
        //QUEStion101
        Question101_Rgroup = findViewById(R.id.Question101_Rgroup);
        Question101_field = findViewById(R.id.Question101_field);
        Question101_item = findViewById(R.id.Question101_item);
        Question101_btn1 = findViewById(R.id.Question101_btn1);
        Question101_btn2 = findViewById(R.id.Question101_btn2);
        Question101_btn3 = findViewById(R.id.Question101_btn3);
        Question101_btn4 = findViewById(R.id.Question101_btn4);
        //QUEStion102
        Question102_Rgroup = findViewById(R.id.Question102_Rgroup);
        Question102_field = findViewById(R.id.Question102_field);
        Question102_item = findViewById(R.id.Question102_item);
        Question102_btn1 = findViewById(R.id.Question102_btn1);
        Question102_btn2 = findViewById(R.id.Question102_btn2);
        Question102_btn3 = findViewById(R.id.Question102_btn3);
        Question102_btn4 = findViewById(R.id.Question102_btn4);
        //QUEStion103
        Question103_Rgroup = findViewById(R.id.Question103_Rgroup);
        Question103_field = findViewById(R.id.Question103_field);
        Question103_item = findViewById(R.id.Question103_item);
        Question103_btn1 = findViewById(R.id.Question103_btn1);
        Question103_btn2 = findViewById(R.id.Question103_btn2);
        Question103_btn3 = findViewById(R.id.Question103_btn3);
        Question103_btn4 = findViewById(R.id.Question103_btn4);
        //QUEStion104
        Question104_Rgroup = findViewById(R.id.Question104_Rgroup);
        Question104_field = findViewById(R.id.Question104_field);
        Question104_item = findViewById(R.id.Question104_item);
        Question104_btn1 = findViewById(R.id.Question104_btn1);
        Question104_btn2 = findViewById(R.id.Question104_btn2);
        Question104_btn3 = findViewById(R.id.Question104_btn3);
        Question104_btn4 = findViewById(R.id.Question104_btn4);
        //QUEStion105
        Question105_Rgroup = findViewById(R.id.Question105_Rgroup);
        Question105_field = findViewById(R.id.Question105_field);
        Question105_item = findViewById(R.id.Question105_item);
        Question105_btn1 = findViewById(R.id.Question105_btn1);
        Question105_btn2 = findViewById(R.id.Question105_btn2);
        Question105_btn3 = findViewById(R.id.Question105_btn3);
        Question105_btn4 = findViewById(R.id.Question105_btn4);
        //QUEStion106
        Question106_Rgroup = findViewById(R.id.Question106_Rgroup);
        Question106_field = findViewById(R.id.Question106_field);
        Question106_item = findViewById(R.id.Question106_item);
        Question106_btn1 = findViewById(R.id.Question106_btn1);
        Question106_btn2 = findViewById(R.id.Question106_btn2);
        Question106_btn3 = findViewById(R.id.Question106_btn3);
        Question106_btn4 = findViewById(R.id.Question106_btn4);
        //QUEStion107
        Question107_Rgroup = findViewById(R.id.Question107_Rgroup);
        Question107_field = findViewById(R.id.Question107_field);
        Question107_item = findViewById(R.id.Question107_item);
        Question107_btn1 = findViewById(R.id.Question107_btn1);
        Question107_btn2 = findViewById(R.id.Question107_btn2);
        Question107_btn3 = findViewById(R.id.Question107_btn3);
        Question107_btn4 = findViewById(R.id.Question107_btn4);
        //QUEStion108
        Question108_Rgroup = findViewById(R.id.Question108_Rgroup);
        Question108_field = findViewById(R.id.Question108_field);
        Question108_item = findViewById(R.id.Question108_item);
        Question108_btn1 = findViewById(R.id.Question108_btn1);
        Question108_btn2 = findViewById(R.id.Question108_btn2);
        Question108_btn3 = findViewById(R.id.Question108_btn3);
        Question108_btn4 = findViewById(R.id.Question108_btn4);
        //QUEStion109
        Question109_Rgroup = findViewById(R.id.Question109_Rgroup);
        Question109_field = findViewById(R.id.Question109_field);
        Question109_item = findViewById(R.id.Question109_item);
        Question109_btn1 = findViewById(R.id.Question109_btn1);
        Question109_btn2 = findViewById(R.id.Question109_btn2);
        Question109_btn3 = findViewById(R.id.Question109_btn3);
        Question109_btn4 = findViewById(R.id.Question109_btn4);

        textDefualt = txt_time.getTextColors();
        ExamDbHelper dbHelper = new ExamDbHelper(this);
        questionlist = dbHelper.getAllQuestions();
        totalcount = questionlist.size();

        Collections.shuffle(questionlist);
        showNextQuestion();

        timeleft = COUNT_DOWN_MILLIS;
        startCountdown();


        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showResult();
                cdtimer.cancel();
            }
        });
    }

    private void showNextQuestion() {
        //
        //
        //QUESTION 1
        //
        //
        Question1_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question1_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question1_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question1_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION 2
        //
        //
        Question2_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question2_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question2_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question2_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION 3
        //
        //
        Question3_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question3_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question3_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question3_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION 4
        //
        //
        Question4_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question4_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question4_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question4_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION 5
        //
        //
        Question5_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question5_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question5_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question5_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION 6
        //
        //
        Question6_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question6_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question6_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question6_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION 7
        //
        //
        Question7_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question7_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question7_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question7_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION 8
        //
        //
        Question8_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question8_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question8_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question8_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION 9
        //
        //
        Question9_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question9_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question9_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question9_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION10
        //
        //
        Question10_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question10_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question10_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question10_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION11
        //
        //
        Question11_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question11_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question11_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question11_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION12
        //
        //
        Question12_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question12_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question12_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question12_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION13
        //
        //
        Question13_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question13_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question13_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question13_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION14
        //
        //
        Question14_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question14_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question14_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question14_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION15
        //
        //
        Question15_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question15_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question15_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question15_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION16
        //
        //
        Question16_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question16_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question16_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question16_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION17
        //
        //
        Question17_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question17_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question17_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question17_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION18
        //
        //
        Question18_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question18_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question18_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question18_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //QUESTION19
        //
        //
        Question19_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question19_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question19_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question19_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question20
        //
        //
        Question20_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question20_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question20_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question20_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question21
        //
        //
        Question21_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question21_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question21_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question21_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question22
        //
        //
        Question22_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question22_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question22_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question22_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question23
        //
        //
        Question23_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question23_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question23_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question23_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question24
        //
        //
        Question24_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question24_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question24_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question24_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question25
        //
        //
        Question25_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question25_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question25_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question25_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question26
        //
        //
        Question26_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question26_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question26_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question26_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question27
        //
        //
        Question27_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question27_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question27_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question27_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question28
        //
        //
        Question28_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question28_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question28_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question28_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question29
        //
        //
        Question29_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question29_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question29_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question29_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question30
        //
        //
        Question30_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question30_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question30_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question30_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question31
        //
        //
        Question31_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question31_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question31_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question31_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question32
        //
        //
        Question32_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question32_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question32_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question32_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question33
        //
        //
        Question33_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question33_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question33_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question33_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question34
        //
        //
        Question34_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question34_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question34_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question34_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question35
        //
        //
        Question35_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question35_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question35_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question35_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question36
        //
        //
        Question36_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question36_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question36_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question36_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question37
        //
        //
        Question37_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question37_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question37_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question37_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question38
        //
        //
        Question38_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question38_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question38_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question38_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question39
        //
        //
        Question39_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question39_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question39_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question39_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question40
        //
        //
        Question40_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question40_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question40_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question40_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question41
        //
        //
        Question41_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question41_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question41_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question41_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question42
        //
        //
        Question42_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question42_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question42_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question42_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question43
        //
        //
        Question43_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question43_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question43_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question43_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question44
        //
        //
        Question44_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question44_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question44_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question44_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question45
        //
        //
        Question45_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question45_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question45_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question45_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question46
        //
        //
        Question46_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question46_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question46_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question46_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question47
        //
        //
        Question47_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question47_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question47_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question47_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question48
        //
        //
        Question48_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question48_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question48_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question48_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question49
        //
        //
        Question49_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question49_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question49_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question49_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question50
        //
        //
        Question50_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question50_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question50_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question50_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question51
        //
        //
        Question51_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question51_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question51_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question51_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question52
        //
        //
        Question52_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question52_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question52_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question52_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question53
        //
        //
        Question53_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question53_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question53_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question53_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question54
        //
        //
        Question54_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question54_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question54_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question54_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question55
        //
        //
        Question55_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question55_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question55_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question55_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question56
        //
        //
        Question56_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question56_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question56_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question56_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question57
        //
        //
        Question57_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question57_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question57_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question57_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question58
        //
        //
        Question58_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question58_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question58_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question58_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question59
        //
        //
        Question59_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question59_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question59_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question59_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question60
        //
        //
        Question60_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question60_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question60_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question60_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question61
        //
        //
        Question61_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question61_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question61_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question61_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question62
        //
        //
        Question62_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question62_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question62_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question62_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question63
        //
        //
        Question63_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question63_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question63_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question63_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question64
        //
        //
        Question64_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question64_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question64_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question64_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question65
        //
        //
        Question65_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question65_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question65_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question65_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question66
        //
        //
        Question66_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question66_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question66_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question66_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question67
        //
        //
        Question67_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question67_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question67_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question67_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question68
        //
        //
        Question68_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question68_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question68_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question68_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question69
        //
        //
        Question69_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question69_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question69_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question69_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question70
        //
        //
        Question70_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question70_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question70_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question70_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question71
        //
        //
        Question71_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question71_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question71_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question71_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question72
        //
        //
        Question72_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question72_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question72_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question72_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question73
        //
        //
        Question73_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question73_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question73_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question73_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question74
        //
        //
        Question74_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question74_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question74_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question74_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question75
        //
        //
        Question75_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question75_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question75_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question75_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question76
        //
        //
        Question76_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question76_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question76_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question76_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question77
        //
        //
        Question77_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question77_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question77_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question77_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question78
        //
        //
        Question78_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question78_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question78_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question78_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question79
        //
        //
        Question79_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question79_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question79_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question79_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question80
        //
        //
        Question80_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question80_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question80_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question80_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question81
        //
        //
        Question81_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question81_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question81_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question81_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question82
        //
        //
        Question82_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question82_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question82_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question82_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question83
        //
        //
        Question83_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question83_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question83_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question83_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question84
        //
        //
        Question84_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question84_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question84_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question84_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question85
        //
        //
        Question85_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question85_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question85_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question85_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question86
        //
        //
        Question86_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question86_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question86_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question86_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question87
        //
        //
        Question87_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question87_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question87_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question87_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question88
        //
        //
        Question88_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question88_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question88_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question88_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question89
        //
        //
        Question89_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question89_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question89_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question89_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question90
        //
        //
        Question90_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question90_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question90_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question90_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question91
        //
        //
        Question91_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question91_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question91_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question91_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question92
        //
        //
        Question92_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question92_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question92_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question92_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question93
        //
        //
        Question93_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question93_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question93_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question93_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question94
        //
        //
        Question94_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question94_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question94_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question94_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question95
        //
        //
        Question95_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question95_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question95_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question95_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question96
        //
        //
        Question96_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question96_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question96_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question96_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question97
        //
        //
        Question97_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question97_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question97_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question97_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question98
        //
        //
        Question98_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question98_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question98_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question98_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question99
        //
        //
        Question99_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question99_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question99_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question99_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question100
        //
        //
        Question100_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question100_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question100_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question100_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question101
        //
        //
        Question101_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question101_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question101_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question101_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question102
        //
        //
        Question102_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question102_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question102_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question102_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question103
        //
        //
        Question103_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question103_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question103_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question103_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question104
        //
        //
        Question104_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question104_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question104_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question104_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question105
        //
        //
        Question105_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question105_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question105_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question105_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question106
        //
        //
        Question106_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question106_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question106_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question106_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question107
        //
        //
        Question107_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question107_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question107_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question107_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question108
        //
        //
        Question108_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question108_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question108_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question108_btn4.setTextColor(Color.parseColor("#c0c0c0"));
        //
        //
        //Question109
        //
        //
        Question109_btn1.setTextColor(Color.parseColor("#c0c0c0"));
        Question109_btn2.setTextColor(Color.parseColor("#c0c0c0"));
        Question109_btn3.setTextColor(Color.parseColor("#c0c0c0"));
        Question109_btn4.setTextColor(Color.parseColor("#c0c0c0"));



        currentquestion = questionlist.get(counter);
        ArrayList<Integer> answerkeys = new ArrayList<>(Arrays.asList(answerKeys));


        //
        //
        //setting Question and Choices in QUESTION 1
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question1_field.setText(currentquestion.getQuestion());
            Question1_btn1.setText(currentquestion.getOption1());
            Question1_btn2.setText(currentquestion.getOption2());
            Question1_btn3.setText(currentquestion.getOption3());
            Question1_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question1_item.setText("Question " + counter + " / " + totalcount);
        }
        //
        //
        //setting Question and Choices in QUESTION 2
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question2_field.setText(currentquestion.getQuestion());
            Question2_btn1.setText(currentquestion.getOption1());
            Question2_btn2.setText(currentquestion.getOption2());
            Question2_btn3.setText(currentquestion.getOption3());
            Question2_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);
            answer = false;
            counter++;
            Question2_item.setText("Question " + counter + " / " + totalcount);



        }
        //
        //
        //setting Question and Choices in  QUESTION 3
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question3_field.setText(currentquestion.getQuestion());
            Question3_btn1.setText(currentquestion.getOption1());
            Question3_btn2.setText(currentquestion.getOption2());
            Question3_btn3.setText(currentquestion.getOption3());
            Question3_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);
            answer = false;
            counter++;
            Question3_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION 4
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question4_field.setText(currentquestion.getQuestion());
            Question4_btn1.setText(currentquestion.getOption1());
            Question4_btn2.setText(currentquestion.getOption2());
            Question4_btn3.setText(currentquestion.getOption3());
            Question4_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question4_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION 5
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question5_field.setText(currentquestion.getQuestion());
            Question5_btn1.setText(currentquestion.getOption1());
            Question5_btn2.setText(currentquestion.getOption2());
            Question5_btn3.setText(currentquestion.getOption3());
            Question5_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question5_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION 6
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question6_field.setText(currentquestion.getQuestion());
            Question6_btn1.setText(currentquestion.getOption1());
            Question6_btn2.setText(currentquestion.getOption2());
            Question6_btn3.setText(currentquestion.getOption3());
            Question6_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question6_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION 7
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question7_field.setText(currentquestion.getQuestion());
            Question7_btn1.setText(currentquestion.getOption1());
            Question7_btn2.setText(currentquestion.getOption2());
            Question7_btn3.setText(currentquestion.getOption3());
            Question7_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question7_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION 8
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question8_field.setText(currentquestion.getQuestion());
            Question8_btn1.setText(currentquestion.getOption1());
            Question8_btn2.setText(currentquestion.getOption2());
            Question8_btn3.setText(currentquestion.getOption3());
            Question8_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question8_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION 9
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question9_field.setText(currentquestion.getQuestion());
            Question9_btn1.setText(currentquestion.getOption1());
            Question9_btn2.setText(currentquestion.getOption2());
            Question9_btn3.setText(currentquestion.getOption3());
            Question9_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question9_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION10
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question10_field.setText(currentquestion.getQuestion());
            Question10_btn1.setText(currentquestion.getOption1());
            Question10_btn2.setText(currentquestion.getOption2());
            Question10_btn3.setText(currentquestion.getOption3());
            Question10_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question10_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION11
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question11_field.setText(currentquestion.getQuestion());
            Question11_btn1.setText(currentquestion.getOption1());
            Question11_btn2.setText(currentquestion.getOption2());
            Question11_btn3.setText(currentquestion.getOption3());
            Question11_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question11_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION12
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question12_field.setText(currentquestion.getQuestion());
            Question12_btn1.setText(currentquestion.getOption1());
            Question12_btn2.setText(currentquestion.getOption2());
            Question12_btn3.setText(currentquestion.getOption3());
            Question12_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question12_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION13
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question13_field.setText(currentquestion.getQuestion());
            Question13_btn1.setText(currentquestion.getOption1());
            Question13_btn2.setText(currentquestion.getOption2());
            Question13_btn3.setText(currentquestion.getOption3());
            Question13_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question13_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION14
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question14_field.setText(currentquestion.getQuestion());
            Question14_btn1.setText(currentquestion.getOption1());
            Question14_btn2.setText(currentquestion.getOption2());
            Question14_btn3.setText(currentquestion.getOption3());
            Question14_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question14_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION15
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question15_field.setText(currentquestion.getQuestion());
            Question15_btn1.setText(currentquestion.getOption1());
            Question15_btn2.setText(currentquestion.getOption2());
            Question15_btn3.setText(currentquestion.getOption3());
            Question15_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question15_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION16
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question16_field.setText(currentquestion.getQuestion());
            Question16_btn1.setText(currentquestion.getOption1());
            Question16_btn2.setText(currentquestion.getOption2());
            Question16_btn3.setText(currentquestion.getOption3());
            Question16_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question16_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION17
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question17_field.setText(currentquestion.getQuestion());
            Question17_btn1.setText(currentquestion.getOption1());
            Question17_btn2.setText(currentquestion.getOption2());
            Question17_btn3.setText(currentquestion.getOption3());
            Question17_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question17_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION18
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question18_field.setText(currentquestion.getQuestion());
            Question18_btn1.setText(currentquestion.getOption1());
            Question18_btn2.setText(currentquestion.getOption2());
            Question18_btn3.setText(currentquestion.getOption3());
            Question18_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question18_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  QUESTION19
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question19_field.setText(currentquestion.getQuestion());
            Question19_btn1.setText(currentquestion.getOption1());
            Question19_btn2.setText(currentquestion.getOption2());
            Question19_btn3.setText(currentquestion.getOption3());
            Question19_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question19_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question20
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question20_field.setText(currentquestion.getQuestion());
            Question20_btn1.setText(currentquestion.getOption1());
            Question20_btn2.setText(currentquestion.getOption2());
            Question20_btn3.setText(currentquestion.getOption3());
            Question20_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question20_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question21
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question21_field.setText(currentquestion.getQuestion());
            Question21_btn1.setText(currentquestion.getOption1());
            Question21_btn2.setText(currentquestion.getOption2());
            Question21_btn3.setText(currentquestion.getOption3());
            Question21_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question21_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question22
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question22_field.setText(currentquestion.getQuestion());
            Question22_btn1.setText(currentquestion.getOption1());
            Question22_btn2.setText(currentquestion.getOption2());
            Question22_btn3.setText(currentquestion.getOption3());
            Question22_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question22_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question23
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question23_field.setText(currentquestion.getQuestion());
            Question23_btn1.setText(currentquestion.getOption1());
            Question23_btn2.setText(currentquestion.getOption2());
            Question23_btn3.setText(currentquestion.getOption3());
            Question23_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question23_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question24
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question24_field.setText(currentquestion.getQuestion());
            Question24_btn1.setText(currentquestion.getOption1());
            Question24_btn2.setText(currentquestion.getOption2());
            Question24_btn3.setText(currentquestion.getOption3());
            Question24_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question24_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question25
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question25_field.setText(currentquestion.getQuestion());
            Question25_btn1.setText(currentquestion.getOption1());
            Question25_btn2.setText(currentquestion.getOption2());
            Question25_btn3.setText(currentquestion.getOption3());
            Question25_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question25_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question26
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question26_field.setText(currentquestion.getQuestion());
            Question26_btn1.setText(currentquestion.getOption1());
            Question26_btn2.setText(currentquestion.getOption2());
            Question26_btn3.setText(currentquestion.getOption3());
            Question26_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question26_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question27
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question27_field.setText(currentquestion.getQuestion());
            Question27_btn1.setText(currentquestion.getOption1());
            Question27_btn2.setText(currentquestion.getOption2());
            Question27_btn3.setText(currentquestion.getOption3());
            Question27_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question27_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question28
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question28_field.setText(currentquestion.getQuestion());
            Question28_btn1.setText(currentquestion.getOption1());
            Question28_btn2.setText(currentquestion.getOption2());
            Question28_btn3.setText(currentquestion.getOption3());
            Question28_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question28_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question29
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question29_field.setText(currentquestion.getQuestion());
            Question29_btn1.setText(currentquestion.getOption1());
            Question29_btn2.setText(currentquestion.getOption2());
            Question29_btn3.setText(currentquestion.getOption3());
            Question29_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question29_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question30
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question30_field.setText(currentquestion.getQuestion());
            Question30_btn1.setText(currentquestion.getOption1());
            Question30_btn2.setText(currentquestion.getOption2());
            Question30_btn3.setText(currentquestion.getOption3());
            Question30_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question30_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question31
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question31_field.setText(currentquestion.getQuestion());
            Question31_btn1.setText(currentquestion.getOption1());
            Question31_btn2.setText(currentquestion.getOption2());
            Question31_btn3.setText(currentquestion.getOption3());
            Question31_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question31_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question32
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question32_field.setText(currentquestion.getQuestion());
            Question32_btn1.setText(currentquestion.getOption1());
            Question32_btn2.setText(currentquestion.getOption2());
            Question32_btn3.setText(currentquestion.getOption3());
            Question32_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question32_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question33
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question33_field.setText(currentquestion.getQuestion());
            Question33_btn1.setText(currentquestion.getOption1());
            Question33_btn2.setText(currentquestion.getOption2());
            Question33_btn3.setText(currentquestion.getOption3());
            Question33_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question33_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question34
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question34_field.setText(currentquestion.getQuestion());
            Question34_btn1.setText(currentquestion.getOption1());
            Question34_btn2.setText(currentquestion.getOption2());
            Question34_btn3.setText(currentquestion.getOption3());
            Question34_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question34_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question35
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question35_field.setText(currentquestion.getQuestion());
            Question35_btn1.setText(currentquestion.getOption1());
            Question35_btn2.setText(currentquestion.getOption2());
            Question35_btn3.setText(currentquestion.getOption3());
            Question35_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question35_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question36
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question36_field.setText(currentquestion.getQuestion());
            Question36_btn1.setText(currentquestion.getOption1());
            Question36_btn2.setText(currentquestion.getOption2());
            Question36_btn3.setText(currentquestion.getOption3());
            Question36_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question36_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question37
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question37_field.setText(currentquestion.getQuestion());
            Question37_btn1.setText(currentquestion.getOption1());
            Question37_btn2.setText(currentquestion.getOption2());
            Question37_btn3.setText(currentquestion.getOption3());
            Question37_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question37_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question38
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question38_field.setText(currentquestion.getQuestion());
            Question38_btn1.setText(currentquestion.getOption1());
            Question38_btn2.setText(currentquestion.getOption2());
            Question38_btn3.setText(currentquestion.getOption3());
            Question38_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question38_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question39
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question39_field.setText(currentquestion.getQuestion());
            Question39_btn1.setText(currentquestion.getOption1());
            Question39_btn2.setText(currentquestion.getOption2());
            Question39_btn3.setText(currentquestion.getOption3());
            Question39_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question39_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question40
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question40_field.setText(currentquestion.getQuestion());
            Question40_btn1.setText(currentquestion.getOption1());
            Question40_btn2.setText(currentquestion.getOption2());
            Question40_btn3.setText(currentquestion.getOption3());
            Question40_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question40_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question41
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question41_field.setText(currentquestion.getQuestion());
            Question41_btn1.setText(currentquestion.getOption1());
            Question41_btn2.setText(currentquestion.getOption2());
            Question41_btn3.setText(currentquestion.getOption3());
            Question41_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question41_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question42
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question42_field.setText(currentquestion.getQuestion());
            Question42_btn1.setText(currentquestion.getOption1());
            Question42_btn2.setText(currentquestion.getOption2());
            Question42_btn3.setText(currentquestion.getOption3());
            Question42_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question42_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question43
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question43_field.setText(currentquestion.getQuestion());
            Question43_btn1.setText(currentquestion.getOption1());
            Question43_btn2.setText(currentquestion.getOption2());
            Question43_btn3.setText(currentquestion.getOption3());
            Question43_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question43_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question44
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question44_field.setText(currentquestion.getQuestion());
            Question44_btn1.setText(currentquestion.getOption1());
            Question44_btn2.setText(currentquestion.getOption2());
            Question44_btn3.setText(currentquestion.getOption3());
            Question44_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question44_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question45
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question45_field.setText(currentquestion.getQuestion());
            Question45_btn1.setText(currentquestion.getOption1());
            Question45_btn2.setText(currentquestion.getOption2());
            Question45_btn3.setText(currentquestion.getOption3());
            Question45_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question45_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question46
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question46_field.setText(currentquestion.getQuestion());
            Question46_btn1.setText(currentquestion.getOption1());
            Question46_btn2.setText(currentquestion.getOption2());
            Question46_btn3.setText(currentquestion.getOption3());
            Question46_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question46_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question47
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question47_field.setText(currentquestion.getQuestion());
            Question47_btn1.setText(currentquestion.getOption1());
            Question47_btn2.setText(currentquestion.getOption2());
            Question47_btn3.setText(currentquestion.getOption3());
            Question47_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question47_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question48
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question48_field.setText(currentquestion.getQuestion());
            Question48_btn1.setText(currentquestion.getOption1());
            Question48_btn2.setText(currentquestion.getOption2());
            Question48_btn3.setText(currentquestion.getOption3());
            Question48_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question48_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question49
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question49_field.setText(currentquestion.getQuestion());
            Question49_btn1.setText(currentquestion.getOption1());
            Question49_btn2.setText(currentquestion.getOption2());
            Question49_btn3.setText(currentquestion.getOption3());
            Question49_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question49_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question50
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question50_field.setText(currentquestion.getQuestion());
            Question50_btn1.setText(currentquestion.getOption1());
            Question50_btn2.setText(currentquestion.getOption2());
            Question50_btn3.setText(currentquestion.getOption3());
            Question50_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question50_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question51
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question51_field.setText(currentquestion.getQuestion());
            Question51_btn1.setText(currentquestion.getOption1());
            Question51_btn2.setText(currentquestion.getOption2());
            Question51_btn3.setText(currentquestion.getOption3());
            Question51_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question51_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question52
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question52_field.setText(currentquestion.getQuestion());
            Question52_btn1.setText(currentquestion.getOption1());
            Question52_btn2.setText(currentquestion.getOption2());
            Question52_btn3.setText(currentquestion.getOption3());
            Question52_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question52_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question53
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question53_field.setText(currentquestion.getQuestion());
            Question53_btn1.setText(currentquestion.getOption1());
            Question53_btn2.setText(currentquestion.getOption2());
            Question53_btn3.setText(currentquestion.getOption3());
            Question53_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question53_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question54
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question54_field.setText(currentquestion.getQuestion());
            Question54_btn1.setText(currentquestion.getOption1());
            Question54_btn2.setText(currentquestion.getOption2());
            Question54_btn3.setText(currentquestion.getOption3());
            Question54_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question54_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question55
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question55_field.setText(currentquestion.getQuestion());
            Question55_btn1.setText(currentquestion.getOption1());
            Question55_btn2.setText(currentquestion.getOption2());
            Question55_btn3.setText(currentquestion.getOption3());
            Question55_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question55_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question56
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question56_field.setText(currentquestion.getQuestion());
            Question56_btn1.setText(currentquestion.getOption1());
            Question56_btn2.setText(currentquestion.getOption2());
            Question56_btn3.setText(currentquestion.getOption3());
            Question56_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question56_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question57
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question57_field.setText(currentquestion.getQuestion());
            Question57_btn1.setText(currentquestion.getOption1());
            Question57_btn2.setText(currentquestion.getOption2());
            Question57_btn3.setText(currentquestion.getOption3());
            Question57_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question57_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question58
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question58_field.setText(currentquestion.getQuestion());
            Question58_btn1.setText(currentquestion.getOption1());
            Question58_btn2.setText(currentquestion.getOption2());
            Question58_btn3.setText(currentquestion.getOption3());
            Question58_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question58_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question59
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question59_field.setText(currentquestion.getQuestion());
            Question59_btn1.setText(currentquestion.getOption1());
            Question59_btn2.setText(currentquestion.getOption2());
            Question59_btn3.setText(currentquestion.getOption3());
            Question59_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question59_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question60
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question60_field.setText(currentquestion.getQuestion());
            Question60_btn1.setText(currentquestion.getOption1());
            Question60_btn2.setText(currentquestion.getOption2());
            Question60_btn3.setText(currentquestion.getOption3());
            Question60_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question60_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question61
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question61_field.setText(currentquestion.getQuestion());
            Question61_btn1.setText(currentquestion.getOption1());
            Question61_btn2.setText(currentquestion.getOption2());
            Question61_btn3.setText(currentquestion.getOption3());
            Question61_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question61_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question62
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question62_field.setText(currentquestion.getQuestion());
            Question62_btn1.setText(currentquestion.getOption1());
            Question62_btn2.setText(currentquestion.getOption2());
            Question62_btn3.setText(currentquestion.getOption3());
            Question62_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question62_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question63
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question63_field.setText(currentquestion.getQuestion());
            Question63_btn1.setText(currentquestion.getOption1());
            Question63_btn2.setText(currentquestion.getOption2());
            Question63_btn3.setText(currentquestion.getOption3());
            Question63_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question63_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question64
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question64_field.setText(currentquestion.getQuestion());
            Question64_btn1.setText(currentquestion.getOption1());
            Question64_btn2.setText(currentquestion.getOption2());
            Question64_btn3.setText(currentquestion.getOption3());
            Question64_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question64_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question65
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question65_field.setText(currentquestion.getQuestion());
            Question65_btn1.setText(currentquestion.getOption1());
            Question65_btn2.setText(currentquestion.getOption2());
            Question65_btn3.setText(currentquestion.getOption3());
            Question65_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question65_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question66
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question66_field.setText(currentquestion.getQuestion());
            Question66_btn1.setText(currentquestion.getOption1());
            Question66_btn2.setText(currentquestion.getOption2());
            Question66_btn3.setText(currentquestion.getOption3());
            Question66_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question66_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question67
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question67_field.setText(currentquestion.getQuestion());
            Question67_btn1.setText(currentquestion.getOption1());
            Question67_btn2.setText(currentquestion.getOption2());
            Question67_btn3.setText(currentquestion.getOption3());
            Question67_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question67_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question68
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question68_field.setText(currentquestion.getQuestion());
            Question68_btn1.setText(currentquestion.getOption1());
            Question68_btn2.setText(currentquestion.getOption2());
            Question68_btn3.setText(currentquestion.getOption3());
            Question68_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question68_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question69
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question69_field.setText(currentquestion.getQuestion());
            Question69_btn1.setText(currentquestion.getOption1());
            Question69_btn2.setText(currentquestion.getOption2());
            Question69_btn3.setText(currentquestion.getOption3());
            Question69_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question69_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question70
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question70_field.setText(currentquestion.getQuestion());
            Question70_btn1.setText(currentquestion.getOption1());
            Question70_btn2.setText(currentquestion.getOption2());
            Question70_btn3.setText(currentquestion.getOption3());
            Question70_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question70_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question71
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question71_field.setText(currentquestion.getQuestion());
            Question71_btn1.setText(currentquestion.getOption1());
            Question71_btn2.setText(currentquestion.getOption2());
            Question71_btn3.setText(currentquestion.getOption3());
            Question71_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question71_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question72
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question72_field.setText(currentquestion.getQuestion());
            Question72_btn1.setText(currentquestion.getOption1());
            Question72_btn2.setText(currentquestion.getOption2());
            Question72_btn3.setText(currentquestion.getOption3());
            Question72_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question72_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question73
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question73_field.setText(currentquestion.getQuestion());
            Question73_btn1.setText(currentquestion.getOption1());
            Question73_btn2.setText(currentquestion.getOption2());
            Question73_btn3.setText(currentquestion.getOption3());
            Question73_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question73_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question74
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question74_field.setText(currentquestion.getQuestion());
            Question74_btn1.setText(currentquestion.getOption1());
            Question74_btn2.setText(currentquestion.getOption2());
            Question74_btn3.setText(currentquestion.getOption3());
            Question74_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question74_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question75
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question75_field.setText(currentquestion.getQuestion());
            Question75_btn1.setText(currentquestion.getOption1());
            Question75_btn2.setText(currentquestion.getOption2());
            Question75_btn3.setText(currentquestion.getOption3());
            Question75_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question75_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question76
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question76_field.setText(currentquestion.getQuestion());
            Question76_btn1.setText(currentquestion.getOption1());
            Question76_btn2.setText(currentquestion.getOption2());
            Question76_btn3.setText(currentquestion.getOption3());
            Question76_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question76_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question77
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question77_field.setText(currentquestion.getQuestion());
            Question77_btn1.setText(currentquestion.getOption1());
            Question77_btn2.setText(currentquestion.getOption2());
            Question77_btn3.setText(currentquestion.getOption3());
            Question77_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question77_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question78
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question78_field.setText(currentquestion.getQuestion());
            Question78_btn1.setText(currentquestion.getOption1());
            Question78_btn2.setText(currentquestion.getOption2());
            Question78_btn3.setText(currentquestion.getOption3());
            Question78_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question78_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question79
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question79_field.setText(currentquestion.getQuestion());
            Question79_btn1.setText(currentquestion.getOption1());
            Question79_btn2.setText(currentquestion.getOption2());
            Question79_btn3.setText(currentquestion.getOption3());
            Question79_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);


            counter++;
            Question79_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question80
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question80_field.setText(currentquestion.getQuestion());
            Question80_btn1.setText(currentquestion.getOption1());
            Question80_btn2.setText(currentquestion.getOption2());
            Question80_btn3.setText(currentquestion.getOption3());
            Question80_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question80_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question81
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question81_field.setText(currentquestion.getQuestion());
            Question81_btn1.setText(currentquestion.getOption1());
            Question81_btn2.setText(currentquestion.getOption2());
            Question81_btn3.setText(currentquestion.getOption3());
            Question81_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question81_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question82
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question82_field.setText(currentquestion.getQuestion());
            Question82_btn1.setText(currentquestion.getOption1());
            Question82_btn2.setText(currentquestion.getOption2());
            Question82_btn3.setText(currentquestion.getOption3());
            Question82_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question82_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question83
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question83_field.setText(currentquestion.getQuestion());
            Question83_btn1.setText(currentquestion.getOption1());
            Question83_btn2.setText(currentquestion.getOption2());
            Question83_btn3.setText(currentquestion.getOption3());
            Question83_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question83_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question84
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question84_field.setText(currentquestion.getQuestion());
            Question84_btn1.setText(currentquestion.getOption1());
            Question84_btn2.setText(currentquestion.getOption2());
            Question84_btn3.setText(currentquestion.getOption3());
            Question84_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question84_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question85
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question85_field.setText(currentquestion.getQuestion());
            Question85_btn1.setText(currentquestion.getOption1());
            Question85_btn2.setText(currentquestion.getOption2());
            Question85_btn3.setText(currentquestion.getOption3());
            Question85_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question85_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question86
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question86_field.setText(currentquestion.getQuestion());
            Question86_btn1.setText(currentquestion.getOption1());
            Question86_btn2.setText(currentquestion.getOption2());
            Question86_btn3.setText(currentquestion.getOption3());
            Question86_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question86_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question87
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question87_field.setText(currentquestion.getQuestion());
            Question87_btn1.setText(currentquestion.getOption1());
            Question87_btn2.setText(currentquestion.getOption2());
            Question87_btn3.setText(currentquestion.getOption3());
            Question87_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question87_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question88
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question88_field.setText(currentquestion.getQuestion());
            Question88_btn1.setText(currentquestion.getOption1());
            Question88_btn2.setText(currentquestion.getOption2());
            Question88_btn3.setText(currentquestion.getOption3());
            Question88_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question88_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question89
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question89_field.setText(currentquestion.getQuestion());
            Question89_btn1.setText(currentquestion.getOption1());
            Question89_btn2.setText(currentquestion.getOption2());
            Question89_btn3.setText(currentquestion.getOption3());
            Question89_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question89_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question90
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question90_field.setText(currentquestion.getQuestion());
            Question90_btn1.setText(currentquestion.getOption1());
            Question90_btn2.setText(currentquestion.getOption2());
            Question90_btn3.setText(currentquestion.getOption3());
            Question90_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question90_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question91
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question91_field.setText(currentquestion.getQuestion());
            Question91_btn1.setText(currentquestion.getOption1());
            Question91_btn2.setText(currentquestion.getOption2());
            Question91_btn3.setText(currentquestion.getOption3());
            Question91_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question91_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question92
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question92_field.setText(currentquestion.getQuestion());
            Question92_btn1.setText(currentquestion.getOption1());
            Question92_btn2.setText(currentquestion.getOption2());
            Question92_btn3.setText(currentquestion.getOption3());
            Question92_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question92_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question93
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question93_field.setText(currentquestion.getQuestion());
            Question93_btn1.setText(currentquestion.getOption1());
            Question93_btn2.setText(currentquestion.getOption2());
            Question93_btn3.setText(currentquestion.getOption3());
            Question93_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question93_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question94
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question94_field.setText(currentquestion.getQuestion());
            Question94_btn1.setText(currentquestion.getOption1());
            Question94_btn2.setText(currentquestion.getOption2());
            Question94_btn3.setText(currentquestion.getOption3());
            Question94_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question94_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question95
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question95_field.setText(currentquestion.getQuestion());
            Question95_btn1.setText(currentquestion.getOption1());
            Question95_btn2.setText(currentquestion.getOption2());
            Question95_btn3.setText(currentquestion.getOption3());
            Question95_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question95_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question96
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question96_field.setText(currentquestion.getQuestion());
            Question96_btn1.setText(currentquestion.getOption1());
            Question96_btn2.setText(currentquestion.getOption2());
            Question96_btn3.setText(currentquestion.getOption3());
            Question96_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question96_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question97
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question97_field.setText(currentquestion.getQuestion());
            Question97_btn1.setText(currentquestion.getOption1());
            Question97_btn2.setText(currentquestion.getOption2());
            Question97_btn3.setText(currentquestion.getOption3());
            Question97_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question97_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question98
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question98_field.setText(currentquestion.getQuestion());
            Question98_btn1.setText(currentquestion.getOption1());
            Question98_btn2.setText(currentquestion.getOption2());
            Question98_btn3.setText(currentquestion.getOption3());
            Question98_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question98_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question99
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question99_field.setText(currentquestion.getQuestion());
            Question99_btn1.setText(currentquestion.getOption1());
            Question99_btn2.setText(currentquestion.getOption2());
            Question99_btn3.setText(currentquestion.getOption3());
            Question99_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question99_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question100
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question100_field.setText(currentquestion.getQuestion());
            Question100_btn1.setText(currentquestion.getOption1());
            Question100_btn2.setText(currentquestion.getOption2());
            Question100_btn3.setText(currentquestion.getOption3());
            Question100_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question100_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question101
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question101_field.setText(currentquestion.getQuestion());
            Question101_btn1.setText(currentquestion.getOption1());
            Question101_btn2.setText(currentquestion.getOption2());
            Question101_btn3.setText(currentquestion.getOption3());
            Question101_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question101_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question102
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question102_field.setText(currentquestion.getQuestion());
            Question102_btn1.setText(currentquestion.getOption1());
            Question102_btn2.setText(currentquestion.getOption2());
            Question102_btn3.setText(currentquestion.getOption3());
            Question102_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question102_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question103
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question103_field.setText(currentquestion.getQuestion());
            Question103_btn1.setText(currentquestion.getOption1());
            Question103_btn2.setText(currentquestion.getOption2());
            Question103_btn3.setText(currentquestion.getOption3());
            Question103_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question103_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question104
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question104_field.setText(currentquestion.getQuestion());
            Question104_btn1.setText(currentquestion.getOption1());
            Question104_btn2.setText(currentquestion.getOption2());
            Question104_btn3.setText(currentquestion.getOption3());
            Question104_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question104_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question105
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question105_field.setText(currentquestion.getQuestion());
            Question105_btn1.setText(currentquestion.getOption1());
            Question105_btn2.setText(currentquestion.getOption2());
            Question105_btn3.setText(currentquestion.getOption3());
            Question105_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question105_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question106
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question106_field.setText(currentquestion.getQuestion());
            Question106_btn1.setText(currentquestion.getOption1());
            Question106_btn2.setText(currentquestion.getOption2());
            Question106_btn3.setText(currentquestion.getOption3());
            Question106_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question106_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question107
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question107_field.setText(currentquestion.getQuestion());
            Question107_btn1.setText(currentquestion.getOption1());
            Question107_btn2.setText(currentquestion.getOption2());
            Question107_btn3.setText(currentquestion.getOption3());
            Question107_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question107_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question108
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question108_field.setText(currentquestion.getQuestion());
            Question108_btn1.setText(currentquestion.getOption1());
            Question108_btn2.setText(currentquestion.getOption2());
            Question108_btn3.setText(currentquestion.getOption3());
            Question108_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question108_item.setText("Question " + counter + " / " + totalcount);

        }
        //
        //
        //setting Question and Choices in  Question109
        //
        //
        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            Question109_field.setText(currentquestion.getQuestion());
            Question109_btn1.setText(currentquestion.getOption1());
            Question109_btn2.setText(currentquestion.getOption2());
            Question109_btn3.setText(currentquestion.getOption3());
            Question109_btn4.setText(currentquestion.getOption4());

            answerkeys.add(currentquestion.getAnswer());
            answerKeys = answerkeys.toArray(answerKeys);

            answer = false;
            counter++;
            Question109_item.setText("Question " + counter + " / " + totalcount);

        }




        else {
            finishquiz();
        }


    }

    //
    //
    //answer key of QUESTION 1
    //
    //
    private void showSolution()
    {
        Question1_btn1.setTextColor(Color.rgb(255,60,60));
        Question1_btn2.setTextColor(Color.rgb(255,60,60));
        Question1_btn3.setTextColor(Color.rgb(255,60,60));
        Question1_btn4.setTextColor(Color.rgb(255,60,60));
        Question1_btn1.setEnabled(false);
        Question1_btn2.setEnabled(false);
        Question1_btn3.setEnabled(false);
        Question1_btn4.setEnabled(false);

        switch (answerKeys[0])
        {
            case 1:
                Question1_btn1.setTextColor(Color.rgb(79,255,60));
                break;
            case 2:
                Question1_btn2.setTextColor(Color.rgb(79,255,60));
                break;
            case 3:
                Question1_btn3.setTextColor(Color.rgb(79,255,60));

                break;
            case 4:
                Question1_btn4.setTextColor(Color.rgb(79,255,60));
                break;
        }

    }

    //
    //
    //answer key of QUESTION 2
    //
    //
    public  void showSolution2()
    {
        Question2_btn1.setTextColor(Color.RED);
        Question2_btn2.setTextColor(Color.RED);
        Question2_btn3.setTextColor(Color.RED);
        Question2_btn4.setTextColor(Color.RED);
        Question2_btn1.setEnabled(false);
        Question2_btn2.setEnabled(false);
        Question2_btn3.setEnabled(false);
        Question2_btn4.setEnabled(false);
        switch (answerKeys[1])
        {
            case 1:
                Question2_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question2_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question2_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question2_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION 3
    //
    //
    private void showSolution3()
    {
        Question3_btn1.setTextColor(Color.RED);
        Question3_btn2.setTextColor(Color.RED);
        Question3_btn3.setTextColor(Color.RED);
        Question3_btn4.setTextColor(Color.RED);
        Question3_btn1.setEnabled(false);
        Question3_btn2.setEnabled(false);
        Question3_btn3.setEnabled(false);
        Question3_btn4.setEnabled(false);

        switch (answerKeys[2])
        {
            case 1:
                Question3_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question3_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question3_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question3_btn4.setTextColor(Color.GREEN);
                break;
        }

    }
    //
    //
    //answer key of QUESTION 4
    //
    //
    private void showSolution4()
    {
        Question4_btn1.setTextColor(Color.RED);
        Question4_btn2.setTextColor(Color.RED);
        Question4_btn3.setTextColor(Color.RED);
        Question4_btn4.setTextColor(Color.RED);
        Question4_btn1.setEnabled(false);
        Question4_btn2.setEnabled(false);
        Question4_btn3.setEnabled(false);
        Question4_btn4.setEnabled(false);

        switch (answerKeys[3])
        {
            case 1:
                Question4_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question4_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question4_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question4_btn4.setTextColor(Color.GREEN);
                break;
        }

    }
    //
    //
    //answer key of QUESTION 5
    //
    //
    public  void showSolution5()
    {
        Question5_btn1.setTextColor(Color.RED);
        Question5_btn2.setTextColor(Color.RED);
        Question5_btn3.setTextColor(Color.RED);
        Question5_btn4.setTextColor(Color.RED);
        Question5_btn1.setEnabled(false);
        Question5_btn2.setEnabled(false);
        Question5_btn3.setEnabled(false);
        Question5_btn4.setEnabled(false);
        switch (answerKeys[4])
        {
            case 1:
                Question5_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question5_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question5_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question5_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION 6
    //
    //
    public  void showSolution6()
    {
        Question6_btn1.setTextColor(Color.RED);
        Question6_btn2.setTextColor(Color.RED);
        Question6_btn3.setTextColor(Color.RED);
        Question6_btn4.setTextColor(Color.RED);
        Question6_btn1.setEnabled(false);
        Question6_btn2.setEnabled(false);
        Question6_btn3.setEnabled(false);
        Question6_btn4.setEnabled(false);
        switch (answerKeys[5])
        {
            case 1:
                Question6_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question6_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question6_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question6_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION 6
    //
    //
    public  void showSolution7()
    {
        Question7_btn1.setTextColor(Color.RED);
        Question7_btn2.setTextColor(Color.RED);
        Question7_btn3.setTextColor(Color.RED);
        Question7_btn4.setTextColor(Color.RED);
        Question7_btn1.setEnabled(false);
        Question7_btn2.setEnabled(false);
        Question7_btn3.setEnabled(false);
        Question7_btn4.setEnabled(false);
        switch (answerKeys[6])
        {
            case 1:
                Question7_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question7_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question7_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question7_btn4.setTextColor(Color.GREEN);
                break;
        }
    } //
    //
    //answer key of QUESTION 8
    //
    //
    public  void showSolution8()
    {
        Question8_btn1.setTextColor(Color.RED);
        Question8_btn2.setTextColor(Color.RED);
        Question8_btn3.setTextColor(Color.RED);
        Question8_btn4.setTextColor(Color.RED);
        Question8_btn1.setEnabled(false);
        Question8_btn2.setEnabled(false);
        Question8_btn3.setEnabled(false);
        Question8_btn4.setEnabled(false);
        switch (answerKeys[7])
        {
            case 1:
                Question8_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question8_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question8_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question8_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION 9
    //
    //
    public  void showSolution9()
    {
        Question9_btn1.setTextColor(Color.RED);
        Question9_btn2.setTextColor(Color.RED);
        Question9_btn3.setTextColor(Color.RED);
        Question9_btn4.setTextColor(Color.RED);
        Question9_btn1.setEnabled(false);
        Question9_btn2.setEnabled(false);
        Question9_btn3.setEnabled(false);
        Question9_btn4.setEnabled(false);
        switch (answerKeys[8])
        {
            case 1:
                Question9_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question9_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question9_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question9_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION10
    //
    //
    public  void showSolution10()
    {
        Question10_btn1.setTextColor(Color.RED);
        Question10_btn2.setTextColor(Color.RED);
        Question10_btn3.setTextColor(Color.RED);
        Question10_btn4.setTextColor(Color.RED);
        Question10_btn1.setEnabled(false);
        Question10_btn2.setEnabled(false);
        Question10_btn3.setEnabled(false);
        Question10_btn4.setEnabled(false);
        switch (answerKeys[9])
        {
            case 1:
                Question10_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question10_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question10_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question10_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION11
    //
    //
    public  void showSolution11()
    {
        Question11_btn1.setTextColor(Color.RED);
        Question11_btn2.setTextColor(Color.RED);
        Question11_btn3.setTextColor(Color.RED);
        Question11_btn4.setTextColor(Color.RED);
        Question11_btn1.setEnabled(false);
        Question11_btn2.setEnabled(false);
        Question11_btn3.setEnabled(false);
        Question11_btn4.setEnabled(false);
        switch (answerKeys[10])
        {
            case 1:
                Question11_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question11_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question11_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question11_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION11
    //
    //
    public  void showSolution12()
    {
        Question12_btn1.setTextColor(Color.RED);
        Question12_btn2.setTextColor(Color.RED);
        Question12_btn3.setTextColor(Color.RED);
        Question12_btn4.setTextColor(Color.RED);
        Question12_btn1.setEnabled(false);
        Question12_btn2.setEnabled(false);
        Question12_btn3.setEnabled(false);
        Question12_btn4.setEnabled(false);
        switch (answerKeys[11])
        {
            case 1:
                Question12_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question12_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question12_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question12_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION13
    //
    //
    public  void showSolution13()
    {
        Question13_btn1.setTextColor(Color.RED);
        Question13_btn2.setTextColor(Color.RED);
        Question13_btn3.setTextColor(Color.RED);
        Question13_btn4.setTextColor(Color.RED);
        Question13_btn1.setEnabled(false);
        Question13_btn2.setEnabled(false);
        Question13_btn3.setEnabled(false);
        Question13_btn4.setEnabled(false);
        switch (answerKeys[12])
        {
            case 1:
                Question13_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question13_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question13_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question13_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION14
    //
    //
    public  void showSolution14()
    {
        Question14_btn1.setTextColor(Color.RED);
        Question14_btn2.setTextColor(Color.RED);
        Question14_btn3.setTextColor(Color.RED);
        Question14_btn4.setTextColor(Color.RED);
        Question14_btn1.setEnabled(false);
        Question14_btn2.setEnabled(false);
        Question14_btn3.setEnabled(false);
        Question14_btn4.setEnabled(false);
        switch (answerKeys[13])
        {
            case 1:
                Question14_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question14_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question14_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question14_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION15
    //
    //
    public  void showSolution15()
    {
        Question15_btn1.setTextColor(Color.RED);
        Question15_btn2.setTextColor(Color.RED);
        Question15_btn3.setTextColor(Color.RED);
        Question15_btn4.setTextColor(Color.RED);
        Question15_btn1.setEnabled(false);
        Question15_btn2.setEnabled(false);
        Question15_btn3.setEnabled(false);
        Question15_btn4.setEnabled(false);
        switch (answerKeys[14])
        {
            case 1:
                Question15_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question15_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question15_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question15_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION16
    //
    //
    public  void showSolution16()
    {
        Question16_btn1.setTextColor(Color.RED);
        Question16_btn2.setTextColor(Color.RED);
        Question16_btn3.setTextColor(Color.RED);
        Question16_btn4.setTextColor(Color.RED);
        Question16_btn1.setEnabled(false);
        Question16_btn2.setEnabled(false);
        Question16_btn3.setEnabled(false);
        Question16_btn4.setEnabled(false);
        switch (answerKeys[15])
        {
            case 1:
                Question16_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question16_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question16_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question16_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION17
    //
    //
    public  void showSolution17()
    {
        Question17_btn1.setTextColor(Color.RED);
        Question17_btn2.setTextColor(Color.RED);
        Question17_btn3.setTextColor(Color.RED);
        Question17_btn4.setTextColor(Color.RED);
        Question17_btn1.setEnabled(false);
        Question17_btn2.setEnabled(false);
        Question17_btn3.setEnabled(false);
        Question17_btn4.setEnabled(false);
        switch (answerKeys[16])
        {
            case 1:
                Question17_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question17_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question17_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question17_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION18
    //
    //
    public  void showSolution18()
    {
        Question18_btn1.setTextColor(Color.RED);
        Question18_btn2.setTextColor(Color.RED);
        Question18_btn3.setTextColor(Color.RED);
        Question18_btn4.setTextColor(Color.RED);
        Question18_btn1.setEnabled(false);
        Question18_btn2.setEnabled(false);
        Question18_btn3.setEnabled(false);
        Question18_btn4.setEnabled(false);
        switch (answerKeys[17])
        {
            case 1:
                Question18_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question18_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question18_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question18_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of QUESTION19
    //
    //
    public  void showSolution19()
    {
        Question19_btn1.setTextColor(Color.RED);
        Question19_btn2.setTextColor(Color.RED);
        Question19_btn3.setTextColor(Color.RED);
        Question19_btn4.setTextColor(Color.RED);
        Question19_btn1.setEnabled(false);
        Question19_btn2.setEnabled(false);
        Question19_btn3.setEnabled(false);
        Question19_btn4.setEnabled(false);
        switch (answerKeys[18])
        {
            case 1:
                Question19_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question19_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question19_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question19_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question20
    //
    //
    public  void showSolution20()
    {
        Question20_btn1.setTextColor(Color.RED);
        Question20_btn2.setTextColor(Color.RED);
        Question20_btn3.setTextColor(Color.RED);
        Question20_btn4.setTextColor(Color.RED);
        Question20_btn1.setEnabled(false);
        Question20_btn2.setEnabled(false);
        Question20_btn3.setEnabled(false);
        Question20_btn4.setEnabled(false);
        switch (answerKeys[19])
        {
            case 1:
                Question20_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question20_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question20_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question20_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question21
    //
    //
    public  void showSolution21()
    {
        Question21_btn1.setTextColor(Color.RED);
        Question21_btn2.setTextColor(Color.RED);
        Question21_btn3.setTextColor(Color.RED);
        Question21_btn4.setTextColor(Color.RED);
        Question21_btn1.setEnabled(false);
        Question21_btn2.setEnabled(false);
        Question21_btn3.setEnabled(false);
        Question21_btn4.setEnabled(false);
        switch (answerKeys[20])
        {
            case 1:
                Question21_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question21_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question21_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question21_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question22
    //
    //
    public  void showSolution22()
    {
        Question22_btn1.setTextColor(Color.RED);
        Question22_btn2.setTextColor(Color.RED);
        Question22_btn3.setTextColor(Color.RED);
        Question22_btn4.setTextColor(Color.RED);
        Question22_btn1.setEnabled(false);
        Question22_btn2.setEnabled(false);
        Question22_btn3.setEnabled(false);
        Question22_btn4.setEnabled(false);
        switch (answerKeys[21])
        {
            case 1:
                Question22_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question22_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question22_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question22_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question23
    //
    //
    public  void showSolution23()
    {
        Question23_btn1.setTextColor(Color.RED);
        Question23_btn2.setTextColor(Color.RED);
        Question23_btn3.setTextColor(Color.RED);
        Question23_btn4.setTextColor(Color.RED);
        Question23_btn1.setEnabled(false);
        Question23_btn2.setEnabled(false);
        Question23_btn3.setEnabled(false);
        Question23_btn4.setEnabled(false);
        switch (answerKeys[22])
        {
            case 1:
                Question23_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question23_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question23_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question23_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question24
    //
    //
    public  void showSolution24()
    {
        Question24_btn1.setTextColor(Color.RED);
        Question24_btn2.setTextColor(Color.RED);
        Question24_btn3.setTextColor(Color.RED);
        Question24_btn4.setTextColor(Color.RED);
        Question24_btn1.setEnabled(false);
        Question24_btn2.setEnabled(false);
        Question24_btn3.setEnabled(false);
        Question24_btn4.setEnabled(false);
        switch (answerKeys[23])
        {
            case 1:
                Question24_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question24_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question24_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question24_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question25
    //
    //
    public  void showSolution25()
    {
        Question25_btn1.setTextColor(Color.RED);
        Question25_btn2.setTextColor(Color.RED);
        Question25_btn3.setTextColor(Color.RED);
        Question25_btn4.setTextColor(Color.RED);
        Question25_btn1.setEnabled(false);
        Question25_btn2.setEnabled(false);
        Question25_btn3.setEnabled(false);
        Question25_btn4.setEnabled(false);
        switch (answerKeys[24])
        {
            case 1:
                Question25_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question25_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question25_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question25_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question26
    //
    //
    public  void showSolution26()
    {
        Question26_btn1.setTextColor(Color.RED);
        Question26_btn2.setTextColor(Color.RED);
        Question26_btn3.setTextColor(Color.RED);
        Question26_btn4.setTextColor(Color.RED);
        Question26_btn1.setEnabled(false);
        Question26_btn2.setEnabled(false);
        Question26_btn3.setEnabled(false);
        Question26_btn4.setEnabled(false);
        switch (answerKeys[25])
        {
            case 1:
                Question26_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question26_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question26_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question26_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question27
    //
    //
    public  void showSolution27()
    {
        Question27_btn1.setTextColor(Color.RED);
        Question27_btn2.setTextColor(Color.RED);
        Question27_btn3.setTextColor(Color.RED);
        Question27_btn4.setTextColor(Color.RED);
        Question27_btn1.setEnabled(false);
        Question27_btn2.setEnabled(false);
        Question27_btn3.setEnabled(false);
        Question27_btn4.setEnabled(false);
        switch (answerKeys[26])
        {
            case 1:
                Question27_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question27_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question27_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question27_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question28
    //
    //
    public  void showSolution28()
    {
        Question28_btn1.setTextColor(Color.RED);
        Question28_btn2.setTextColor(Color.RED);
        Question28_btn3.setTextColor(Color.RED);
        Question28_btn4.setTextColor(Color.RED);
        Question28_btn1.setEnabled(false);
        Question28_btn2.setEnabled(false);
        Question28_btn3.setEnabled(false);
        Question28_btn4.setEnabled(false);
        switch (answerKeys[27])
        {
            case 1:
                Question28_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question28_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question28_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question28_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question29
    //
    //
    public  void showSolution29()
    {
        Question29_btn1.setTextColor(Color.RED);
        Question29_btn2.setTextColor(Color.RED);
        Question29_btn3.setTextColor(Color.RED);
        Question29_btn4.setTextColor(Color.RED);
        Question29_btn1.setEnabled(false);
        Question29_btn2.setEnabled(false);
        Question29_btn3.setEnabled(false);
        Question29_btn4.setEnabled(false);
        switch (answerKeys[28])
        {
            case 1:
                Question29_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question29_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question29_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question29_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question30
    //
    //
    public  void showSolution30()
    {
        Question30_btn1.setTextColor(Color.RED);
        Question30_btn2.setTextColor(Color.RED);
        Question30_btn3.setTextColor(Color.RED);
        Question30_btn4.setTextColor(Color.RED);
        Question30_btn1.setEnabled(false);
        Question30_btn2.setEnabled(false);
        Question30_btn3.setEnabled(false);
        Question30_btn4.setEnabled(false);
        switch (answerKeys[29])
        {
            case 1:
                Question30_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question30_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question30_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question30_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question31
    //
    //
    public  void showSolution31()
    {
        Question31_btn1.setTextColor(Color.RED);
        Question31_btn2.setTextColor(Color.RED);
        Question31_btn3.setTextColor(Color.RED);
        Question31_btn4.setTextColor(Color.RED);
        Question31_btn1.setEnabled(false);
        Question31_btn2.setEnabled(false);
        Question31_btn3.setEnabled(false);
        Question31_btn4.setEnabled(false);
        switch (answerKeys[30])
        {
            case 1:
                Question31_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question31_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question31_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question31_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question31
    //
    //
    public  void showSolution32()
    {
        Question32_btn1.setTextColor(Color.RED);
        Question32_btn2.setTextColor(Color.RED);
        Question32_btn3.setTextColor(Color.RED);
        Question32_btn4.setTextColor(Color.RED);
        Question32_btn1.setEnabled(false);
        Question32_btn2.setEnabled(false);
        Question32_btn3.setEnabled(false);
        Question32_btn4.setEnabled(false);
        switch (answerKeys[31])
        {
            case 1:
                Question32_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question32_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question32_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question32_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question33
    //
    //
    public  void showSolution33()
    {
        Question33_btn1.setTextColor(Color.RED);
        Question33_btn2.setTextColor(Color.RED);
        Question33_btn3.setTextColor(Color.RED);
        Question33_btn4.setTextColor(Color.RED);
        Question33_btn1.setEnabled(false);
        Question33_btn2.setEnabled(false);
        Question33_btn3.setEnabled(false);
        Question33_btn4.setEnabled(false);
        switch (answerKeys[32])
        {
            case 1:
                Question33_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question33_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question33_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question33_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question34
    //
    //
    public  void showSolution34()
    {
        Question34_btn1.setTextColor(Color.RED);
        Question34_btn2.setTextColor(Color.RED);
        Question34_btn3.setTextColor(Color.RED);
        Question34_btn4.setTextColor(Color.RED);
        Question34_btn1.setEnabled(false);
        Question34_btn2.setEnabled(false);
        Question34_btn3.setEnabled(false);
        Question34_btn4.setEnabled(false);
        switch (answerKeys[33])
        {
            case 1:
                Question34_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question34_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question34_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question34_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question35
    //
    //
    public  void showSolution35()
    {
        Question35_btn1.setTextColor(Color.RED);
        Question35_btn2.setTextColor(Color.RED);
        Question35_btn3.setTextColor(Color.RED);
        Question35_btn4.setTextColor(Color.RED);
        Question35_btn1.setEnabled(false);
        Question35_btn2.setEnabled(false);
        Question35_btn3.setEnabled(false);
        Question35_btn4.setEnabled(false);
        switch (answerKeys[34])
        {
            case 1:
                Question35_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question35_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question35_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question35_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question36
    //
    //
    public  void showSolution36()
    {
        Question36_btn1.setTextColor(Color.RED);
        Question36_btn2.setTextColor(Color.RED);
        Question36_btn3.setTextColor(Color.RED);
        Question36_btn4.setTextColor(Color.RED);
        Question36_btn1.setEnabled(false);
        Question36_btn2.setEnabled(false);
        Question36_btn3.setEnabled(false);
        Question36_btn4.setEnabled(false);
        switch (answerKeys[35])
        {
            case 1:
                Question36_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question36_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question36_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question36_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question37
    //
    //
    public  void showSolution37()
    {
        Question37_btn1.setTextColor(Color.RED);
        Question37_btn2.setTextColor(Color.RED);
        Question37_btn3.setTextColor(Color.RED);
        Question37_btn4.setTextColor(Color.RED);
        Question37_btn1.setEnabled(false);
        Question37_btn2.setEnabled(false);
        Question37_btn3.setEnabled(false);
        Question37_btn4.setEnabled(false);
        switch (answerKeys[36])
        {
            case 1:
                Question37_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question37_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question37_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question37_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question38
    //
    //
    public  void showSolution38()
    {
        Question38_btn1.setTextColor(Color.RED);
        Question38_btn2.setTextColor(Color.RED);
        Question38_btn3.setTextColor(Color.RED);
        Question38_btn4.setTextColor(Color.RED);
        Question38_btn1.setEnabled(false);
        Question38_btn2.setEnabled(false);
        Question38_btn3.setEnabled(false);
        Question38_btn4.setEnabled(false);
        switch (answerKeys[37])
        {
            case 1:
                Question38_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question38_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question38_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question38_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question39
    //
    //
    public  void showSolution39()
    {
        Question39_btn1.setTextColor(Color.RED);
        Question39_btn2.setTextColor(Color.RED);
        Question39_btn3.setTextColor(Color.RED);
        Question39_btn4.setTextColor(Color.RED);
        Question39_btn1.setEnabled(false);
        Question39_btn2.setEnabled(false);
        Question39_btn3.setEnabled(false);
        Question39_btn4.setEnabled(false);
        switch (answerKeys[38])
        {
            case 1:
                Question39_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question39_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question39_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question39_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question40
    //
    //
    public  void showSolution40()
    {
        Question40_btn1.setTextColor(Color.RED);
        Question40_btn2.setTextColor(Color.RED);
        Question40_btn3.setTextColor(Color.RED);
        Question40_btn4.setTextColor(Color.RED);
        Question40_btn1.setEnabled(false);
        Question40_btn2.setEnabled(false);
        Question40_btn3.setEnabled(false);
        Question40_btn4.setEnabled(false);
        switch (answerKeys[39])
        {
            case 1:
                Question40_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question40_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question40_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question40_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question41
    //
    //
    public  void showSolution41()
    {
        Question41_btn1.setTextColor(Color.RED);
        Question41_btn2.setTextColor(Color.RED);
        Question41_btn3.setTextColor(Color.RED);
        Question41_btn4.setTextColor(Color.RED);
        Question41_btn1.setEnabled(false);
        Question41_btn2.setEnabled(false);
        Question41_btn3.setEnabled(false);
        Question41_btn4.setEnabled(false);
        switch (answerKeys[40])
        {
            case 1:
                Question41_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question41_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question41_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question41_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question41
    //
    //
    public  void showSolution42()
    {
        Question42_btn1.setTextColor(Color.RED);
        Question42_btn2.setTextColor(Color.RED);
        Question42_btn3.setTextColor(Color.RED);
        Question42_btn4.setTextColor(Color.RED);
        Question42_btn1.setEnabled(false);
        Question42_btn2.setEnabled(false);
        Question42_btn3.setEnabled(false);
        Question42_btn4.setEnabled(false);
        switch (answerKeys[41])
        {
            case 1:
                Question42_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question42_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question42_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question42_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question43
    //
    //
    public  void showSolution43()
    {
        Question43_btn1.setTextColor(Color.RED);
        Question43_btn2.setTextColor(Color.RED);
        Question43_btn3.setTextColor(Color.RED);
        Question43_btn4.setTextColor(Color.RED);
        Question43_btn1.setEnabled(false);
        Question43_btn2.setEnabled(false);
        Question43_btn3.setEnabled(false);
        Question43_btn4.setEnabled(false);
        switch (answerKeys[42])
        {
            case 1:
                Question43_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question43_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question43_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question43_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question44
    //
    //
    public  void showSolution44()
    {
        Question44_btn1.setTextColor(Color.RED);
        Question44_btn2.setTextColor(Color.RED);
        Question44_btn3.setTextColor(Color.RED);
        Question44_btn4.setTextColor(Color.RED);
        Question44_btn1.setEnabled(false);
        Question44_btn2.setEnabled(false);
        Question44_btn3.setEnabled(false);
        Question44_btn4.setEnabled(false);
        switch (answerKeys[43])
        {
            case 1:
                Question44_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question44_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question44_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question44_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question45
    //
    //
    public  void showSolution45()
    {
        Question45_btn1.setTextColor(Color.RED);
        Question45_btn2.setTextColor(Color.RED);
        Question45_btn3.setTextColor(Color.RED);
        Question45_btn4.setTextColor(Color.RED);
        Question45_btn1.setEnabled(false);
        Question45_btn2.setEnabled(false);
        Question45_btn3.setEnabled(false);
        Question45_btn4.setEnabled(false);
        switch (answerKeys[44])
        {
            case 1:
                Question45_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question45_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question45_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question45_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question46
    //
    //
    public  void showSolution46()
    {
        Question46_btn1.setTextColor(Color.RED);
        Question46_btn2.setTextColor(Color.RED);
        Question46_btn3.setTextColor(Color.RED);
        Question46_btn4.setTextColor(Color.RED);
        Question46_btn1.setEnabled(false);
        Question46_btn2.setEnabled(false);
        Question46_btn3.setEnabled(false);
        Question46_btn4.setEnabled(false);
        switch (answerKeys[45])
        {
            case 1:
                Question46_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question46_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question46_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question46_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question47
    //
    //
    public  void showSolution47()
    {
        Question47_btn1.setTextColor(Color.RED);
        Question47_btn2.setTextColor(Color.RED);
        Question47_btn3.setTextColor(Color.RED);
        Question47_btn4.setTextColor(Color.RED);
        Question47_btn1.setEnabled(false);
        Question47_btn2.setEnabled(false);
        Question47_btn3.setEnabled(false);
        Question47_btn4.setEnabled(false);
        switch (answerKeys[46])
        {
            case 1:
                Question47_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question47_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question47_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question47_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question48
    //
    //
    public  void showSolution48()
    {
        Question48_btn1.setTextColor(Color.RED);
        Question48_btn2.setTextColor(Color.RED);
        Question48_btn3.setTextColor(Color.RED);
        Question48_btn4.setTextColor(Color.RED);
        Question48_btn1.setEnabled(false);
        Question48_btn2.setEnabled(false);
        Question48_btn3.setEnabled(false);
        Question48_btn4.setEnabled(false);
        switch (answerKeys[47])
        {
            case 1:
                Question48_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question48_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question48_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question48_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question49
    //
    //
    public  void showSolution49()
    {
        Question49_btn1.setTextColor(Color.RED);
        Question49_btn2.setTextColor(Color.RED);
        Question49_btn3.setTextColor(Color.RED);
        Question49_btn4.setTextColor(Color.RED);
        Question49_btn1.setEnabled(false);
        Question49_btn2.setEnabled(false);
        Question49_btn3.setEnabled(false);
        Question49_btn4.setEnabled(false);
        switch (answerKeys[48])
        {
            case 1:
                Question49_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question49_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question49_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question49_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question50
    //
    //
    public  void showSolution50()
    {
        Question50_btn1.setTextColor(Color.RED);
        Question50_btn2.setTextColor(Color.RED);
        Question50_btn3.setTextColor(Color.RED);
        Question50_btn4.setTextColor(Color.RED);
        Question50_btn1.setEnabled(false);
        Question50_btn2.setEnabled(false);
        Question50_btn3.setEnabled(false);
        Question50_btn4.setEnabled(false);
        switch (answerKeys[49])
        {
            case 1:
                Question50_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question50_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question50_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question50_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question51
    //
    //
    public  void showSolution51()
    {
        Question51_btn1.setTextColor(Color.RED);
        Question51_btn2.setTextColor(Color.RED);
        Question51_btn3.setTextColor(Color.RED);
        Question51_btn4.setTextColor(Color.RED);
        Question51_btn1.setEnabled(false);
        Question51_btn2.setEnabled(false);
        Question51_btn3.setEnabled(false);
        Question51_btn4.setEnabled(false);
        switch (answerKeys[50])
        {
            case 1:
                Question51_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question51_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question51_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question51_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question51
    //
    //
    public  void showSolution52()
    {
        Question52_btn1.setTextColor(Color.RED);
        Question52_btn2.setTextColor(Color.RED);
        Question52_btn3.setTextColor(Color.RED);
        Question52_btn4.setTextColor(Color.RED);
        Question52_btn1.setEnabled(false);
        Question52_btn2.setEnabled(false);
        Question52_btn3.setEnabled(false);
        Question52_btn4.setEnabled(false);
        switch (answerKeys[51])
        {
            case 1:
                Question52_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question52_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question52_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question52_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question53
    //
    //
    public  void showSolution53()
    {
        Question53_btn1.setTextColor(Color.RED);
        Question53_btn2.setTextColor(Color.RED);
        Question53_btn3.setTextColor(Color.RED);
        Question53_btn4.setTextColor(Color.RED);
        Question53_btn1.setEnabled(false);
        Question53_btn2.setEnabled(false);
        Question53_btn3.setEnabled(false);
        Question53_btn4.setEnabled(false);
        switch (answerKeys[52])
        {
            case 1:
                Question53_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question53_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question53_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question53_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question54
    //
    //
    public  void showSolution54()
    {
        Question54_btn1.setTextColor(Color.RED);
        Question54_btn2.setTextColor(Color.RED);
        Question54_btn3.setTextColor(Color.RED);
        Question54_btn4.setTextColor(Color.RED);
        Question54_btn1.setEnabled(false);
        Question54_btn2.setEnabled(false);
        Question54_btn3.setEnabled(false);
        Question54_btn4.setEnabled(false);
        switch (answerKeys[53])
        {
            case 1:
                Question54_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question54_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question54_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question54_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question55
    //
    //
    public  void showSolution55()
    {
        Question55_btn1.setTextColor(Color.RED);
        Question55_btn2.setTextColor(Color.RED);
        Question55_btn3.setTextColor(Color.RED);
        Question55_btn4.setTextColor(Color.RED);
        Question55_btn1.setEnabled(false);
        Question55_btn2.setEnabled(false);
        Question55_btn3.setEnabled(false);
        Question55_btn4.setEnabled(false);
        switch (answerKeys[54])
        {
            case 1:
                Question55_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question55_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question55_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question55_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question56
    //
    //
    public  void showSolution56()
    {
        Question56_btn1.setTextColor(Color.RED);
        Question56_btn2.setTextColor(Color.RED);
        Question56_btn3.setTextColor(Color.RED);
        Question56_btn4.setTextColor(Color.RED);
        Question56_btn1.setEnabled(false);
        Question56_btn2.setEnabled(false);
        Question56_btn3.setEnabled(false);
        Question56_btn4.setEnabled(false);
        switch (answerKeys[55])
        {
            case 1:
                Question56_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question56_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question56_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question56_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question57
    //
    //
    public  void showSolution57()
    {
        Question57_btn1.setTextColor(Color.RED);
        Question57_btn2.setTextColor(Color.RED);
        Question57_btn3.setTextColor(Color.RED);
        Question57_btn4.setTextColor(Color.RED);
        Question57_btn1.setEnabled(false);
        Question57_btn2.setEnabled(false);
        Question57_btn3.setEnabled(false);
        Question57_btn4.setEnabled(false);
        switch (answerKeys[56])
        {
            case 1:
                Question57_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question57_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question57_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question57_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question58
    //
    //
    public  void showSolution58()
    {
        Question58_btn1.setTextColor(Color.RED);
        Question58_btn2.setTextColor(Color.RED);
        Question58_btn3.setTextColor(Color.RED);
        Question58_btn4.setTextColor(Color.RED);
        Question58_btn1.setEnabled(false);
        Question58_btn2.setEnabled(false);
        Question58_btn3.setEnabled(false);
        Question58_btn4.setEnabled(false);
        switch (answerKeys[57])
        {
            case 1:
                Question58_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question58_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question58_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question58_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question59
    //
    //
    public  void showSolution59()
    {
        Question59_btn1.setTextColor(Color.RED);
        Question59_btn2.setTextColor(Color.RED);
        Question59_btn3.setTextColor(Color.RED);
        Question59_btn4.setTextColor(Color.RED);
        Question59_btn1.setEnabled(false);
        Question59_btn2.setEnabled(false);
        Question59_btn3.setEnabled(false);
        Question59_btn4.setEnabled(false);
        switch (answerKeys[58])
        {
            case 1:
                Question59_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question59_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question59_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question59_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question60
    //
    //
    public  void showSolution60()
    {
        Question60_btn1.setTextColor(Color.RED);
        Question60_btn2.setTextColor(Color.RED);
        Question60_btn3.setTextColor(Color.RED);
        Question60_btn4.setTextColor(Color.RED);
        Question60_btn1.setEnabled(false);
        Question60_btn2.setEnabled(false);
        Question60_btn3.setEnabled(false);
        Question60_btn4.setEnabled(false);
        switch (answerKeys[59])
        {
            case 1:
                Question60_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question60_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question60_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question60_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question61
    //
    //
    public  void showSolution61()
    {
        Question61_btn1.setTextColor(Color.RED);
        Question61_btn2.setTextColor(Color.RED);
        Question61_btn3.setTextColor(Color.RED);
        Question61_btn4.setTextColor(Color.RED);
        Question61_btn1.setEnabled(false);
        Question61_btn2.setEnabled(false);
        Question61_btn3.setEnabled(false);
        Question61_btn4.setEnabled(false);
        switch (answerKeys[60])
        {
            case 1:
                Question61_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question61_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question61_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question61_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question61
    //
    //
    public  void showSolution62()
    {
        Question62_btn1.setTextColor(Color.RED);
        Question62_btn2.setTextColor(Color.RED);
        Question62_btn3.setTextColor(Color.RED);
        Question62_btn4.setTextColor(Color.RED);
        Question62_btn1.setEnabled(false);
        Question62_btn2.setEnabled(false);
        Question62_btn3.setEnabled(false);
        Question62_btn4.setEnabled(false);
        switch (answerKeys[61])
        {
            case 1:
                Question62_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question62_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question62_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question62_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question63
    //
    //
    public  void showSolution63()
    {
        Question63_btn1.setTextColor(Color.RED);
        Question63_btn2.setTextColor(Color.RED);
        Question63_btn3.setTextColor(Color.RED);
        Question63_btn4.setTextColor(Color.RED);
        Question63_btn1.setEnabled(false);
        Question63_btn2.setEnabled(false);
        Question63_btn3.setEnabled(false);
        Question63_btn4.setEnabled(false);
        switch (answerKeys[62])
        {
            case 1:
                Question63_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question63_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question63_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question63_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question64
    //
    //
    public  void showSolution64()
    {
        Question64_btn1.setTextColor(Color.RED);
        Question64_btn2.setTextColor(Color.RED);
        Question64_btn3.setTextColor(Color.RED);
        Question64_btn4.setTextColor(Color.RED);
        Question64_btn1.setEnabled(false);
        Question64_btn2.setEnabled(false);
        Question64_btn3.setEnabled(false);
        Question64_btn4.setEnabled(false);
        switch (answerKeys[63])
        {
            case 1:
                Question64_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question64_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question64_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question64_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question65
    //
    //
    public  void showSolution65()
    {
        Question65_btn1.setTextColor(Color.RED);
        Question65_btn2.setTextColor(Color.RED);
        Question65_btn3.setTextColor(Color.RED);
        Question65_btn4.setTextColor(Color.RED);
        Question65_btn1.setEnabled(false);
        Question65_btn2.setEnabled(false);
        Question65_btn3.setEnabled(false);
        Question65_btn4.setEnabled(false);
        switch (answerKeys[64])
        {
            case 1:
                Question65_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question65_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question65_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question65_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question66
    //
    //
    public  void showSolution66()
    {
        Question66_btn1.setTextColor(Color.RED);
        Question66_btn2.setTextColor(Color.RED);
        Question66_btn3.setTextColor(Color.RED);
        Question66_btn4.setTextColor(Color.RED);
        Question66_btn1.setEnabled(false);
        Question66_btn2.setEnabled(false);
        Question66_btn3.setEnabled(false);
        Question66_btn4.setEnabled(false);
        switch (answerKeys[65])
        {
            case 1:
                Question66_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question66_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question66_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question66_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question67
    //
    //
    public  void showSolution67()
    {
        Question67_btn1.setTextColor(Color.RED);
        Question67_btn2.setTextColor(Color.RED);
        Question67_btn3.setTextColor(Color.RED);
        Question67_btn4.setTextColor(Color.RED);
        Question67_btn1.setEnabled(false);
        Question67_btn2.setEnabled(false);
        Question67_btn3.setEnabled(false);
        Question67_btn4.setEnabled(false);
        switch (answerKeys[66])
        {
            case 1:
                Question67_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question67_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question67_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question67_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question68
    //
    //
    public  void showSolution68()
    {
        Question68_btn1.setTextColor(Color.RED);
        Question68_btn2.setTextColor(Color.RED);
        Question68_btn3.setTextColor(Color.RED);
        Question68_btn4.setTextColor(Color.RED);
        Question68_btn1.setEnabled(false);
        Question68_btn2.setEnabled(false);
        Question68_btn3.setEnabled(false);
        Question68_btn4.setEnabled(false);
        switch (answerKeys[67])
        {
            case 1:
                Question68_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question68_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question68_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question68_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question69
    //
    //
    public  void showSolution69()
    {
        Question69_btn1.setTextColor(Color.RED);
        Question69_btn2.setTextColor(Color.RED);
        Question69_btn3.setTextColor(Color.RED);
        Question69_btn4.setTextColor(Color.RED);
        Question69_btn1.setEnabled(false);
        Question69_btn2.setEnabled(false);
        Question69_btn3.setEnabled(false);
        Question69_btn4.setEnabled(false);
        switch (answerKeys[68])
        {
            case 1:
                Question69_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question69_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question69_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question69_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question70
    //
    //
    public  void showSolution70()
    {
        Question70_btn1.setTextColor(Color.RED);
        Question70_btn2.setTextColor(Color.RED);
        Question70_btn3.setTextColor(Color.RED);
        Question70_btn4.setTextColor(Color.RED);
        Question70_btn1.setEnabled(false);
        Question70_btn2.setEnabled(false);
        Question70_btn3.setEnabled(false);
        Question70_btn4.setEnabled(false);
        switch (answerKeys[69])
        {
            case 1:
                Question70_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question70_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question70_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question70_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question71
    //
    //
    public  void showSolution71()
    {
        Question71_btn1.setTextColor(Color.RED);
        Question71_btn2.setTextColor(Color.RED);
        Question71_btn3.setTextColor(Color.RED);
        Question71_btn4.setTextColor(Color.RED);
        Question71_btn1.setEnabled(false);
        Question71_btn2.setEnabled(false);
        Question71_btn3.setEnabled(false);
        Question71_btn4.setEnabled(false);
        switch (answerKeys[70])
        {
            case 1:
                Question71_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question71_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question71_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question71_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question71
    //
    //
    public  void showSolution72()
    {
        Question72_btn1.setTextColor(Color.RED);
        Question72_btn2.setTextColor(Color.RED);
        Question72_btn3.setTextColor(Color.RED);
        Question72_btn4.setTextColor(Color.RED);
        Question72_btn1.setEnabled(false);
        Question72_btn2.setEnabled(false);
        Question72_btn3.setEnabled(false);
        Question72_btn4.setEnabled(false);
        switch (answerKeys[71])
        {
            case 1:
                Question72_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question72_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question72_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question72_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question73
    //
    //
    public  void showSolution73()
    {
        Question73_btn1.setTextColor(Color.RED);
        Question73_btn2.setTextColor(Color.RED);
        Question73_btn3.setTextColor(Color.RED);
        Question73_btn4.setTextColor(Color.RED);
        Question73_btn1.setEnabled(false);
        Question73_btn2.setEnabled(false);
        Question73_btn3.setEnabled(false);
        Question73_btn4.setEnabled(false);
        switch (answerKeys[72])
        {
            case 1:
                Question73_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question73_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question73_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question73_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question74
    //
    //
    public  void showSolution74()
    {
        Question74_btn1.setTextColor(Color.RED);
        Question74_btn2.setTextColor(Color.RED);
        Question74_btn3.setTextColor(Color.RED);
        Question74_btn4.setTextColor(Color.RED);
        Question74_btn1.setEnabled(false);
        Question74_btn2.setEnabled(false);
        Question74_btn3.setEnabled(false);
        Question74_btn4.setEnabled(false);
        switch (answerKeys[73])
        {
            case 1:
                Question74_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question74_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question74_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question74_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question75
    //
    //
    public  void showSolution75()
    {
        Question75_btn1.setTextColor(Color.RED);
        Question75_btn2.setTextColor(Color.RED);
        Question75_btn3.setTextColor(Color.RED);
        Question75_btn4.setTextColor(Color.RED);
        Question75_btn1.setEnabled(false);
        Question75_btn2.setEnabled(false);
        Question75_btn3.setEnabled(false);
        Question75_btn4.setEnabled(false);
        switch (answerKeys[74])
        {
            case 1:
                Question75_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question75_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question75_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question75_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question76
    //
    //
    public  void showSolution76()
    {
        Question76_btn1.setTextColor(Color.RED);
        Question76_btn2.setTextColor(Color.RED);
        Question76_btn3.setTextColor(Color.RED);
        Question76_btn4.setTextColor(Color.RED);
        Question76_btn1.setEnabled(false);
        Question76_btn2.setEnabled(false);
        Question76_btn3.setEnabled(false);
        Question76_btn4.setEnabled(false);
        switch (answerKeys[75])
        {
            case 1:
                Question76_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question76_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question76_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question76_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question77
    //
    //
    public  void showSolution77()
    {
        Question77_btn1.setTextColor(Color.RED);
        Question77_btn2.setTextColor(Color.RED);
        Question77_btn3.setTextColor(Color.RED);
        Question77_btn4.setTextColor(Color.RED);
        Question77_btn1.setEnabled(false);
        Question77_btn2.setEnabled(false);
        Question77_btn3.setEnabled(false);
        Question77_btn4.setEnabled(false);
        switch (answerKeys[76])
        {
            case 1:
                Question77_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question77_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question77_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question77_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question78
    //
    //
    public  void showSolution78()
    {
        Question78_btn1.setTextColor(Color.RED);
        Question78_btn2.setTextColor(Color.RED);
        Question78_btn3.setTextColor(Color.RED);
        Question78_btn4.setTextColor(Color.RED);
        Question78_btn1.setEnabled(false);
        Question78_btn2.setEnabled(false);
        Question78_btn3.setEnabled(false);
        Question78_btn4.setEnabled(false);
        switch (answerKeys[77])
        {
            case 1:
                Question78_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question78_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question78_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question78_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question79
    //
    //
    public  void showSolution79()
    {
        Question79_btn1.setTextColor(Color.RED);
        Question79_btn2.setTextColor(Color.RED);
        Question79_btn3.setTextColor(Color.RED);
        Question79_btn4.setTextColor(Color.RED);
        Question79_btn1.setEnabled(false);
        Question79_btn2.setEnabled(false);
        Question79_btn3.setEnabled(false);
        Question79_btn4.setEnabled(false);
        switch (answerKeys[78])
        {
            case 1:
                Question79_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question79_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question79_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question79_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question80
    //
    //
    public  void showSolution80()
    {
        Question80_btn1.setTextColor(Color.RED);
        Question80_btn2.setTextColor(Color.RED);
        Question80_btn3.setTextColor(Color.RED);
        Question80_btn4.setTextColor(Color.RED);
        Question80_btn1.setEnabled(false);
        Question80_btn2.setEnabled(false);
        Question80_btn3.setEnabled(false);
        Question80_btn4.setEnabled(false);
        switch (answerKeys[79])
        {
            case 1:
                Question80_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question80_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question80_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question80_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question81
    //
    //
    public  void showSolution81()
    {
        Question81_btn1.setTextColor(Color.RED);
        Question81_btn2.setTextColor(Color.RED);
        Question81_btn3.setTextColor(Color.RED);
        Question81_btn4.setTextColor(Color.RED);
        Question81_btn1.setEnabled(false);
        Question81_btn2.setEnabled(false);
        Question81_btn3.setEnabled(false);
        Question81_btn4.setEnabled(false);
        switch (answerKeys[80])
        {
            case 1:
                Question81_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question81_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question81_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question81_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question81
    //
    //
    public  void showSolution82()
    {
        Question82_btn1.setTextColor(Color.RED);
        Question82_btn2.setTextColor(Color.RED);
        Question82_btn3.setTextColor(Color.RED);
        Question82_btn4.setTextColor(Color.RED);
        Question82_btn1.setEnabled(false);
        Question82_btn2.setEnabled(false);
        Question82_btn3.setEnabled(false);
        Question82_btn4.setEnabled(false);
        switch (answerKeys[81])
        {
            case 1:
                Question82_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question82_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question82_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question82_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question83
    //
    //
    public  void showSolution83()
    {
        Question83_btn1.setTextColor(Color.RED);
        Question83_btn2.setTextColor(Color.RED);
        Question83_btn3.setTextColor(Color.RED);
        Question83_btn4.setTextColor(Color.RED);
        Question83_btn1.setEnabled(false);
        Question83_btn2.setEnabled(false);
        Question83_btn3.setEnabled(false);
        Question83_btn4.setEnabled(false);
        switch (answerKeys[82])
        {
            case 1:
                Question83_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question83_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question83_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question83_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question84
    //
    //
    public  void showSolution84()
    {
        Question84_btn1.setTextColor(Color.RED);
        Question84_btn2.setTextColor(Color.RED);
        Question84_btn3.setTextColor(Color.RED);
        Question84_btn4.setTextColor(Color.RED);
        Question84_btn1.setEnabled(false);
        Question84_btn2.setEnabled(false);
        Question84_btn3.setEnabled(false);
        Question84_btn4.setEnabled(false);
        switch (answerKeys[83])
        {
            case 1:
                Question84_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question84_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question84_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question84_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question85
    //
    //
    public  void showSolution85()
    {
        Question85_btn1.setTextColor(Color.RED);
        Question85_btn2.setTextColor(Color.RED);
        Question85_btn3.setTextColor(Color.RED);
        Question85_btn4.setTextColor(Color.RED);
        Question85_btn1.setEnabled(false);
        Question85_btn2.setEnabled(false);
        Question85_btn3.setEnabled(false);
        Question85_btn4.setEnabled(false);
        switch (answerKeys[84])
        {
            case 1:
                Question85_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question85_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question85_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question85_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question86
    //
    //
    public  void showSolution86()
    {
        Question86_btn1.setTextColor(Color.RED);
        Question86_btn2.setTextColor(Color.RED);
        Question86_btn3.setTextColor(Color.RED);
        Question86_btn4.setTextColor(Color.RED);
        Question86_btn1.setEnabled(false);
        Question86_btn2.setEnabled(false);
        Question86_btn3.setEnabled(false);
        Question86_btn4.setEnabled(false);
        switch (answerKeys[85])
        {
            case 1:
                Question86_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question86_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question86_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question86_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question87
    //
    //
    public  void showSolution87()
    {
        Question87_btn1.setTextColor(Color.RED);
        Question87_btn2.setTextColor(Color.RED);
        Question87_btn3.setTextColor(Color.RED);
        Question87_btn4.setTextColor(Color.RED);
        Question87_btn1.setEnabled(false);
        Question87_btn2.setEnabled(false);
        Question87_btn3.setEnabled(false);
        Question87_btn4.setEnabled(false);
        switch (answerKeys[86])
        {
            case 1:
                Question87_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question87_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question87_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question87_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question88
    //
    //
    public  void showSolution88()
    {
        Question88_btn1.setTextColor(Color.RED);
        Question88_btn2.setTextColor(Color.RED);
        Question88_btn3.setTextColor(Color.RED);
        Question88_btn4.setTextColor(Color.RED);
        Question88_btn1.setEnabled(false);
        Question88_btn2.setEnabled(false);
        Question88_btn3.setEnabled(false);
        Question88_btn4.setEnabled(false);
        switch (answerKeys[87])
        {
            case 1:
                Question88_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question88_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question88_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question88_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question89
    //
    //
    public  void showSolution89()
    {
        Question89_btn1.setTextColor(Color.RED);
        Question89_btn2.setTextColor(Color.RED);
        Question89_btn3.setTextColor(Color.RED);
        Question89_btn4.setTextColor(Color.RED);
        Question89_btn1.setEnabled(false);
        Question89_btn2.setEnabled(false);
        Question89_btn3.setEnabled(false);
        Question89_btn4.setEnabled(false);
        switch (answerKeys[88])
        {
            case 1:
                Question89_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question89_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question89_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question89_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question90
    //
    //
    public  void showSolution90()
    {
        Question90_btn1.setTextColor(Color.RED);
        Question90_btn2.setTextColor(Color.RED);
        Question90_btn3.setTextColor(Color.RED);
        Question90_btn4.setTextColor(Color.RED);
        Question90_btn1.setEnabled(false);
        Question90_btn2.setEnabled(false);
        Question90_btn3.setEnabled(false);
        Question90_btn4.setEnabled(false);
        switch (answerKeys[89])
        {
            case 1:
                Question90_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question90_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question90_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question90_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question91
    //
    //
    public  void showSolution91()
    {
        Question91_btn1.setTextColor(Color.RED);
        Question91_btn2.setTextColor(Color.RED);
        Question91_btn3.setTextColor(Color.RED);
        Question91_btn4.setTextColor(Color.RED);
        Question91_btn1.setEnabled(false);
        Question91_btn2.setEnabled(false);
        Question91_btn3.setEnabled(false);
        Question91_btn4.setEnabled(false);
        switch (answerKeys[90])
        {
            case 1:
                Question91_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question91_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question91_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question91_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question91
    //
    //
    public  void showSolution92()
    {
        Question92_btn1.setTextColor(Color.RED);
        Question92_btn2.setTextColor(Color.RED);
        Question92_btn3.setTextColor(Color.RED);
        Question92_btn4.setTextColor(Color.RED);
        Question92_btn1.setEnabled(false);
        Question92_btn2.setEnabled(false);
        Question92_btn3.setEnabled(false);
        Question92_btn4.setEnabled(false);
        switch (answerKeys[91])
        {
            case 1:
                Question92_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question92_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question92_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question92_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question93
    //
    //
    public  void showSolution93()
    {
        Question93_btn1.setTextColor(Color.RED);
        Question93_btn2.setTextColor(Color.RED);
        Question93_btn3.setTextColor(Color.RED);
        Question93_btn4.setTextColor(Color.RED);
        Question93_btn1.setEnabled(false);
        Question93_btn2.setEnabled(false);
        Question93_btn3.setEnabled(false);
        Question93_btn4.setEnabled(false);
        switch (answerKeys[92])
        {
            case 1:
                Question93_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question93_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question93_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question93_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question94
    //
    //
    public  void showSolution94()
    {
        Question94_btn1.setTextColor(Color.RED);
        Question94_btn2.setTextColor(Color.RED);
        Question94_btn3.setTextColor(Color.RED);
        Question94_btn4.setTextColor(Color.RED);
        Question94_btn1.setEnabled(false);
        Question94_btn2.setEnabled(false);
        Question94_btn3.setEnabled(false);
        Question94_btn4.setEnabled(false);
        switch (answerKeys[93])
        {
            case 1:
                Question94_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question94_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question94_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question94_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question95
    //
    //
    public  void showSolution95()
    {
        Question95_btn1.setTextColor(Color.RED);
        Question95_btn2.setTextColor(Color.RED);
        Question95_btn3.setTextColor(Color.RED);
        Question95_btn4.setTextColor(Color.RED);
        Question95_btn1.setEnabled(false);
        Question95_btn2.setEnabled(false);
        Question95_btn3.setEnabled(false);
        Question95_btn4.setEnabled(false);
        switch (answerKeys[94])
        {
            case 1:
                Question95_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question95_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question95_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question95_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question96
    //
    //
    public  void showSolution96()
    {
        Question96_btn1.setTextColor(Color.RED);
        Question96_btn2.setTextColor(Color.RED);
        Question96_btn3.setTextColor(Color.RED);
        Question96_btn4.setTextColor(Color.RED);
        Question96_btn1.setEnabled(false);
        Question96_btn2.setEnabled(false);
        Question96_btn3.setEnabled(false);
        Question96_btn4.setEnabled(false);
        switch (answerKeys[95])
        {
            case 1:
                Question96_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question96_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question96_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question96_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question97
    //
    //
    public  void showSolution97()
    {
        Question97_btn1.setTextColor(Color.RED);
        Question97_btn2.setTextColor(Color.RED);
        Question97_btn3.setTextColor(Color.RED);
        Question97_btn4.setTextColor(Color.RED);
        Question97_btn1.setEnabled(false);
        Question97_btn2.setEnabled(false);
        Question97_btn3.setEnabled(false);
        Question97_btn4.setEnabled(false);
        switch (answerKeys[96])
        {
            case 1:
                Question97_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question97_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question97_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question97_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question98
    //
    //
    public  void showSolution98()
    {
        Question98_btn1.setTextColor(Color.RED);
        Question98_btn2.setTextColor(Color.RED);
        Question98_btn3.setTextColor(Color.RED);
        Question98_btn4.setTextColor(Color.RED);
        Question98_btn1.setEnabled(false);
        Question98_btn2.setEnabled(false);
        Question98_btn3.setEnabled(false);
        Question98_btn4.setEnabled(false);
        switch (answerKeys[97])
        {
            case 1:
                Question98_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question98_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question98_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question98_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question99
    //
    //
    public  void showSolution99()
    {
        Question99_btn1.setTextColor(Color.RED);
        Question99_btn2.setTextColor(Color.RED);
        Question99_btn3.setTextColor(Color.RED);
        Question99_btn4.setTextColor(Color.RED);
        Question99_btn1.setEnabled(false);
        Question99_btn2.setEnabled(false);
        Question99_btn3.setEnabled(false);
        Question99_btn4.setEnabled(false);
        switch (answerKeys[98])
        {
            case 1:
                Question99_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question99_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question99_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question99_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question100
    //
    //
    public  void showSolution100()
    {
        Question100_btn1.setTextColor(Color.RED);
        Question100_btn2.setTextColor(Color.RED);
        Question100_btn3.setTextColor(Color.RED);
        Question100_btn4.setTextColor(Color.RED);
        Question100_btn1.setEnabled(false);
        Question100_btn2.setEnabled(false);
        Question100_btn3.setEnabled(false);
        Question100_btn4.setEnabled(false);
        switch (answerKeys[99])
        {
            case 1:
                Question100_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question100_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question100_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question100_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question101
    //
    //
    public  void showSolution101()
    {
        Question101_btn1.setTextColor(Color.RED);
        Question101_btn2.setTextColor(Color.RED);
        Question101_btn3.setTextColor(Color.RED);
        Question101_btn4.setTextColor(Color.RED);
        Question101_btn1.setEnabled(false);
        Question101_btn2.setEnabled(false);
        Question101_btn3.setEnabled(false);
        Question101_btn4.setEnabled(false);
        switch (answerKeys[100])
        {
            case 1:
                Question101_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question101_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question101_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question101_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question101
    //
    //
    public  void showSolution102()
    {
        Question102_btn1.setTextColor(Color.RED);
        Question102_btn2.setTextColor(Color.RED);
        Question102_btn3.setTextColor(Color.RED);
        Question102_btn4.setTextColor(Color.RED);
        Question102_btn1.setEnabled(false);
        Question102_btn2.setEnabled(false);
        Question102_btn3.setEnabled(false);
        Question102_btn4.setEnabled(false);
        switch (answerKeys[101])
        {
            case 1:
                Question102_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question102_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question102_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question102_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question103
    //
    //
    public  void showSolution103()
    {
        Question103_btn1.setTextColor(Color.RED);
        Question103_btn2.setTextColor(Color.RED);
        Question103_btn3.setTextColor(Color.RED);
        Question103_btn4.setTextColor(Color.RED);
        Question103_btn1.setEnabled(false);
        Question103_btn2.setEnabled(false);
        Question103_btn3.setEnabled(false);
        Question103_btn4.setEnabled(false);
        switch (answerKeys[102])
        {
            case 1:
                Question103_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question103_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question103_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question103_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question104
    //
    //
    public  void showSolution104()
    {
        Question104_btn1.setTextColor(Color.RED);
        Question104_btn2.setTextColor(Color.RED);
        Question104_btn3.setTextColor(Color.RED);
        Question104_btn4.setTextColor(Color.RED);
        Question104_btn1.setEnabled(false);
        Question104_btn2.setEnabled(false);
        Question104_btn3.setEnabled(false);
        Question104_btn4.setEnabled(false);
        switch (answerKeys[103])
        {
            case 1:
                Question104_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question104_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question104_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question104_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question105
    //
    //
    public  void showSolution105()
    {
        Question105_btn1.setTextColor(Color.RED);
        Question105_btn2.setTextColor(Color.RED);
        Question105_btn3.setTextColor(Color.RED);
        Question105_btn4.setTextColor(Color.RED);
        Question105_btn1.setEnabled(false);
        Question105_btn2.setEnabled(false);
        Question105_btn3.setEnabled(false);
        Question105_btn4.setEnabled(false);
        switch (answerKeys[104])
        {
            case 1:
                Question105_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question105_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question105_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question105_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question106
    //
    //
    public  void showSolution106()
    {
        Question106_btn1.setTextColor(Color.RED);
        Question106_btn2.setTextColor(Color.RED);
        Question106_btn3.setTextColor(Color.RED);
        Question106_btn4.setTextColor(Color.RED);
        Question106_btn1.setEnabled(false);
        Question106_btn2.setEnabled(false);
        Question106_btn3.setEnabled(false);
        Question106_btn4.setEnabled(false);
        switch (answerKeys[105])
        {
            case 1:
                Question106_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question106_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question106_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question106_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question107
    //
    //
    public  void showSolution107()
    {
        Question107_btn1.setTextColor(Color.RED);
        Question107_btn2.setTextColor(Color.RED);
        Question107_btn3.setTextColor(Color.RED);
        Question107_btn4.setTextColor(Color.RED);
        Question107_btn1.setEnabled(false);
        Question107_btn2.setEnabled(false);
        Question107_btn3.setEnabled(false);
        Question107_btn4.setEnabled(false);
        switch (answerKeys[106])
        {
            case 1:
                Question107_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question107_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question107_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question107_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question108
    //
    //
    public  void showSolution108()
    {
        Question108_btn1.setTextColor(Color.RED);
        Question108_btn2.setTextColor(Color.RED);
        Question108_btn3.setTextColor(Color.RED);
        Question108_btn4.setTextColor(Color.RED);
        Question108_btn1.setEnabled(false);
        Question108_btn2.setEnabled(false);
        Question108_btn3.setEnabled(false);
        Question108_btn4.setEnabled(false);
        switch (answerKeys[107])
        {
            case 1:
                Question108_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question108_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question108_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question108_btn4.setTextColor(Color.GREEN);
                break;
        }
    }
    //
    //
    //answer key of Question109
    //
    //
    public  void showSolution109()
    {
        Question109_btn1.setTextColor(Color.RED);
        Question109_btn2.setTextColor(Color.RED);
        Question109_btn3.setTextColor(Color.RED);
        Question109_btn4.setTextColor(Color.RED);
        Question109_btn1.setEnabled(false);
        Question109_btn2.setEnabled(false);
        Question109_btn3.setEnabled(false);
        Question109_btn4.setEnabled(false);
        switch (answerKeys[108])
        {
            case 1:
                Question109_btn1.setTextColor(Color.GREEN);
                break;
            case 2:
                Question109_btn2.setTextColor(Color.GREEN);
                break;
            case 3:
                Question109_btn3.setTextColor(Color.GREEN);
                break;
            case 4:
                Question109_btn4.setTextColor(Color.GREEN);
                break;
        }
    }



    //
    //
    //OverAll Result
    //
    //
    private void showResult1()
    {
        answer = true;
    }
    private void showResult2()
    {
        answer = true;
    }
    private void showResult3()
    {
        answer = true;
    }

    private void showResult()
    {
        answer = true;

        RadioButton Q1rb = findViewById(Question1_Rgroup.getCheckedRadioButtonId());
        int answerNr = Question1_Rgroup.indexOfChild(Q1rb)+1;
        if (answerNr == answerKeys[0])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
       //
        RadioButton Q2rb = findViewById(Question2_Rgroup.getCheckedRadioButtonId());
        int answerNr1 = Question2_Rgroup.indexOfChild(Q2rb)+1;
        if (answerNr1 == answerKeys[1])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q3rb = findViewById(Question3_Rgroup.getCheckedRadioButtonId());
        int answerNr2 = Question3_Rgroup.indexOfChild(Q3rb)+1;
        if (answerNr2 == answerKeys[2])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q4rb = findViewById(Question4_Rgroup.getCheckedRadioButtonId());
        int answerNr3 = Question4_Rgroup.indexOfChild(Q4rb)+1;
        if (answerNr3 == answerKeys[3])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        RadioButton Q5rb = findViewById(Question5_Rgroup.getCheckedRadioButtonId());
        int answerNr4 = Question5_Rgroup.indexOfChild(Q5rb)+1;
        if (answerNr4 == answerKeys[4])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q6rb = findViewById(Question6_Rgroup.getCheckedRadioButtonId());
        int answerNr5 = Question6_Rgroup.indexOfChild(Q6rb)+1;
        if (answerNr5 == answerKeys[5])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q7rb = findViewById(Question7_Rgroup.getCheckedRadioButtonId());
        int answerNr6 = Question7_Rgroup.indexOfChild(Q7rb)+1;
        if (answerNr6 == answerKeys[6])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q8rb = findViewById(Question8_Rgroup.getCheckedRadioButtonId());
        int answerNr7 = Question8_Rgroup.indexOfChild(Q8rb)+1;
        if (answerNr7 == answerKeys[7])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q9rb = findViewById(Question9_Rgroup.getCheckedRadioButtonId());
        int answerNr8 = Question9_Rgroup.indexOfChild(Q9rb)+1;
        if (answerNr8 == answerKeys[8])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q10rb = findViewById(Question10_Rgroup.getCheckedRadioButtonId());
        int answerNr9 = Question10_Rgroup.indexOfChild(Q10rb)+1;
        if (answerNr9 == answerKeys[9])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q11rb = findViewById(Question11_Rgroup.getCheckedRadioButtonId());
        int answerNr10 = Question11_Rgroup.indexOfChild(Q11rb)+1;
        if (answerNr10 == answerKeys[10])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q12rb = findViewById(Question12_Rgroup.getCheckedRadioButtonId());
        int answerNr11 = Question12_Rgroup.indexOfChild(Q12rb)+1;
        if (answerNr11 == answerKeys[11])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q13rb = findViewById(Question13_Rgroup.getCheckedRadioButtonId());
        int answerNr12 = Question13_Rgroup.indexOfChild(Q13rb)+1;
        if (answerNr12 ==answerKeys[12])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q14rb = findViewById(Question14_Rgroup.getCheckedRadioButtonId());
        int answerNr13 = Question14_Rgroup.indexOfChild(Q14rb)+1;
        if (answerNr13 == answerKeys[13])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        RadioButton Q15rb = findViewById(Question15_Rgroup.getCheckedRadioButtonId());
        int answerNr14 = Question15_Rgroup.indexOfChild(Q15rb)+1;
        if (answerNr14 == answerKeys[14])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q16rb = findViewById(Question16_Rgroup.getCheckedRadioButtonId());
        int answerNr15 = Question16_Rgroup.indexOfChild(Q16rb)+1;
        if (answerNr15 == answerKeys[15])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q17rb = findViewById(Question17_Rgroup.getCheckedRadioButtonId());
        int answerNr16 = Question17_Rgroup.indexOfChild(Q17rb)+1;
        if (answerNr16 == answerKeys[16])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q18rb = findViewById(Question18_Rgroup.getCheckedRadioButtonId());
        int answerNr17 = Question18_Rgroup.indexOfChild(Q18rb)+1;
        if (answerNr17 == answerKeys[17])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q19rb = findViewById(Question19_Rgroup.getCheckedRadioButtonId());
        int answerNr18 = Question19_Rgroup.indexOfChild(Q19rb)+1;
        if (answerNr18 == answerKeys[18])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q20rb = findViewById(Question20_Rgroup.getCheckedRadioButtonId());
        int answerNr19 = Question20_Rgroup.indexOfChild(Q20rb)+1;
        if (answerNr19 == answerKeys[19])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q21rb = findViewById(Question21_Rgroup.getCheckedRadioButtonId());
        int answerNr20 = Question21_Rgroup.indexOfChild(Q21rb)+1;
        if (answerNr20 ==answerKeys[20])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q22rb = findViewById(Question22_Rgroup.getCheckedRadioButtonId());
        int answerNr21 = Question22_Rgroup.indexOfChild(Q22rb)+1;
        if (answerNr21 == answerKeys[21])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q23rb = findViewById(Question23_Rgroup.getCheckedRadioButtonId());
        int answerNr22 = Question23_Rgroup.indexOfChild(Q23rb)+1;
        if (answerNr22 == answerKeys[22])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q24rb = findViewById(Question24_Rgroup.getCheckedRadioButtonId());
        int answerNr23 = Question24_Rgroup.indexOfChild(Q24rb)+1;
        if (answerNr23 == answerKeys[23])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        RadioButton Q25rb = findViewById(Question25_Rgroup.getCheckedRadioButtonId());
        int answerNr24 = Question25_Rgroup.indexOfChild(Q25rb)+1;
        if (answerNr24 ==answerKeys[24])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q26rb = findViewById(Question26_Rgroup.getCheckedRadioButtonId());
        int answerNr25 = Question26_Rgroup.indexOfChild(Q26rb)+1;
        if (answerNr25 == answerKeys[25])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q27rb = findViewById(Question27_Rgroup.getCheckedRadioButtonId());
        int answerNr26 = Question27_Rgroup.indexOfChild(Q27rb)+1;
        if (answerNr26 == answerKeys[26])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q28rb = findViewById(Question28_Rgroup.getCheckedRadioButtonId());
        int answerNr27 = Question28_Rgroup.indexOfChild(Q28rb)+1;
        if (answerNr27 == answerKeys[27])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q29rb = findViewById(Question29_Rgroup.getCheckedRadioButtonId());
        int answerNr28 = Question29_Rgroup.indexOfChild(Q29rb)+1;
        if (answerNr28 == answerKeys[28])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q30rb = findViewById(Question30_Rgroup.getCheckedRadioButtonId());
        int answerNr29 = Question30_Rgroup.indexOfChild(Q30rb)+1;
        if (answerNr29 == answerKeys[29])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q31rb = findViewById(Question31_Rgroup.getCheckedRadioButtonId());
        int answerNr30 = Question31_Rgroup.indexOfChild(Q31rb)+1;
        if (answerNr30 ==answerKeys[30])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q32rb = findViewById(Question32_Rgroup.getCheckedRadioButtonId());
        int answerNr31 = Question33_Rgroup.indexOfChild(Q32rb)+1;
        if (answerNr31 == answerKeys[31])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q33rb = findViewById(Question33_Rgroup.getCheckedRadioButtonId());
        int answerNr32 = Question33_Rgroup.indexOfChild(Q33rb)+1;
        if (answerNr32 == answerKeys[32])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q34rb = findViewById(Question34_Rgroup.getCheckedRadioButtonId());
        int answerNr33 = Question34_Rgroup.indexOfChild(Q34rb)+1;
        if (answerNr33 == answerKeys[33])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        RadioButton Q35rb = findViewById(Question35_Rgroup.getCheckedRadioButtonId());
        int answerNr34 = Question35_Rgroup.indexOfChild(Q35rb)+1;
        if (answerNr34 ==answerKeys[34])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q36rb = findViewById(Question36_Rgroup.getCheckedRadioButtonId());
        int answerNr35 = Question36_Rgroup.indexOfChild(Q36rb)+1;
        if (answerNr35 == answerKeys[35])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q37rb = findViewById(Question37_Rgroup.getCheckedRadioButtonId());
        int answerNr36 = Question37_Rgroup.indexOfChild(Q37rb)+1;
        if (answerNr36 == answerKeys[36])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q38rb = findViewById(Question38_Rgroup.getCheckedRadioButtonId());
        int answerNr37 = Question38_Rgroup.indexOfChild(Q38rb)+1;
        if (answerNr37 == answerKeys[37])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q39rb = findViewById(Question39_Rgroup.getCheckedRadioButtonId());
        int answerNr38 = Question39_Rgroup.indexOfChild(Q39rb)+1;
        if (answerNr38 == answerKeys[38])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q40rb = findViewById(Question40_Rgroup.getCheckedRadioButtonId());
        int answerNr39 = Question40_Rgroup.indexOfChild(Q40rb)+1;
        if (answerNr39 == answerKeys[39])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q41rb = findViewById(Question41_Rgroup.getCheckedRadioButtonId());
        int answerNr40 = Question41_Rgroup.indexOfChild(Q41rb)+1;
        if (answerNr40 ==answerKeys[40])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q42rb = findViewById(Question42_Rgroup.getCheckedRadioButtonId());
        int answerNr41 = Question42_Rgroup.indexOfChild(Q42rb)+1;
        if (answerNr41 == answerKeys[41])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q43rb = findViewById(Question43_Rgroup.getCheckedRadioButtonId());
        int answerNr42 = Question43_Rgroup.indexOfChild(Q43rb)+1;
        if (answerNr42 == answerKeys[42])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q44rb = findViewById(Question43_Rgroup.getCheckedRadioButtonId());
        int answerNr43 = Question44_Rgroup.indexOfChild(Q44rb)+1;
        if (answerNr43 == answerKeys[43])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        RadioButton Q45rb = findViewById(Question45_Rgroup.getCheckedRadioButtonId());
        int answerNr44 = Question45_Rgroup.indexOfChild(Q45rb)+1;
        if (answerNr44 ==answerKeys[44])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q46rb = findViewById(Question46_Rgroup.getCheckedRadioButtonId());
        int answerNr45 = Question46_Rgroup.indexOfChild(Q46rb)+1;
        if (answerNr45 == answerKeys[45])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q47rb = findViewById(Question47_Rgroup.getCheckedRadioButtonId());
        int answerNr46 = Question47_Rgroup.indexOfChild(Q47rb)+1;
        if (answerNr46 == answerKeys[46])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q48rb = findViewById(Question48_Rgroup.getCheckedRadioButtonId());
        int answerNr47 = Question48_Rgroup.indexOfChild(Q48rb)+1;
        if (answerNr47 == answerKeys[47])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q49rb = findViewById(Question49_Rgroup.getCheckedRadioButtonId());
        int answerNr48 = Question49_Rgroup.indexOfChild(Q49rb)+1;
        if (answerNr48 == answerKeys[48])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q50rb = findViewById(Question50_Rgroup.getCheckedRadioButtonId());
        int answerNr49 = Question50_Rgroup.indexOfChild(Q50rb)+1;
        if (answerNr49 == answerKeys[49])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q51rb = findViewById(Question51_Rgroup.getCheckedRadioButtonId());
        int answerNr50 = Question51_Rgroup.indexOfChild(Q51rb)+1;
        if (answerNr50 ==answerKeys[50])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q52rb = findViewById(Question52_Rgroup.getCheckedRadioButtonId());
        int answerNr51 = Question52_Rgroup.indexOfChild(Q52rb)+1;
        if (answerNr51 == answerKeys[51])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q53rb = findViewById(Question53_Rgroup.getCheckedRadioButtonId());
        int answerNr52 = Question53_Rgroup.indexOfChild(Q53rb)+1;
        if (answerNr52 == answerKeys[52])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q54rb = findViewById(Question54_Rgroup.getCheckedRadioButtonId());
        int answerNr53 = Question54_Rgroup.indexOfChild(Q54rb)+1;
        if (answerNr53 == answerKeys[53])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        RadioButton Q55rb = findViewById(Question55_Rgroup.getCheckedRadioButtonId());
        int answerNr54 = Question55_Rgroup.indexOfChild(Q55rb)+1;
        if (answerNr54 ==answerKeys[54])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q56rb = findViewById(Question56_Rgroup.getCheckedRadioButtonId());
        int answerNr55 = Question56_Rgroup.indexOfChild(Q56rb)+1;
        if (answerNr55 == answerKeys[55])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q57rb = findViewById(Question57_Rgroup.getCheckedRadioButtonId());
        int answerNr56 = Question57_Rgroup.indexOfChild(Q57rb)+1;
        if (answerNr56 == answerKeys[56])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q58rb = findViewById(Question58_Rgroup.getCheckedRadioButtonId());
        int answerNr57 = Question58_Rgroup.indexOfChild(Q58rb)+1;
        if (answerNr57 == answerKeys[57])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q59rb = findViewById(Question59_Rgroup.getCheckedRadioButtonId());
        int answerNr58 = Question59_Rgroup.indexOfChild(Q59rb)+1;
        if (answerNr58 == answerKeys[58])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q60rb = findViewById(Question60_Rgroup.getCheckedRadioButtonId());
        int answerNr59 = Question60_Rgroup.indexOfChild(Q60rb)+1;
        if (answerNr59 == answerKeys[59])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q61rb = findViewById(Question61_Rgroup.getCheckedRadioButtonId());
        int answerNr60 = Question61_Rgroup.indexOfChild(Q61rb)+1;
        if (answerNr60 ==answerKeys[60])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q62rb = findViewById(Question62_Rgroup.getCheckedRadioButtonId());
        int answerNr61 = Question62_Rgroup.indexOfChild(Q62rb)+1;
        if (answerNr61 == answerKeys[61])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q63rb = findViewById(Question63_Rgroup.getCheckedRadioButtonId());
        int answerNr62 = Question63_Rgroup.indexOfChild(Q63rb)+1;
        if (answerNr62 == answerKeys[62])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q64rb = findViewById(Question64_Rgroup.getCheckedRadioButtonId());
        int answerNr63 = Question64_Rgroup.indexOfChild(Q64rb)+1;
        if (answerNr63 == answerKeys[63])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        RadioButton Q65rb = findViewById(Question65_Rgroup.getCheckedRadioButtonId());
        int answerNr64 = Question65_Rgroup.indexOfChild(Q65rb)+1;
        if (answerNr64 ==answerKeys[64])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q66rb = findViewById(Question66_Rgroup.getCheckedRadioButtonId());
        int answerNr65 = Question66_Rgroup.indexOfChild(Q66rb)+1;
        if (answerNr65 == answerKeys[65])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q67rb = findViewById(Question67_Rgroup.getCheckedRadioButtonId());
        int answerNr66 = Question67_Rgroup.indexOfChild(Q67rb)+1;
        if (answerNr66 == answerKeys[66])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q68rb = findViewById(Question68_Rgroup.getCheckedRadioButtonId());
        int answerNr67 = Question68_Rgroup.indexOfChild(Q68rb)+1;
        if (answerNr67 == answerKeys[67])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q69rb = findViewById(Question69_Rgroup.getCheckedRadioButtonId());
        int answerNr68 = Question69_Rgroup.indexOfChild(Q69rb)+1;
        if (answerNr68 == answerKeys[68])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q70rb = findViewById(Question70_Rgroup.getCheckedRadioButtonId());
        int answerNr69 = Question70_Rgroup.indexOfChild(Q70rb)+1;
        if (answerNr69 == answerKeys[69])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q71rb = findViewById(Question71_Rgroup.getCheckedRadioButtonId());
        int answerNr70 = Question71_Rgroup.indexOfChild(Q71rb)+1;
        if (answerNr70 ==answerKeys[70])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q72rb = findViewById(Question72_Rgroup.getCheckedRadioButtonId());
        int answerNr71 = Question72_Rgroup.indexOfChild(Q72rb)+1;
        if (answerNr71 == answerKeys[71])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q73rb = findViewById(Question73_Rgroup.getCheckedRadioButtonId());
        int answerNr72 = Question73_Rgroup.indexOfChild(Q73rb)+1;
        if (answerNr72 == answerKeys[72])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q74rb = findViewById(Question74_Rgroup.getCheckedRadioButtonId());
        int answerNr73 = Question74_Rgroup.indexOfChild(Q74rb)+1;
        if (answerNr73 == answerKeys[73])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        RadioButton Q75rb = findViewById(Question75_Rgroup.getCheckedRadioButtonId());
        int answerNr74 = Question75_Rgroup.indexOfChild(Q75rb)+1;
        if (answerNr74 ==answerKeys[74])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q76rb = findViewById(Question76_Rgroup.getCheckedRadioButtonId());
        int answerNr75 = Question76_Rgroup.indexOfChild(Q76rb)+1;
        if (answerNr75 == answerKeys[75])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q77rb = findViewById(Question77_Rgroup.getCheckedRadioButtonId());
        int answerNr76 = Question77_Rgroup.indexOfChild(Q77rb)+1;
        if (answerNr76 == answerKeys[76])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q78rb = findViewById(Question78_Rgroup.getCheckedRadioButtonId());
        int answerNr77 = Question78_Rgroup.indexOfChild(Q78rb)+1;
        if (answerNr77 == answerKeys[77])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q79rb = findViewById(Question79_Rgroup.getCheckedRadioButtonId());
        int answerNr78 = Question79_Rgroup.indexOfChild(Q79rb)+1;
        if (answerNr78 == answerKeys[78])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q80rb = findViewById(Question80_Rgroup.getCheckedRadioButtonId());
        int answerNr79 = Question80_Rgroup.indexOfChild(Q80rb)+1;
        if (answerNr79 == answerKeys[79])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q81rb = findViewById(Question81_Rgroup.getCheckedRadioButtonId());
        int answerNr80 = Question81_Rgroup.indexOfChild(Q81rb)+1;
        if (answerNr80 ==answerKeys[80])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q82rb = findViewById(Question82_Rgroup.getCheckedRadioButtonId());
        int answerNr81 = Question82_Rgroup.indexOfChild(Q82rb)+1;
        if (answerNr81 == answerKeys[81])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q83rb = findViewById(Question83_Rgroup.getCheckedRadioButtonId());
        int answerNr82 = Question83_Rgroup.indexOfChild(Q83rb)+1;
        if (answerNr82 == answerKeys[82])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q84rb = findViewById(Question84_Rgroup.getCheckedRadioButtonId());
        int answerNr83 = Question84_Rgroup.indexOfChild(Q84rb)+1;
        if (answerNr83 == answerKeys[83])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        RadioButton Q85rb = findViewById(Question85_Rgroup.getCheckedRadioButtonId());
        int answerNr84 = Question85_Rgroup.indexOfChild(Q85rb)+1;
        if (answerNr84 ==answerKeys[84])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q86rb = findViewById(Question86_Rgroup.getCheckedRadioButtonId());
        int answerNr85 = Question86_Rgroup.indexOfChild(Q86rb)+1;
        if (answerNr85 == answerKeys[85])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q87rb = findViewById(Question87_Rgroup.getCheckedRadioButtonId());
        int answerNr86 = Question87_Rgroup.indexOfChild(Q87rb)+1;
        if (answerNr86 == answerKeys[86])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q88rb = findViewById(Question88_Rgroup.getCheckedRadioButtonId());
        int answerNr87 = Question88_Rgroup.indexOfChild(Q88rb)+1;
        if (answerNr87 == answerKeys[87])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q89rb = findViewById(Question89_Rgroup.getCheckedRadioButtonId());
        int answerNr88 = Question89_Rgroup.indexOfChild(Q89rb)+1;
        if (answerNr88 == answerKeys[88])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q90rb = findViewById(Question90_Rgroup.getCheckedRadioButtonId());
        int answerNr89 = Question90_Rgroup.indexOfChild(Q90rb)+1;
        if (answerNr89 == answerKeys[89])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q91rb = findViewById(Question91_Rgroup.getCheckedRadioButtonId());
        int answerNr90 = Question91_Rgroup.indexOfChild(Q91rb)+1;
        if (answerNr90 ==answerKeys[90])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q92rb = findViewById(Question92_Rgroup.getCheckedRadioButtonId());
        int answerNr91 = Question92_Rgroup.indexOfChild(Q92rb)+1;
        if (answerNr91 == answerKeys[91])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q93rb = findViewById(Question93_Rgroup.getCheckedRadioButtonId());
        int answerNr92 = Question93_Rgroup.indexOfChild(Q93rb)+1;
        if (answerNr92 == answerKeys[92])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q94rb = findViewById(Question94_Rgroup.getCheckedRadioButtonId());
        int answerNr93 = Question94_Rgroup.indexOfChild(Q94rb)+1;
        if (answerNr93 == answerKeys[93])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        RadioButton Q95rb = findViewById(Question95_Rgroup.getCheckedRadioButtonId());
        int answerNr94 = Question95_Rgroup.indexOfChild(Q95rb)+1;
        if (answerNr94 ==answerKeys[94])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q96rb = findViewById(Question96_Rgroup.getCheckedRadioButtonId());
        int answerNr95 = Question96_Rgroup.indexOfChild(Q96rb)+1;
        if (answerNr95 == answerKeys[95])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q97rb = findViewById(Question97_Rgroup.getCheckedRadioButtonId());
        int answerNr96 = Question97_Rgroup.indexOfChild(Q97rb)+1;
        if (answerNr96 == answerKeys[96])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q98rb = findViewById(Question98_Rgroup.getCheckedRadioButtonId());
        int answerNr97 = Question98_Rgroup.indexOfChild(Q98rb)+1;
        if (answerNr97 == answerKeys[97])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q99rb = findViewById(Question99_Rgroup.getCheckedRadioButtonId());
        int answerNr98 = Question99_Rgroup.indexOfChild(Q99rb)+1;
        if (answerNr98 == answerKeys[98])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q100rb = findViewById(Question100_Rgroup.getCheckedRadioButtonId());
        int answerNr99 = Question100_Rgroup.indexOfChild(Q100rb)+1;
        if (answerNr99 == answerKeys[99])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q101rb = findViewById(Question101_Rgroup.getCheckedRadioButtonId());
        int answerNr100 = Question101_Rgroup.indexOfChild(Q101rb)+1;
        if (answerNr100 ==answerKeys[100])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q102rb = findViewById(Question102_Rgroup.getCheckedRadioButtonId());
        int answerNr101 = Question102_Rgroup.indexOfChild(Q102rb)+1;
        if (answerNr101 == answerKeys[101])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q103rb = findViewById(Question103_Rgroup.getCheckedRadioButtonId());
        int answerNr102 = Question103_Rgroup.indexOfChild(Q103rb)+1;
        if (answerNr102 == answerKeys[102])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q104rb = findViewById(Question104_Rgroup.getCheckedRadioButtonId());
        int answerNr103 = Question104_Rgroup.indexOfChild(Q104rb)+1;
        if (answerNr103 == answerKeys[103])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        RadioButton Q105rb = findViewById(Question105_Rgroup.getCheckedRadioButtonId());
        int answerNr104 = Question105_Rgroup.indexOfChild(Q105rb)+1;
        if (answerNr104 ==answerKeys[104])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q106rb = findViewById(Question106_Rgroup.getCheckedRadioButtonId());
        int answerNr105 = Question106_Rgroup.indexOfChild(Q106rb)+1;
        if (answerNr105 == answerKeys[105])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q107rb = findViewById(Question107_Rgroup.getCheckedRadioButtonId());
        int answerNr106 = Question107_Rgroup.indexOfChild(Q107rb)+1;
        if (answerNr106 == answerKeys[106])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q108rb = findViewById(Question108_Rgroup.getCheckedRadioButtonId());
        int answerNr107 = Question108_Rgroup.indexOfChild(Q108rb)+1;
        if (answerNr107 == answerKeys[107])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }
        //
        RadioButton Q109rb = findViewById(Question109_Rgroup.getCheckedRadioButtonId());
        int answerNr108 = Question109_Rgroup.indexOfChild(Q109rb)+1;
        if (answerNr108 == answerKeys[108])
        {
            score ++;
            txt_score.setText("Score: "+ score);
        }

        showSolution();
        showSolution2();
        showSolution3();
        showSolution4();
        showSolution5();
        showSolution6();
        showSolution7();
        showSolution8();
        showSolution9();
        showSolution10();
        showSolution11();
        showSolution12();
        showSolution13();
        showSolution14();
        showSolution15();
        showSolution16();
        showSolution17();
        showSolution18();
        showSolution19();
        showSolution20();
        showSolution21();
        showSolution22();
        showSolution23();
        showSolution24();
        showSolution25();
        showSolution26();
        showSolution27();
        showSolution28();
        showSolution29();
        showSolution30();
        showSolution31();
        showSolution32();
        showSolution33();
        showSolution34();
        showSolution35();
        showSolution36();
        showSolution37();
        showSolution38();
        showSolution39();
        showSolution40();
        showSolution41();
        showSolution42();
        showSolution43();
        showSolution44();
        showSolution45();
        showSolution46();
        showSolution47();
        showSolution48();
        showSolution49();
        showSolution50();
        showSolution51();
        showSolution52();
        showSolution53();
        showSolution54();
        showSolution55();
        showSolution56();
        showSolution57();
        showSolution58();
        showSolution59();
        showSolution60();
        showSolution61();
        showSolution62();
        showSolution63();
        showSolution64();
        showSolution65();
        showSolution66();
        showSolution67();
        showSolution68();
        showSolution69();
        showSolution70();
        showSolution71();
        showSolution72();
        showSolution73();
        showSolution74();
        showSolution75();
        showSolution76();
        showSolution77();
        showSolution78();
        showSolution79();
        showSolution80();
        showSolution81();
        showSolution82();
        showSolution83();
        showSolution84();
        showSolution85();
        showSolution86();
        showSolution87();
        showSolution88();
        showSolution89();
        showSolution90();
        showSolution91();
        showSolution92();
        showSolution93();
        showSolution94();
        showSolution95();
        showSolution96();
        showSolution97();
        showSolution98();
        showSolution99();
        showSolution100();
        showSolution101();
        showSolution102();
        showSolution103();
        showSolution104();
        showSolution105();
        showSolution106();
        showSolution107();
        showSolution108();
        showSolution109();

    }

    //
    //Timer Countdown
    //
private void startCountdown()
{
    cdtimer = new CountDownTimer(timeleft,1000) {
        @Override
        public void onTick(long millisUntilFinished) {
            timeleft = millisUntilFinished;
            updatecountdown();
        }
        //
        //Displaying Answer keys
        //
        @Override
        public void onFinish() {
            timeleft = 0;
            updatecountdown();
            showResult();
            cdtimer.cancel();
        }
    }.start();
}


    //
    //Creating Timer CountDown
    //
    private void updatecountdown()
    {
        int hrs     = (int) (timeleft / (1000 * 60 * 60)) %24;
        int mins    = (int) (timeleft / (1000 * 60)) %60;
        int secs    = (int) (timeleft / 1000) %60;

        String timeformatted = String.format(Locale.getDefault(), "%02d:%02d:%02d",hrs,mins, secs);
        txt_time.setText(timeformatted);
        if (timeleft > 600000)
        {
            txt_time.setTextColor(textDefualt);

            return;
        }
        else  if (timeleft <= 600000 && timeleft > 595000)
        {
            Toast.makeText(getBaseContext(), "You only have 10 Minutes", Toast.LENGTH_SHORT).show();
            txt_time.setTextColor(Color.RED);
        }
        else
        {
            txt_time.setTextColor(Color.RED);

        }
    }


    private void finishquiz()
    {
        finish();
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        if (cdtimer != null)
        {
            cdtimer.cancel();
        }
    }


    @Override
    public void onBackPressed() {

        if(back_pressed + 2000 > System.currentTimeMillis())
        {
            super.onBackPressed();
            return;
        }
        else
        {
            Toast.makeText(getBaseContext(), "Please Back again to exit", Toast.LENGTH_SHORT).show();
        }
        back_pressed = System.currentTimeMillis();
    }
}
