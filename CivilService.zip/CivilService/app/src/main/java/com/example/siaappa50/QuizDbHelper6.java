package com.example.siaappa50;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
import com.example.siaappa50.QuizContact.*;

import java.util.ArrayList;
import java.util.List;

public class QuizDbHelper6 extends SQLiteOpenHelper {
    //    Name of DataBase
    private static final String DATABASE_NAME = "myawesomequiz6.db";
    private static final int DATABASE_VERSION = 1;

    private SQLiteDatabase db;

    public QuizDbHelper6(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);


    }

    //    To Create Sqlite Database
    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;
        final String SQL_CRETE_QUESTION_TABLE = " CREATE TABLE " + QuizContact.QuestionTables.TABLE_NAME + " ( " + QuestionTables._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionTables.COLUMN_QUESTION + " TEXT, " + QuestionTables.COLUMN_OPTION1 + " TEXT, " + QuestionTables.COLUMN_OPTION2 + " TEXT, " + QuestionTables.COLUMN_OPTION3 + " TEXT, " + QuestionTables.COLUMN_OPTION4 + " TEXT, " + QuestionTables.COLUMN_ANSWER_NR + " INTEGER " + " ) ";
        db.execSQL(SQL_CRETE_QUESTION_TABLE);

        fillQuestionTable();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(" DROP TABLE IF EXISTS " + QuestionTables.TABLE_NAME);
        onCreate(db);
    }

    //    Question and Answer here      //
    private void fillQuestionTable() {
        Question q1 = new Question("A. One effective way is to diversify his funds to different investments like real estate, stocks and money instruments like bonds and trust funds.\n" +
                "B. It is always best to expand money to different investment wheels.\n" +
                "C. A wise investor must not put all his eggs in one basket.\n" +
                "D. He should always consider the risks involved in investing his money.", "CBAD ", "CBDA", " CDAB", "CDBA", 2);
        addQuestion(q1);
        Question q2 = new Question("A. It is very vital to have social media presence however personal blogs serve as web domains.\n" +
                "B. Most people including celebrities and businessmen have blogs nowadays.\n" +
                "C. Therefore, building them will help anyone in promoting himself or his business.\n" +
                "D. Apparently blogs are like our offices only they are in the internet.", "BDAC", "BADC", "BACD", " BDCA", 3);
        addQuestion(q2);
        Question q3 = new Question("A. The basic steps in building a website are easy to remember and registering a domain name is the usual priority.\n" +
                "B. Designing a layout will come after that.\n" +
                "C. Finally, adding more content and social media presence are required to keep your site active.\n" +
                "D. Then you need a hosting provider to host your site’s content in the World Wide Web.", "ABCD", "ADBC", "ACBD", "ADCB", 1);
        addQuestion(q3);
        Question q4 = new Question("A. Speaking in English every day is also proven effective.\n" +
                "B. Another way is watching English movies and TV shows particularly with English subtitles.\n" +
                "C. Reading articles in books, newspapers, and magazines is just among the helpful ways.\n" +
                "D. There are many ways to improve and develop English proficiency.", "DCBA", "DACB", "DABC    ", "DCAB", 2);
        addQuestion(q4);
        Question q5 = new Question("A. Others don’t realize yet what to pursue because they have many dreams.\n" +
                "B. Finding the right course in college is one of the most challenging decisions anyone can make.\n" +
                "C. Some people want to pursue their dreams ever since they were just little.\n" +
                "D. Indeed destiny is a matter of choice.", "BDAC", "BCDA", "BADC   ", "BCAD", 4);
        addQuestion(q5);
        Question q6 = new Question("A. While passport, airline tickets and valid IDs are required, proof of financial capacity may be required for visa application.\n" +
                "B. Many Filipinos rejoiced hearing that good news.\n" +
                "C. The Bureau of Immigration announced recently that proof of financial capacity is not a primary requirement at the airport.\n" +
                "D. Positive points go to the bureau for this.", "CBAD", "CADB", " CABD", "CBDA", 2);
        addQuestion(q6);
        Question q7 = new Question("A. This will be one of your tickets to land a job in the government.\n" +
                "B. That is why many people apply to take the Career Service examination.\n" +
                "C. If you passed the exam, you will get a certificate of eligibility.\n" +
                "D. Career Service Eligibility is a major requirement to apply for a job position in the government.", "DCBA ", "DBAC ", "DBCA ", "DCAB", 1);
        addQuestion(q7);
        Question q8 = new Question("A. Your passport will arrive in 7 days if you choose the rush processing.\n" +
                "B. Getting a passport is faster nowadays.\n" +
                "C. Now, it only takes about 10 working days.\n" +
                "D. Compared before, it would take about a month for the regular processing.", "BCAD  ", "BDCA", "BADC", "BACD", 2);
        addQuestion(q8);
        Question q9 = new Question("A. Facebook has been the number one social network in the web and the world for quite long now.\n" +
                "B. Mobile instant messaging apps are also dominating social presence in the internet.\n" +
                "C. After many acquisitions, Facebook bought Instagram, one of the fastest growing photo sharing networks.\n" +
                "D. Because of that, Facebook acquired WhatsApp, a leading instant chat platform like Kakaotalk.", "ACBD", "ABCD ", "ADCB ", "ADBC", 3);
        addQuestion(q9);
        Question q10 = new Question("A. They will help you to purchase through zero-interest installment schemes.\n" +
                "B. Thus, you must be wise and pay in full if you want to avoid never-ending debts.\n" +
                "C. Credit cards are helpful if you know how and when to use them wisely.\n" +
                "D. However, they will produce interests from interests if you didn’t pay the whole amount at the due date.", "CDBA", "CABD", "CDAB  ", "CADB", 1);
        addQuestion(q10);
    }


    private void addQuestion(Question question) {
        ContentValues Content_val = new ContentValues();
        Content_val.put(QuestionTables.COLUMN_QUESTION, question.getQuestion());
        Content_val.put(QuestionTables.COLUMN_OPTION1, question.getOption1());
        Content_val.put(QuestionTables.COLUMN_OPTION2, question.getOption2());
        Content_val.put(QuestionTables.COLUMN_OPTION3, question.getOption3());
        Content_val.put(QuestionTables.COLUMN_OPTION4, question.getOption4());
        Content_val.put(QuestionTables.COLUMN_ANSWER_NR, question.getAnswer());
        db.insert(QuestionTables.TABLE_NAME, null, Content_val);
    }

    public List<Question> getAllQuestions() {
        List<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery(" SELECT * FROM " + QuestionTables.TABLE_NAME, null);
        if (c.moveToFirst()) {
            do {
                Question questions = new Question();
                questions.setQuestion((c.getString(c.getColumnIndex(QuestionTables.COLUMN_QUESTION))));
                questions.setOption1((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION1))));
                questions.setOption2((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION2))));
                questions.setOption3((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION3))));
                questions.setOption4((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION4))));
                questions.setAnswer((c.getInt(c.getColumnIndex(QuestionTables.COLUMN_ANSWER_NR))));
                questionList.add(questions);
            } while (c.moveToNext());
        }
        else if (c.moveToPrevious())
        {
            do {
                Question questions = new Question();
                questions.setQuestion((c.getString(c.getColumnIndex(QuestionTables.COLUMN_QUESTION))));
                questions.setOption1((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION1))));
                questions.setOption2((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION2))));
                questions.setOption3((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION3))));
                questions.setOption4((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION4))));
                questions.setAnswer((c.getInt(c.getColumnIndex(QuestionTables.COLUMN_ANSWER_NR))));
                questionList.add(questions);
            } while (c.moveToPrevious());
        }
        c.close();
        return questionList;

    }
}
