package com.example.siaappa50;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Main3Activity extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main3);

    BottomNavigationView navigationView = findViewById(R.id.bottom_navigation);

    navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
      @Override
      public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();

        if (id == R.id.nav_home) {
          Fragment_quiz fragment = new Fragment_quiz();
          FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
          fragmentTransaction.replace(R.id.fragment_container, fragment);
          fragmentTransaction.commit();
        }
        if (id == R.id.nav_favorites) {
          Fragment_exam fragment = new Fragment_exam();
          FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
          fragmentTransaction.replace(R.id.fragment_container, fragment);
          fragmentTransaction.commit();
        }
        if (id == R.id.nav_search) {
          Fragment_categories fragment = new Fragment_categories();
          FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
          fragmentTransaction.replace(R.id.fragment_container, fragment);
          fragmentTransaction.commit();
        }
        return true;
      }

    });
    navigationView.setSelectedItemId(R.id.nav_home);

  }
}
