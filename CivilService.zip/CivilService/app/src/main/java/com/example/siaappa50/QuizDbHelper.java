package com.example.siaappa50;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
import com.example.siaappa50.QuizContact.*;

import java.util.ArrayList;
import java.util.List;

public class QuizDbHelper extends SQLiteOpenHelper {
    //    Name of DataBase
    private static final String DATABASE_NAME = "myawesomequiz.db";
    private static final int DATABASE_VERSION = 1;

    private SQLiteDatabase db;

    public QuizDbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);


    }

    //    To Create Sqlite Database
    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;
        final String SQL_CRETE_QUESTION_TABLE = " CREATE TABLE " + QuizContact.QuestionTables.TABLE_NAME + " ( " + QuestionTables._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionTables.COLUMN_QUESTION + " TEXT, " + QuestionTables.COLUMN_OPTION1 + " TEXT, " + QuestionTables.COLUMN_OPTION2 + " TEXT, " + QuestionTables.COLUMN_OPTION3 + " TEXT, " + QuestionTables.COLUMN_OPTION4 + " TEXT, " + QuestionTables.COLUMN_ANSWER_NR + " INTEGER " + " ) ";
        db.execSQL(SQL_CRETE_QUESTION_TABLE);

        fillQuestionTable();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(" DROP TABLE IF EXISTS " + QuestionTables.TABLE_NAME);
        onCreate(db);
    }

    //    Question and Answer here      //
    private void fillQuestionTable() {
        Question q1 = new Question("Iron: metal: : Granite: ______", "Marble ", "Rock", "Sand", "Solid", 2);
        addQuestion(q1);
        Question q2 = new Question("Decibel: sound: : volt: ______", "Watts", "Fire", "Electricity", "Lightning", 3);
        addQuestion(q2);
        Question q3 = new Question("Coward: brave: : philanthropist: _______", "Selfish", "Kind", "Pessimist", "Optimist", 1);
        addQuestion(q3);
        Question q4 = new Question("Logic: reasoning: : ethics: _______", "Character", "Behavior", "Subject", "Traits", 2);
        addQuestion(q4);
        Question q5 = new Question("Antenna: signal: : net: ______", "Web", "Catch", "Gross", "Fish", 4);
        addQuestion(q5);
        Question q6 = new Question("Stanza: poem : Act: ______", "Movie", "Opera", "Song", "Lyric", 2);
        addQuestion(q6);
        Question q7 = new Question("Astrology: Astronomy : Alchemy: ______", "Chemistry", "Biology", "Physics", "Science", 1);
        addQuestion(q7);
        Question q8 = new Question("Census: Population : Inventory: ______", "Accounting", "Merchandise", "Cost", "List", 2);
        addQuestion(q8);
        Question q9 = new Question("Oath: Promise : Contract: ______", "License", "Contract", "Agreement", "Paper", 3);
        addQuestion(q9);
        Question q10 = new Question("Glimmer: Flicker : Murmur:  ______", "Whisper", "Shout", "Rumor", "Speak", 1);
        addQuestion(q10);
        Question q11 = new Question("Bouquet: Flower : Flock:  ______", "Dogs", "Sheep", "Ship", "Cats", 2);
        addQuestion(q11);
        Question q12 = new Question("Rescind: Law : Withdraw: ______", "Bank", "Candidacy", "Deposit", "Resume", 2);
        addQuestion(q12);
        Question q13 = new Question("Hoax: Deceive : Filibuster: ______", "Delay", "Refuse", "Stop", "None", 1);
        addQuestion(q13);
        Question q14= new Question("Syllabus: Course : Agenda: ______", "Subject", "Platform", "Meeting", "Lesson", 3);
        addQuestion(q14);
        Question q15 = new Question("Cat: Kitten : Horse: ______", "Cab", "Puppy", "Stallion", "Pony", 4);
        addQuestion(q15);
        Question q16 = new Question("Evaporate: Vapor : Petrify: ______", "Liquid", "Stone", "Magnify", "Cold", 2);
        addQuestion(q16);
        Question q17 = new Question("Canvas: Painter : Marble: ______", "Sculptor", "Rock", "Statue", "Form", 1);
        addQuestion(q17);
        Question q18 = new Question("Hammer: Anvil : Pestle: ______", "Ground", "Grinder", "Mortar", "Knife", 3);
        addQuestion(q18);
        Question q19 = new Question("Librarian: Books : Curator ______", "Atlas", "Encyclopedia", "Room", "Paintings", 4);
        addQuestion(q19);
        Question q20 = new Question("Archive: Manuscript : Arsenal: ______", "Soldier", "Weapon", "Castle", "King", 2);
        addQuestion(q20);
    }


    private void addQuestion(Question question) {
        ContentValues Content_val = new ContentValues();
        Content_val.put(QuestionTables.COLUMN_QUESTION, question.getQuestion());
        Content_val.put(QuestionTables.COLUMN_OPTION1, question.getOption1());
        Content_val.put(QuestionTables.COLUMN_OPTION2, question.getOption2());
        Content_val.put(QuestionTables.COLUMN_OPTION3, question.getOption3());
        Content_val.put(QuestionTables.COLUMN_OPTION4, question.getOption4());
        Content_val.put(QuestionTables.COLUMN_ANSWER_NR, question.getAnswer());
        db.insert(QuestionTables.TABLE_NAME, null, Content_val);
    }

    public List<Question> getAllQuestions() {
        List<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery(" SELECT * FROM " + QuestionTables.TABLE_NAME, null);
        if (c.moveToFirst()) {
            do {
                Question questions = new Question();
                questions.setQuestion((c.getString(c.getColumnIndex(QuestionTables.COLUMN_QUESTION))));
                questions.setOption1((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION1))));
                questions.setOption2((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION2))));
                questions.setOption3((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION3))));
                questions.setOption4((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION4))));
                questions.setAnswer((c.getInt(c.getColumnIndex(QuestionTables.COLUMN_ANSWER_NR))));
                questionList.add(questions);
            } while (c.moveToNext());
        }
        else if (c.moveToPrevious())
        {
            do {
                Question questions = new Question();
                questions.setQuestion((c.getString(c.getColumnIndex(QuestionTables.COLUMN_QUESTION))));
                questions.setOption1((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION1))));
                questions.setOption2((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION2))));
                questions.setOption3((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION3))));
                questions.setOption4((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION4))));
                questions.setAnswer((c.getInt(c.getColumnIndex(QuestionTables.COLUMN_ANSWER_NR))));
                questionList.add(questions);
            } while (c.moveToPrevious());
        }
        c.close();
        return questionList;

    }
}
