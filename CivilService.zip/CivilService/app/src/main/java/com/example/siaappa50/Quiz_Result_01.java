package com.example.siaappa50;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Quiz_Result_01 extends AppCompatActivity {

    Button btn_try_again,btn_exit;
    TextView Anatomy_score, Numeric_score, English_score, Idiomatic_score;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz__result_01);

        Anatomy_score = findViewById(R.id.textView6);
        Numeric_score = findViewById(R.id.textView8);
        English_score = findViewById(R.id.textView7);
        Idiomatic_score = findViewById(R.id.textView9);
        btn_try_again = findViewById(R.id.btn_try_again);
        btn_exit = findViewById(R.id.btn_rxit);


        final SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String name = preferences.getString("Name","");
        if(!name.equalsIgnoreCase("")){
            Anatomy_score.setText(name);}

        String name1 = preferences.getString("Name1","");
        if(!name1.equalsIgnoreCase("")){
            Numeric_score.setText(name1);}

        String name2 = preferences.getString("Name2","");
        if(!name2.equalsIgnoreCase("")){
            English_score.setText(name2);}

        String name3 = preferences.getString("Name3","");
        if(!name3.equalsIgnoreCase("")){
            Idiomatic_score.setText(name3);}


        btn_try_again.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Quiz_Result_01.this,Quiz_Question_01.class);
                startActivity(intent);
            }
        });

        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Quiz_Result_01.this, Main3Activity.class);
                startActivity(intent);
            }
        });
    }


    @Override
    public void onBackPressed() {
    }
}
