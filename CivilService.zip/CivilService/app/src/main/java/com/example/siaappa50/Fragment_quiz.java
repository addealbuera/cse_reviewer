package com.example.siaappa50;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Fragment_quiz extends Fragment {

    public Fragment_quiz(){
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.fragment_quiz, container, false);
        Button buttonQuiz01 = view.findViewById(R.id.buttonQuiz01);
        Button buttonQuiz02 = view.findViewById(R.id.buttonQuiz02);
        Button buttonQuiz03 = view.findViewById(R.id.buttonQuiz03);
        Button buttonQuiz04 = view.findViewById(R.id.buttonQuiz04);
        Button buttonQuiz05 = view.findViewById(R.id.buttonQuiz05);
        Button buttonQuiz06 = view.findViewById(R.id.buttonQuiz06);
        Button buttonQuiz07 = view.findViewById(R.id.buttonQuiz07);
        Button buttonQuiz08 = view.findViewById(R.id.buttonQuiz08);

        buttonQuiz01.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent go = new Intent(getActivity(), Quiz_Question_01.class);
                //go.putExtra("some","some data");
                startActivity(go);
            }
        });
        buttonQuiz02.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent go = new Intent(getActivity(), Quiz_Question_02.class);
                startActivity(go);
            }
        });
        buttonQuiz03.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent go = new Intent(getActivity(), Quiz_Question_03.class);
                startActivity(go);
            }
        });
        buttonQuiz04.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent go = new Intent(getActivity(), Quiz_Question_04.class);
                startActivity(go);
            }
        });
        buttonQuiz05.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent go = new Intent(getActivity(), Quiz_Question_05.class);
                startActivity(go);
            }
        });
        buttonQuiz06.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent go = new Intent(getActivity(), Quiz_Question_06.class);
                startActivity(go);
            }
        });
        buttonQuiz07.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent go = new Intent(getActivity(), Quiz_Question_07.class);
                startActivity(go);
            }
        });
        buttonQuiz08.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent go = new Intent(getActivity(), Quiz_Question_08.class);
                startActivity(go);
            }
        });

        return view;

//        return inflater.inflate(R.layout.fragment_quiz, container, false);

    }
}
