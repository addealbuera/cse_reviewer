package com.example.siaappa50;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
import com.example.siaappa50.QuizContact.*;

import java.util.ArrayList;
import java.util.List;

public class QuizDbHelper5 extends SQLiteOpenHelper {
    //    Name of DataBase
    private static final String DATABASE_NAME = "myawesomequiz5.db";
    private static final int DATABASE_VERSION = 1;

    private SQLiteDatabase db;

    public QuizDbHelper5(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);


    }

    //    To Create Sqlite Database
    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;
        final String SQL_CRETE_QUESTION_TABLE = " CREATE TABLE " + QuizContact.QuestionTables.TABLE_NAME + " ( " + QuestionTables._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionTables.COLUMN_QUESTION + " TEXT, " + QuestionTables.COLUMN_OPTION1 + " TEXT, " + QuestionTables.COLUMN_OPTION2 + " TEXT, " + QuestionTables.COLUMN_OPTION3 + " TEXT, " + QuestionTables.COLUMN_OPTION4 + " TEXT, " + QuestionTables.COLUMN_ANSWER_NR + " INTEGER " + " ) ";
        db.execSQL(SQL_CRETE_QUESTION_TABLE);

        fillQuestionTable();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(" DROP TABLE IF EXISTS " + QuestionTables.TABLE_NAME);
        onCreate(db);
    }

    //    Question and Answer here      //
    private void fillQuestionTable() {
        Question q1 = new Question("Which department of an office is responsible for hiring new personnel?", "Office of the President ", "Accounting Department", "Logistic and Supply", "Human Resource Department", 4);
        addQuestion(q1);
        Question q2 = new Question("Which computer program should you go if you want to email a company?", "Word", "Excel", "Outlook", "Powerpoint", 3);
        addQuestion(q2);
        Question q3 = new Question(" This is a telephonic transmission of scanned documents of texts and images to a telephone number connected to a printer.", "Photocopying Machine", "Fax Machine", "Typewriter", "Inkjet Printer", 2);
        addQuestion(q3);
        Question q4 = new Question("The chief financial officer is responsible for the financial matters and financial management of a corporation, she is also known as the _______.", "Auditor", "Treasurer", "Chief Executive Officer", "Manager", 2);
        addQuestion(q4);
        Question q5 = new Question("Which department of a company is responsible for cash register operations and payment processing?", "Cashier", "Billing", "Accounting", "Budget", 1);
        addQuestion(q5);
        Question q6 = new Question(" All of the following items are found in the Official Receipt form except _____.", "Name and address of the buyer", " Signature of the recipient", "Quantity of the items paid", "Credit Card Number of the customer", 1);
        addQuestion(q6);
        Question q7 = new Question(" The method of indexing and filing where names are in alphabetized order.", "Geographic", "Numeric", "Metric", "Alphabetic", 4);
        addQuestion(q7);
        Question q8 = new Question("Which is the best way to address a correspondence for the President of the Philippines?", "His Excellency Rodrigo Duterte", "His Excellency President Rodrigo Duterte", "President Rodrigo Duterte", "President Digong", 2);
        addQuestion(q8);
        Question q9 = new Question(" How do you address the Queen of England when you talk about her?", "Her Highness the Queen", "Her Majesty Queen Elizabeth II", "Queen Elizabeth II her Highness", "Queen Elizabeth II her Majesty", 2);
        addQuestion(q9);
        Question q10 = new Question("Your boss asked you to send her a soft copy of your latest résumé. An example of a soft copy is:", "A print out copy usually in a paper", "Original copy written in a paper", "A copy saved in a computer and sent through email", "A copy from a Xerox machine", 3);
        addQuestion(q10);
        Question q11 = new Question("When a company asked you to submit your latest CV, what does CV stand for?", "Curriculum Vitum", "Curriculum Virtue", "Curriculum Vitae", "Curriculum Vital", 3);
        addQuestion(q11);
        Question q12 = new Question("It is the section of Accounting Department in a company that records goods and services that it receives and the payments it owes.", "Budget", "Payroll", "Accounts Payable and Receivable", "Inventory", 3);
        addQuestion(q12);
        Question q13 = new Question(" Which of the following is not a function of Accounting Department in a big corporation?", "Prepare Interim Financial Statements", "Inventory Management", "Bank Reconciliation", "Internal and External Auditing", 4);
        addQuestion(q13);
        Question q14= new Question("He is the highest ranking executive manager in a corporation and he is the top person in command in an organization.", "Chief Financial Executive", "Chief Executive Officer", "Executive Admin. Officer", "Chief Executive Assistant", 2);
        addQuestion(q14);
        Question q15 = new Question("Which of the following is not a responsibility of a clerical worker?", "Marketing and promotion for customers", "Filing and updating purchase orders", "Updating and billing buyer’s account", "Answering business emails", 1);
        addQuestion(q15);
        Question q16 = new Question("How much is the present Value-Added-Tax in the Philippines?", "12% of gross profit", "12% of cost of goods sold", "12% of gross sales", "12% of net income", 3);
        addQuestion(q16);
        Question q17 = new Question("This department of the company is responsible for preparing and updating customers’ accounts:", "Purchasing section", "Cashier section", "Billing Section", "Releasing section", 3);
        addQuestion(q17);
        Question q18 = new Question("This is a type of document issued by a seller to a buyer relating to a sale transaction and indicating the products, quantities and prices sold to the buyer.", "Check voucher", "Purchase order", "Delivery receipt", "Sales invoice", 4);
        addQuestion(q18);
        Question q19 = new Question("Which of the following is not a usual document used in a sales company?", "Form 137", "Delivery receipt", "Sales invoice", "Purchase order", 1);
        addQuestion(q19);
        Question q20 = new Question("One of the responsibilities of a clerical job is answering and tending phone calls. Which is the best way to answer a phone call in a company?", "Say “Hello,” and wait for the caller to speak.", "Run and get a pen and notebook then pick up the phone.", "Answer the phone politely and give your department or company name.", "Wait for fellow employees to answer the phone.", 3);
        addQuestion(q20);
    }


    private void addQuestion(Question question) {
        ContentValues Content_val = new ContentValues();
        Content_val.put(QuestionTables.COLUMN_QUESTION, question.getQuestion());
        Content_val.put(QuestionTables.COLUMN_OPTION1, question.getOption1());
        Content_val.put(QuestionTables.COLUMN_OPTION2, question.getOption2());
        Content_val.put(QuestionTables.COLUMN_OPTION3, question.getOption3());
        Content_val.put(QuestionTables.COLUMN_OPTION4, question.getOption4());
        Content_val.put(QuestionTables.COLUMN_ANSWER_NR, question.getAnswer());
        db.insert(QuestionTables.TABLE_NAME, null, Content_val);
    }

    public List<Question> getAllQuestions() {
        List<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery(" SELECT * FROM " + QuestionTables.TABLE_NAME, null);
        if (c.moveToFirst()) {
            do {
                Question questions = new Question();
                questions.setQuestion((c.getString(c.getColumnIndex(QuestionTables.COLUMN_QUESTION))));
                questions.setOption1((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION1))));
                questions.setOption2((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION2))));
                questions.setOption3((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION3))));
                questions.setOption4((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION4))));
                questions.setAnswer((c.getInt(c.getColumnIndex(QuestionTables.COLUMN_ANSWER_NR))));
                questionList.add(questions);
            } while (c.moveToNext());
        }
        else if (c.moveToPrevious())
        {
            do {
                Question questions = new Question();
                questions.setQuestion((c.getString(c.getColumnIndex(QuestionTables.COLUMN_QUESTION))));
                questions.setOption1((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION1))));
                questions.setOption2((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION2))));
                questions.setOption3((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION3))));
                questions.setOption4((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION4))));
                questions.setAnswer((c.getInt(c.getColumnIndex(QuestionTables.COLUMN_ANSWER_NR))));
                questionList.add(questions);
            } while (c.moveToPrevious());
        }
        c.close();
        return questionList;

    }
}
