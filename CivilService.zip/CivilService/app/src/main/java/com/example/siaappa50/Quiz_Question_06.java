package com.example.siaappa50;
//
//Analogy and Logic
//
//
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Collections;

public class Quiz_Question_06 extends AppCompatActivity {
    TextView txt_question,
            txt_itemcount,txt_score;
    Button btn_next,
            btn_choice1,
            btn_choice2,
            btn_choice3,
            btn_choice4,
            btn_result;

    private static long back_pressed;
    private List<Question> questionlist;

    private int counter;
    private int totalcount;
    private Question currentquestion;

    private int score;
    private boolean answered;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz__question_06);
        txt_question = findViewById(R.id.textView2);
        txt_itemcount = findViewById(R.id.textView3);
        txt_score   =  findViewById(R.id.textView4);
        btn_choice1 = findViewById(R.id.buttonChoice1);
        btn_choice2 = findViewById(R.id.buttonChoice2);
        btn_choice3 = findViewById(R.id.buttonChoice3);
        btn_choice4 = findViewById(R.id.buttonChoice4);
        btn_next = findViewById(R.id.buttonNext);
        btn_result = findViewById(R.id.buttonresult);

        QuizDbHelper5 dbHelper = new QuizDbHelper5(this);
        questionlist = dbHelper.getAllQuestions();
        totalcount = questionlist.size();

        Collections.shuffle(questionlist);
        showNextQuestion();

        txt_score.setText(" " + score + "/" + totalcount);

        final SharedPreferences preference = PreferenceManager.getDefaultSharedPreferences(this);
        final Intent intent = new Intent(this,Quiz_Result_01.class);

        btn_result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = preference.edit();
                editor.putString("Name3",txt_score.getText().toString());
                editor.commit();
                editor.apply();
                startActivity(intent);
            }
        });;
        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showNextQuestion();
            }
        });
        btn_choice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(1 == currentquestion.getAnswer()) {
                    score++;
                    txt_score.setText(" " + score + "/" + totalcount);
                    showSolution();
                }
                else
                {
                    showSolution();
                }
            }
        });
        btn_choice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(2== currentquestion.getAnswer()) {
                    score++;
                    txt_score.setText(" " + score + "/" + totalcount);
                    showSolution();
                }
                else
                {
                    showSolution();
                }
            }
        });
        btn_choice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(3 == currentquestion.getAnswer()) {
                    score++;
                    txt_score.setText(" " + score + "/" + totalcount);
                    showSolution();
                }
                else
                {
                    showSolution();
                }
            }
        });
        btn_choice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(4 == currentquestion.getAnswer()) {
                    score++;
                    txt_score.setText(" " + score + "/" + totalcount);
                    showSolution();
                }
                else
                {
                    showSolution();
                }
            }
        });
    }
    @Override
    public void onBackPressed() {

        if(back_pressed + 2000 > System.currentTimeMillis())
        {
            super.onBackPressed();
            return;
        }
        else
        {
            Toast.makeText(getBaseContext(), "Please Back again to exit", Toast.LENGTH_SHORT).show();
        }
        back_pressed = System.currentTimeMillis();
    }

    private void showNextQuestion() {
        btn_choice1.setBackgroundColor(Color.parseColor("#c0c0c0"));
        btn_choice2.setBackgroundColor(Color.parseColor("#c0c0c0"));
        btn_choice3.setBackgroundColor(Color.parseColor("#c0c0c0"));
        btn_choice4.setBackgroundColor(Color.parseColor("#c0c0c0"));
        btn_choice1.setEnabled(true);
        btn_choice2.setEnabled(true);
        btn_choice3.setEnabled(true);
        btn_choice4.setEnabled(true);
        btn_next.setEnabled(false);

        if (counter < totalcount) {
            currentquestion = questionlist.get(counter);
            txt_question.setText(currentquestion.getQuestion());
            btn_choice1.setText(currentquestion.getOption1());
            btn_choice2.setText(currentquestion.getOption2());
            btn_choice3.setText(currentquestion.getOption3());
            btn_choice4.setText(currentquestion.getOption4());


            counter++;
            txt_itemcount.setText("Question " + counter + " / " + totalcount);
            answered = false;


        } else {
            finishquiz();
        }
    }

    private void showSolution()
    {
        btn_choice1.setBackgroundColor(Color.RED);
        btn_choice2.setBackgroundColor(Color.RED);
        btn_choice3.setBackgroundColor(Color.RED);
        btn_choice4.setBackgroundColor(Color.RED);
        btn_choice1.setEnabled(false);
        btn_choice2.setEnabled(false);
        btn_choice3.setEnabled(false);
        btn_choice4.setEnabled(false);
        btn_next.setEnabled(true);
        switch (currentquestion.getAnswer())
        {
            case 1:
                btn_choice1.setBackgroundColor(Color.GREEN);
                break;
            case 2:
                btn_choice2.setBackgroundColor(Color.GREEN);
                break;
            case 3:
                btn_choice3.setBackgroundColor(Color.GREEN);
                break;
            case 4:
                btn_choice4.setBackgroundColor(Color.GREEN);
                break;
        }
        if (counter < totalcount)
        {
            btn_next.setText("Next");
            btn_result.setEnabled(false);
        }
        else
        {
            btn_next.setEnabled(false);
            btn_result.setEnabled(true);
            btn_next.setVisibility(View.INVISIBLE);
            btn_result.setVisibility(View.VISIBLE);
        }
    }




    private void finishquiz()
    {
        finish();
    }

}
