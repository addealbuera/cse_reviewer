package com.example.siaappa50;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
import com.example.siaappa50.QuizContact.*;

import java.util.ArrayList;
import java.util.List;

public class QuizDbHelper3 extends SQLiteOpenHelper {
    //    Name of DataBase
    private static final String DATABASE_NAME = "myawesomequiz3.db";
    private static final int DATABASE_VERSION = 1;

    private SQLiteDatabase db;

    public QuizDbHelper3(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);


    }

    //    To Create Sqlite Database
    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;
        final String SQL_CRETE_QUESTION_TABLE = " CREATE TABLE " + QuizContact.QuestionTables.TABLE_NAME + " ( " + QuestionTables._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionTables.COLUMN_QUESTION + " TEXT, " + QuestionTables.COLUMN_OPTION1 + " TEXT, " + QuestionTables.COLUMN_OPTION2 + " TEXT, " + QuestionTables.COLUMN_OPTION3 + " TEXT, " + QuestionTables.COLUMN_OPTION4 + " TEXT, " + QuestionTables.COLUMN_ANSWER_NR + " INTEGER " + " ) ";
        db.execSQL(SQL_CRETE_QUESTION_TABLE);

        fillQuestionTable();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(" DROP TABLE IF EXISTS " + QuestionTables.TABLE_NAME);
        onCreate(db);
    }

    //    Question and Answer here      //
    private void fillQuestionTable() {
        Question q1 = new Question("If you don’t spill the beans now, you might gonna regret it.", "Spread rumors", "Let out a secret", "Plant some seeds", "None of the above", 2);
        addQuestion(q1);
        Question q2 = new Question("Hey, man, you are absolutely barking up the wrong tree here because I’m innocent.", "Choosing the wrong dog", "Giving up a fight", "Accusing the wrong person", "Setting up an event in a tree", 3);
        addQuestion(q2);
        Question q3 = new Question("One proven way to beat an enemy is find his Achilles heel.", "Secret strategy", "Amulet", "Strong point", "Weak spot", 4);
        addQuestion(q3);
        Question q4 = new Question("His new Ferrari costs an arm and a leg so he is now looking for another job.", "Very expensive", "Got fired", "Met an accident", "Was stolen", 1);
        addQuestion(q4);
        Question q5 = new Question("He married a woman who was born with a silver spoon in her mouth.", "Born very beautiful", "Born very poor", "Born from a very rich family", "Born very talkative", 3);
        addQuestion(q5);
        Question q6 = new Question("She has different investments because she doesn’t want to put all eggs in one basket.", "Doesn’t want to put all resources in one possibility", "Doesn’t want to cook everything at once", "Doesn’t want to go bankrupt", "None of the above", 1);
        addQuestion(q6);
        Question q7 = new Question("Whenever his crush passes by the hallway, he’s having butterflies in his stomach.",  "He feels sick", "He feels nervous", "He feels like flying","He feels so handsome", 2);
        addQuestion(q7);
        Question q8 = new Question("Even though they had a nasty fight, they decided to bury the hatchet and move on.", "Kill the enemy", "Remember the past", "Bury the dead", "Forget the past quarrel", 4);
        addQuestion(q8);
        Question q9 = new Question("My father always reminds us, “don’t count your chickens before the eggs have hatched.”", "Don’t eat your eggs before they are cooked.", "Don’t make plans for something that might not happen.", "Don’t deal with your problems before they are solved.", "All of the above.", 2);
        addQuestion(q9);
        Question q10 = new Question("iphones became so popular not only to teens, even my grandparents jumped on the bandwagon and bought some.", "ride on the gadget and sell Apple", "jump for technology and sell iphones", "joined the new trend and bought iphones", "bought Android and Apple", 3);
        addQuestion(q10);


    }


    private void addQuestion(Question question) {
        ContentValues Content_val = new ContentValues();
        Content_val.put(QuestionTables.COLUMN_QUESTION, question.getQuestion());
        Content_val.put(QuestionTables.COLUMN_OPTION1, question.getOption1());
        Content_val.put(QuestionTables.COLUMN_OPTION2, question.getOption2());
        Content_val.put(QuestionTables.COLUMN_OPTION3, question.getOption3());
        Content_val.put(QuestionTables.COLUMN_OPTION4, question.getOption4());
        Content_val.put(QuestionTables.COLUMN_ANSWER_NR, question.getAnswer());
        db.insert(QuestionTables.TABLE_NAME, null, Content_val);
    }

    public List<Question> getAllQuestions() {
        List<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery(" SELECT * FROM " + QuestionTables.TABLE_NAME, null);
        if (c.moveToFirst()) {
            do {
                Question questions = new Question();
                questions.setQuestion((c.getString(c.getColumnIndex(QuestionTables.COLUMN_QUESTION))));
                questions.setOption1((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION1))));
                questions.setOption2((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION2))));
                questions.setOption3((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION3))));
                questions.setOption4((c.getString(c.getColumnIndex(QuestionTables.COLUMN_OPTION4))));
                questions.setAnswer((c.getInt(c.getColumnIndex(QuestionTables.COLUMN_ANSWER_NR))));
                questionList.add(questions);
            } while (c.moveToNext());
        }
        c.close();
        return questionList;

    }
}
