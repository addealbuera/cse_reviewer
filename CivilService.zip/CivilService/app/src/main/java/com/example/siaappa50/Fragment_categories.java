package com.example.siaappa50;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Fragment_categories extends Fragment {
  @Nullable
  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_categories, container, false);
//        Button buttonQuiz01 = view.findViewById(R.id.buttonQuiz01);
//        Button buttonQuiz02 = view.findViewById(R.id.buttonQuiz02);
//        Button buttonQuiz03 = view.findViewById(R.id.buttonQuiz03);
//        Button buttonQuiz04 = view.findViewById(R.id.buttonQuiz04);
//
//        buttonQuiz01.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                Intent go = new Intent(getActivity(), Quiz_Question_01.class);
//                //go.putExtra("some","some data");
//                startActivity(go);
//            }
//        });
//        buttonQuiz02.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                Intent go = new Intent(getActivity(), Quiz_Question_01.class);
//                startActivity(go);
//            }
//        });
//        buttonQuiz03.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                Intent go = new Intent(getActivity(), Quiz_Question_01.class);
//                startActivity(go);
//            }
//        });
//        buttonQuiz04.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                Intent go = new Intent(getActivity(), Quiz_Question_01.class);
//                startActivity(go);
//            }
//        });

    return view;

//        return inflater.inflate(R.layout.fragment_quiz, container, false);

  }
}
